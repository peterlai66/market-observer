## 0.7.7
- 修正 `scripts/_util.mjs`：Windows 改以明確 `cmd.exe /d /s /c` 啟動 `npm` / `npx` / `.cmd`，移除 `shell:true + args` 造成的 `DEP0190` 警告風險。
- 保留 `mo deploy`、`mo logs`、`mo smoke` 等 CLI 行為不變，但 child process runner 更穩定，避免未來 Node 版本升級再出現相容性雜訊。

## 0.7.5-handoff
- 修正 `scripts/_util.mjs`：child process 啟動失敗不再被誤判成成功。
- 修正 `mo deploy`：保留 `npm run deploy` 路徑，但因 `_util.run()` 正確拋錯，Windows 下不再假成功。
- 新增 `npm run smoke:worker`，供 Worker 變更前做 typecheck 與 `wrangler deploy --dry-run` 驗證。
- 同步更新 handoff 文件，納入 update/deploy 分流、D0~D19 為 20 交易日模擬週期、目前未完成項與已知問題。

# Market Observer v0.6.9

- Make `smoke:tools` Windows-safe by reusing the source repo `node_modules` instead of calling nested `npm install` in the temp sandbox.
- Use `node` from the current runtime for smoke steps, create `.updates/inbox` during sandbox setup, and fail fast with a clear message when local dependencies are missing.

# Market Observer v0.6.8

- Add `scripts/smoke-tools.mjs` and `npm run smoke:tools` to verify `mo pack` / `mo patch` / `mo update` end-to-end in a temp repo.
- Fix `scripts/doctor.mjs` success output so the script exits cleanly.
- Fix `scripts/apply-patch.mjs` missing `rmSync` import during deprecated cleanup.
- Replace ZIP creation with `archiver` to normalize entry paths and avoid Windows-created packages storing backslashes in zip entries.
- Keep deprecated `.updates/backup` cleanup covered by smoke verification for both patch and update flows.

# Market Observer v0.6.7-handoff

- Align `mo pack` output path to `.updates/outbox/market-observer_dev_latest.zip`.
- Extend `.updates` contract to include `outbox/dev` and `outbox/handoff`.
- Add deprecated cleanup for `.updates/backup` after successful patch / update.
- Strengthen handoff rule: compare, fill gaps, record unfinished items, then generate a new handoff package.
- Synchronize `MO_START.md`, `docs/PROJECT.md`, `docs/AI_MEMORY.md`, `docs/NEXT_TASK.md`, `docs/update_process.md`, `developer/SCRIPTS_GUIDE.md`, and `.updates/README.md`.

# Market Observer v0.5.5 (hotfix)

- Fixes premature post_close_done marking: post-close is marked done only after today's summary exists and is non-empty.
- Allows push-only placeholder at 16:00 even when summary is not ready, while keeping post-close retry active every 15 minutes.

# Market Observer v0.5.4 (stable)

- Orders generation no longer aborts when TWSE "not ready"; summary may skip but strategy/simulation can continue.
- Prevents wiping existing PENDING orders when no TWSE stock snapshot is available.
- Fixes index up/down direction by applying TWSE sign to change points.

# Market Observer v0.4.2-hotfix.1

- TWSE FMTQIK trade date missing no longer crashes daily process.
- Mark daily readiness into mo_daily_mark and skip until ready.

# Market Observer Release Notes

## 0.0.0 (2026-03-04 19:44)  [1e0b808]

### Other
- auto 20260304_1709
- Initial commit (by create-cloudflare CLI)

## 2026-03-04  Dev Tools Baseline

### Add
- `scripts/` dev tools
- `npm run pack:dev` / `npm run pack:release`
- `npm run send` (typecheck → commit → pack:dev → open artifacts)
- `npm run quick` (typecheck → deploy → tail)
- `npm run doctor` (check node/npm/wrangler/git + wrangler bindings)

### Notes
- Packaging includes: `src/`, `scripts/`, `migrations/`, `wrangler.jsonc`, `package.json`, `tsconfig.json`, `README.md`, `RELEASE_NOTES.md`

---

## 0.4.2 (2026-03-05)

### Added
- D1 runtime audit tables (migration `0005_add_runtime_audit_tables.sql`)
  - `mo_tick_audit`: tick dispatcher audit + de-dupe lock
  - `mo_daily_mark`: daily market-data readiness + push markers
  - `mo_execution_mark`: simulation / execution audit

### Improved
- Tick dispatcher writes audit rows and safely skips duplicate ticks.
- `mo status` includes health summary pulled from remote D1.

### Changed
- Cron trigger switched to global heartbeat: `*/15 * * * *`
