Update staging area for MO releases.
