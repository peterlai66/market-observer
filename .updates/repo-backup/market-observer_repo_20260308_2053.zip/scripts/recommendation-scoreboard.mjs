#!/usr/bin/env node
import { fmtPct, runQuery } from './_recommendation_review_lib.mjs';

const mode = (process.argv[2] || 'remote').trim().toLowerCase();
const remote = mode !== 'local';

console.log(`MO Recommendation Scoreboard (${remote ? 'remote' : 'local'})`);

const batchRows = runQuery(`
SELECT trade_date, review_universe, available_trade_dates, max_review_horizon, review_generated_at
FROM mo_recommendation_review_batches
ORDER BY review_generated_at DESC, trade_date DESC
` , remote);

const itemRows = runQuery(`
SELECT trade_date, symbol, order_status, d0_return, d5_return, d10_return, d20_return
FROM mo_recommendation_review_items
ORDER BY reviewed_at DESC, trade_date DESC, symbol ASC
`, remote);

const totalBatches = batchRows.length;
const totalSymbols = itemRows.length;
const filledOrders = itemRows.filter((r) => String(r.order_status || '').toUpperCase() === 'EXECUTED').length;
const skippedOrders = itemRows.filter((r) => String(r.order_status || '').toUpperCase() === 'SKIPPED').length;
const pendingOrders = itemRows.filter((r) => String(r.order_status || '').toUpperCase() === 'PENDING').length;
const skipRatio = totalSymbols > 0 ? (skippedOrders / totalSymbols) * 100 : 0;
const filledRatio = totalSymbols > 0 ? (filledOrders / totalSymbols) * 100 : 0;

console.log('');
console.log(`total_batches=${totalBatches}`);
console.log(`total_symbols=${totalSymbols}`);
console.log(`filled_orders=${filledOrders}`);
console.log(`skipped_orders=${skippedOrders}`);
console.log(`pending_orders=${pendingOrders}`);
console.log('');
console.log(`skip_ratio=${skipRatio.toFixed(2)}%`);
console.log(`filled_ratio=${filledRatio.toFixed(2)}%`);

if (totalBatches > 0) {
  const latest = batchRows[0];
  console.log('');
  console.log(`latest_batch=${latest.trade_date}`);
  console.log(`latest_universe=${latest.review_universe}`);
  console.log(`latest_horizon=D${latest.max_review_horizon}`);
  console.log(`latest_available_trade_dates=${latest.available_trade_dates}`);
}

const checkpoints = [
  { label: 'D0', key: 'd0_return' },
  { label: 'D5', key: 'd5_return' },
  { label: 'D10', key: 'd10_return' },
  { label: 'D20', key: 'd20_return' },
];

const statuses = ['EXECUTED', 'SKIPPED', 'PENDING'];
const normalizedItems = itemRows.map((row) => ({
  ...row,
  order_status: String(row?.order_status || '').trim().toUpperCase() || 'UNKNOWN',
}));

const avg = (values) => values.length ? values.reduce((sum, value) => sum + value, 0) / values.length : NaN;
const fmtMaybePct = (values) => values.length ? fmtPct(avg(values)) : '—';
const ratio = (num, den) => den > 0 ? `${((num / den) * 100).toFixed(2)}%` : '0.00%';
const windows = [1, 3, 5];
const latestTradeDates = [...new Set(batchRows.map((row) => String(row.trade_date || '')))].filter(Boolean);

console.log('');
console.log('checkpoint_outcomes:');
for (const checkpoint of checkpoints) {
  const evaluableRows = normalizedItems.filter((row) => Number.isFinite(Number(row?.[checkpoint.key])));
  const values = evaluableRows.map((row) => Number(row?.[checkpoint.key]));
  const evaluable = values.length;
  const coverage = totalSymbols > 0 ? (evaluable / totalSymbols) * 100 : 0;
  const positive = values.filter((value) => value > 0).length;
  const positiveRate = evaluable > 0 ? (positive / evaluable) * 100 : 0;
  const average = evaluable > 0 ? avg(values) : NaN;

  console.log(`${checkpoint.label}_evaluable=${evaluable}`);
  console.log(`${checkpoint.label}_coverage=${coverage.toFixed(2)}%`);
  console.log(`${checkpoint.label}_positive=${positive}`);
  console.log(`${checkpoint.label}_positive_rate=${positiveRate.toFixed(2)}%`);
  console.log(`${checkpoint.label}_average_return=${fmtPct(average)}`);
  console.log('');

  const winRows = evaluableRows.filter((row) => Number(row?.[checkpoint.key]) > 0);
  const lossRows = evaluableRows.filter((row) => Number(row?.[checkpoint.key]) < 0);
  const flatRows = evaluableRows.filter((row) => Number(row?.[checkpoint.key]) === 0);
  const win = winRows.length;
  const loss = lossRows.length;
  const flat = flatRows.length;
  const avgOfRows = (rows) => rows.length
    ? fmtPct(rows.reduce((sum, row) => sum + Number(row?.[checkpoint.key]), 0) / rows.length)
    : '—';

  console.log(`${checkpoint.label}_classification:`);
  console.log(`win=${win}`);
  console.log(`loss=${loss}`);
  console.log(`flat=${flat}`);
  console.log(`win_rate=${ratio(win, evaluable)}`);
  console.log(`loss_rate=${ratio(loss, evaluable)}`);
  console.log(`flat_rate=${ratio(flat, evaluable)}`);

  for (const status of statuses) {
    const rows = evaluableRows.filter((row) => row.order_status === status);
    const key = status.toLowerCase();
    console.log(`${key}_evaluable=${rows.length}`);
    console.log(`${key}_average_return=${avgOfRows(rows)}`);
  }
  console.log('');

  const decisive = win + loss;
  const avgWin = avg(winRows.map((row) => Number(row?.[checkpoint.key])));
  const avgLoss = avg(lossRows.map((row) => Number(row?.[checkpoint.key])));
  const edgeRatio = Number.isFinite(avgWin) && Number.isFinite(avgLoss) && avgLoss !== 0
    ? `${Math.abs(avgWin / avgLoss).toFixed(2)}x`
    : '—';

  console.log(`${checkpoint.label}_performance:`);
  console.log(`expectancy=${fmtPct(average)}`);
  console.log(`avg_win_return=${fmtPct(avgWin)}`);
  console.log(`avg_loss_return=${fmtPct(avgLoss)}`);
  console.log(`edge_ratio=${edgeRatio}`);
  console.log(`nonflat_evaluable=${decisive}`);
  console.log(`decisive_rate=${ratio(decisive, evaluable)}`);
  console.log('');

  console.log(`${checkpoint.label}_rolling:`);
  for (const window of windows) {
    const chosenDates = latestTradeDates.slice(0, window);
    const rows = evaluableRows.filter((row) => chosenDates.includes(String(row.trade_date || '')));
    const rowValues = rows.map((row) => Number(row?.[checkpoint.key])).filter((value) => Number.isFinite(value));
    const label = `last_${window}_batch`;
    console.log(`${label}_count=${Math.min(window, latestTradeDates.length)}`);
    console.log(`${label}_evaluable=${rows.length}`);
    console.log(`${label}_average_return=${fmtMaybePct(rowValues)}`);
    console.log(`${label}_positive_rate=${ratio(rowValues.filter((value) => value > 0).length, rowValues.length)}`);
  }
  console.log('');
}

console.log('Recommendation scoreboard OK');
