# MO Lifecycle v1

## Report
- `report(tradeDate)` 是資料資產，即使延遲也必須最終產生。
- 狀態分級：`VALID` / `DEGRADED` / `PENDING`。
- `VALID` 代表可直接作為隔日 recommendation 基礎；`DEGRADED` 代表來源部分延遲，但仍可保留為歸檔與驗證資料。

## Recommendation
- `recommendation(T)` 服務於下一個交易日開盤前。
- `effective_trade_date = next weekday(T)`。
- `expires_at = effective_trade_date 09:00 Asia/Taipei`。
- 若超過時效未能作為實盤訊號，仍保留作為模型驗證樣本。

## Simulation
- `simulation(T+1)` 使用 `report(T+1)` 的 high/low/open 驗證 `recommendation(T)`。
- 驗證結果：`FILLED` / `NOT_FILLED`。
- 若 recommendation 不存在，simulation 可標記為 `INVALID_NO_RECOMMENDATION`。

## D1 order metadata
`mo_orders` 補充以下欄位：
- `effective_trade_date`
- `expires_at`
- `lifecycle_status`
- `validation_status`
- `report_source_quality`

用途：讓 recommendation 的有效期、simulation 驗證結果、報告品質能被明確追蹤。
