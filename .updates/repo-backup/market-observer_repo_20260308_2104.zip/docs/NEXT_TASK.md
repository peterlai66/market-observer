## After 0.12.2
1. 驗證 `mo recommendation-scoreboard` 新增的 `diagnosis` 區塊可穩定輸出。
2. 重點觀察 `dominant_status / gate_pressure / edge_state` 是否能清楚說明目前是 execution gate 主導還是 recommendation edge 主導。
3. 下一步可擴充 diagnosis ranking、跨 checkpoint 比較，或加入 gate reason breakdown。

## After 0.12.1
1. 驗證 `mo recommendation-scoreboard` 新增的 `execution_summary` 區塊可穩定輸出。
2. 重點觀察 `overall` 與 `executed / skipped / pending` 的差異，確認是否能清楚區分 recommendation edge 與 execution gate。
3. 下一步可擴充 execution-aware rolling summary，或加入 batch 間排名 / 穩定度比較。

## After 0.12.0
1. 驗證 `mo recommendation-scoreboard` 新增的 performance 與 rolling 區塊可穩定讀取並正確顯示。
2. 驗證 `npm run mo -- baseline` 可正確顯示 locked baseline 與指紋。
3. 下一步可擴充 executed-only / skipped-only 的 rolling summary，或增加 batch 間排名比較。

## After 0.11.9
1. 驗證 `mo recommendation-scoreboard` 新增的 checkpoint classification 可穩定讀取並正確顯示。
2. 下一步可擴充 batch 間比較、最近 N 批 rolling summary，或加上 filled-only / skipped-only 的 summary 視角。
3. 維持既有 summary 與 0.11.8 outcome metrics 穩定，持續遵守 MO 為推薦驗證系統的定位。

## After 0.11.3
1. 驗證 `mo recommendation-review-save` 能正確寫入 batch / symbol review snapshot。
2. 下一步將 review snapshot 擴充成 scoreboard（平均報酬、勝率、命中率、回撤）。
3. 後續再補批次比較與最近 N 批推薦摘要。

## After 0.11.0
1. 驗證 `mo recommendation-review` 在最新推薦批次上能正確輸出 D0 / D5 / D10 / D20 表現。
2. 若資料不足 20 個交易日，確認腳本以 skip / partial review 呈現，而不是誤判失敗。
3. 下一步再把 recommendation review 擴充成批次 scoreboard（平均報酬、勝率、回撤）。

## After 0.10.8
1. 驗證 `mo portfolio-verify` 在目前空投組狀態與未來有 executed orders 後都能正確工作。
2. 進入 FS-01 Portfolio Closed Loop v2：補 `EXECUTED -> mo_positions / cash_twd / snapshot` 的更完整 schema / updater，而不只停在驗證腳本。
3. 後續再把 realized / unrealized PnL visibility 接到 runtime invariants / portfolio-verify，讓資料層驗證不只看 cash / positions。

## After 0.10.5
1. 驗證 `mo runtime-invariants`、`mo preflight-worker`、`mo autopilot-worker` 是否能在資料異常時正確失敗。
2. 進入 FS-01 Portfolio Closed Loop v2：補 `EXECUTED -> mo_positions / cash_twd / snapshot` 的更完整查詢手冊與必要 schema。
3. 後續再把 realized / unrealized PnL visibility 接到 runtime invariants，讓資料層驗證不只看 cash / positions。

## Current focus after 0.10.0
- Verify that cost-aware guards do not block all valid TW ETF trades, while still filtering out low-notional / fee-inefficient orders.
- Observe next execution cycle to confirm cash, positions and pending→executed/skipped transitions include costs correctly.
- Next phase: extend cost-aware rules into full portfolio closed loop and realized/unrealized PnL visibility.

## Current focus after 0.9.1
- Verify that TW ETF candidates now convert into at least one recommendation/order when `signal=TRY` and candidates exist.
- If `recs` is still 0, use `debug` and `mo_strategy_debug` to inspect the new `px=<source>` lines before adjusting thresholds.

# NEXT TASK

## Current baseline
- Stable base: 0.9.0
- CLI / toolchain baseline remains stable after 0.8.5
- Universe is consumed by engine
- Strategy debug is available through LINE and D1
- Recommendation engine now includes conservative starter fallback

## Immediate next task
1. 觀察 0.9.0 在真實交易日是否開始產生 observation-style BUY/SELL 建議。
2. 若 fallback 太常出現，進一步調整 ranking / signal / budget gate，而不是永久依賴 fallback。
3. 讓 LINE `debug` 顯示更多 rejected reason 細節（例如 invalid_close / qty_zero / cut_by_rank）。
4. 將 D1 migrations apply 納入正式 release 驗證文件。

- Next: 在 dedupe 穩定後，繼續補強 `EXECUTED -> mo_positions / cash_twd / portfolio snapshot` 的驗證腳本與查詢手冊。


## After 0.10.2
1. 先驗證 `mo guard` / `mo sanity` 是否能在錯誤 release 命名、文件缺漏、版本不同步時正確失敗。
2. 再繼續 FS-01 Portfolio Closed Loop v2（`EXECUTED -> mo_positions / cash_twd / snapshot`）。
3. 規劃後續 `mo autopilot`，讓例行巡檢能自動串 `doctor / smoke / guard / sanity`。


## After 0.10.4
1. 驗證 `mo validate` / `mo preflight` / `mo preflight-worker` 是否能穩定收斂既有 guardrail。
2. 進入 FS-01 Portfolio Closed Loop v2：補 `EXECUTED -> mo_positions / cash_twd / snapshot`。
3. 後續補 runtime invariant 檢查（負現金 / NaN 持倉 / 缺 snapshot），讓 preflight 能擴充到資料一致性層。

- 0.11.1 完成後，下一步是把 recommendation review 的 D0/D5/D10/D20 結果正式落表，形成可追蹤的推薦驗證批次。


- 0.11.2 完成後，下一步是把 recommendation review 的結果正式落表（batch / symbol / horizon result），而不只停在 CLI 報表。

## After 0.11.6
1. 驗證 `mo recommendation-scoreboard` 可穩定讀取 review snapshot tables。
2. 下一步可擴充平均報酬、勝率、checkpoint 覆蓋率。

## After 0.11.8
1. 驗證 `mo recommendation-scoreboard` 新增的 D0 / D5 / D10 / D20 outcome metrics 可穩定讀取並正確顯示。
2. 下一步可擴充 batch 間比較、最近 N 批 rolling summary，或加上 filled-only outcome 切片。
3. 維持既有 summary 欄位穩定，持續遵守 MO 為推薦驗證系統的定位。

## After 0.11.7
1. 維持 `recommendation-scoreboard` 為已驗證基線，後續擴充不得破壞既有 summary 欄位。
2. 下一步開發 0.11.8：Recommendation Outcome Metrics，新增 D0 / D5 / D10 / D20 的 checkpoint outcome summary。
3. 新功能仍需遵守 MO 定位：推薦驗證系統，不可將 scope 帶偏為真實交易系統。

