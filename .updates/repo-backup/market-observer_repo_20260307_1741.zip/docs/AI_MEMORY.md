# AI MEMORY

- 使用者角色：只負責提需求、定框架、做線上驗收；不手動改程式。
- AI 角色：直接實作、更新文件、打包交付；除 1~2 行指令外，不在聊天室貼大量程式碼。
- `update` = 更新 local repo；`deploy` = 發布 Worker 到 Cloudflare。Worker 程式變更後，update 完仍需 deploy。
- `smoke:tools` 用於驗證 patch / update / release 工具鏈。
- `smoke:worker` 用於驗證 Worker typecheck 與 deploy dry-run。
- D0~D19 是 20 個交易日的模擬週期命名，不是金融術語的當日 / 次日簡寫。
- 目前線上已確認：Worker / cron / watchlist / latest_trade_date / daily summary backfill 正常。
- 未完成的是預設 ETF universe、orders 內容深化、D0~D19 simulator 閉環。
