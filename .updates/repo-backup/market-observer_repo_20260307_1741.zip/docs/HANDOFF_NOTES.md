# HANDOFF NOTES

## 本次 handoff 已補齊
- 修正 `scripts/_util.mjs`：spawn 失敗時不再被誤判成成功。
- `mo deploy` 仍維持走 `npm run deploy`，但因 `_util.run()` 已正確拋錯，Windows 下不再假成功。
- 新增 `scripts/smoke-worker.mjs` 與 `npm run smoke:worker`。
- 補上 daily summary 對齊 `latest_trade_date` 的流程。
- 非交易日 / LINE report 查詢時，若最近交易日摘要缺失，會先自動補生成再回覆。
- 建議產生流程已改為：先確認 `twse_daily_summary` 已存在，才進入 `mo_orders` / 模擬邏輯。
- 同步文件：`MO_START.md`、`docs/PROJECT.md`、`docs/AI_MEMORY.md`、`docs/NEXT_TASK.md`、`developer/SCRIPTS_GUIDE.md`。

## 目前已知狀態
- local toolchain：`update` / `smoke:tools` / `smoke:worker` 可用。
- Worker：可 deploy、cron 有跑、watchlist 與 latest_trade_date 可查。
- 已完成：daily summary 自動補生成、非交易日報告回補、summary → recommendation gate。
- 線上功能缺口：預設 ETF universe、`mo_orders` 建議內容深化、D0~D19 完整模擬。

## 仍未完成 / 待下一個 AI 接續
1. 讓預設 ETF universe 真正進入策略引擎，解決 `done 0/0`。
2. 補強 `mo_orders (PENDING)` 內容：標的、方向、價格區間、金額 / 數量建議、原因摘要。
3. 完成 D0~D19 模擬成交、持倉與績效更新閉環。
4. 若要再修 `mo deploy` UX，可再補上「update 完若需 deploy 的明確提示」。

## 新視窗接續指令
請上傳本 handoff 包，並輸入：

`讀取檔案中的 MO_START.md 並繼續開發專案`
