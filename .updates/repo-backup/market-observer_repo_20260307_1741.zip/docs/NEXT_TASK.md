# NEXT TASK

## Priority 1 — Strategy / Orders
1. 讓預設 ETF universe 真正進入策略引擎，不再只有 `watchlist` 顯示，tick 卻仍是 `done 0/0`。
2. 寫入 `mo_orders (PENDING)`，作為下一個模擬交易日的建議基礎。
3. 建議需包含：標的、方向、價格區間、金額 / 數量建議、原因摘要。

## Priority 2 — Simulator
1. 明確定義 D0~D19：代表 20 個交易日的模擬週期，不是市場慣例的「當日 / 次日」術語。
2. Dn 交易日：執行 D(n-1) 的建議，使用當日最高 / 最低價判定是否成交。
3. 同日仍需生成新的盤後報告與下一交易日建議。

## Priority 3 — Toolchain / UX
1. 本機交付前優先跑：`npm run smoke:tools`。
2. 若有 `src/`、`wrangler.jsonc`、`migrations/` 變更，再跑：`npm run smoke:worker`。
3. `update` 完成後，若 release 包含 Worker 相關檔案，文件與腳本提示都要提醒：仍需 `deploy`。

## Completed in 0.7.6
- `twse_daily_summary` 生成流程已改為對齊 `latest_trade_date`。
- 非交易日查詢盤後報告時，若最近交易日摘要不存在，會自動補生成最近交易日摘要。
- 建議流程已加上 gate：先確認摘要存在，再進入後續建議產生。
