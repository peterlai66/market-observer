
## 0.12.7
- 最新 scoreboard 已加入 data quality action layer。
- 看見 `data_blocking_severity=CRITICAL/HIGH` 時，後續優先處理資料品質與 coverage，不先做策略最適化。
## 0.12.6
- scoreboard 已從 0.12.5 的 unknown skip reasons，升級為 structured normalization；必須保留 `review_note` 查詢，不能再漏掉。


> 0.12.5: recommendation-scoreboard 新增 actionable_recommendations，可將 diagnosis / top findings 轉成下一步行動建議。

- `mo recommendation-scoreboard` 現在除了 outcome / classification / performance / rolling / execution_summary，還會輸出 `diagnosis`。
- 0.12.2 的 diagnosis 會顯示 `dominant_status`、`gate_pressure`、`edge_state`、`horizon_signal_strength`、`execution_coverage_gap` 與 `interpretation`。
## 0.12.1
- `mo recommendation-scoreboard` 現在除了 outcome / classification / performance / rolling，還會輸出 `execution_summary`。
- `execution_summary` 會把每個 checkpoint 拆成 `overall / executed / skipped / pending` 四種視角，避免把 gate 擋單造成的 `0.00%` 誤讀成 recommendation 本身沒有 edge。


## 0.12.0
- 已完成 Recommendation Performance Engine。
- `recommendation-scoreboard` 新增 checkpoint performance 與 rolling summary。
- `BASELINE.json` 現在是 release 的正式一部分，`mo baseline` 可直接查看鎖定中的 baseline。

## 0.11.9
- 已完成 Recommendation Outcome Classification。
- `recommendation-scoreboard` 新增 `win / loss / flat` 與 `executed / skipped / pending` 切片輸出。
## 2026-03-08 — 0.11.8
- `recommendation-scoreboard` 已擴充 checkpoint outcome summary，可輸出 D0 / D5 / D10 / D20 的 evaluable / coverage / positive / positive_rate / average_return。
- 0.11.8 明確要求保留既有 summary 欄位，不可因 outcome metrics 擴充而破壞舊驗證流程。

## 2026-03-08 — 0.11.7
- `recommendation-scoreboard` 已驗證成功，可穩定輸出 batch / symbol / filled / skipped / pending / latest batch summary。
- handoff 時要明確保留 MO 的正確定位：Recommendation Validation Engine，不是交易系統。

## 2026-03-08 — 0.11.3
- `mo recommendation-review-save` 會把 CLI review 結果寫入 D1，作為後續 scoreboard 的正式資料來源。
- 若 review snapshot tables 不存在，腳本會自動 `CREATE TABLE IF NOT EXISTS`，不依賴先手動 migration。

## 2026-03-08 — 0.11.0
- 使用者再次明確定義：MO 不是交易系統；模擬下單/持倉/portfolio 屬於推薦驗證資料層，用來驗證 20 個交易日內推薦是否有效。
- 新增 `mo recommendation-review`，後續每輪推薦驗證都應優先使用這支腳本檢視 D0 / D5 / D10 / D20 表現。

## 2026-03-08 — 0.10.8
- `runtime-invariants` 首版曾因 `wrangler.jsonc` 是 JSONC 而在 `loadDbName()` 直接失敗。
- 之後凡是腳本需要讀取 `wrangler.jsonc`，都必須使用可容忍 JSONC 的解析方式，不可直接 `JSON.parse`。

## 2026-03-08 — 0.10.5
- 新增 `mo runtime-invariants`，作為 worker preflight 的資料一致性層。
- 之後若有 Worker / D1 / portfolio 相關 release，驗證時除了 `validate` / `preflight-worker`，還要明確提供 `runtime-invariants` 的預期結果。

## 2026-03-07 — 0.10.0
- User explicitly requires minimum trade size / cost-aware filtering so that fees and tax do not consume the trade's potential value.
- This rule is now treated as a hard runtime rule, not a later optimization.

# AI MEMORY

- 0.8.1 established the stable CLI/toolchain baseline.
- 0.8.3 connected D1 `etf_universe` to the strategy engine.
- 0.8.4 added `mo_strategy_debug` and LINE `debug / 除錯`.
- 0.8.5 added artifact validation to prevent release naming regressions.
- 0.9.0 adds snapshot backfill + starter fallback so candidate-rich days no longer stall at `recs=0` without visibility.

- 0.9.1 learned issue: universe candidates were valid but final recommendation close lookup failed; strategy now records explicit price-source fallback in debug output.

- 2026-03-08：MO 0.10.1 已修正同交易日重複建單，`mo_recommendation_log.note` 會帶 `inserted/deduped`；`mo_execution_mark` 會寫入 skipped/executed 結果。


## 0.10.2 workflow memory
- 使用者要求：每一輪 release 後先驗證與討論，再開始下一輪開發。
- 下一輪開發前，必須先由使用者提供 `market-observer_dev_latest.zip` 作為唯一基底。
- AI 不可在對話中貼大量程式碼；應直接改 dev 包並產出 `market-observer_release_latest.zip`。
- 新增 `mo guard` / `mo sanity` 以降低 AI 交付偏離流程的機率。


## 2026-03-08 — 0.10.3
- MO guardrail 第二階段新增 `mo autopilot` / `mo autopilot-worker`。
- 之後 release 驗證至少要跑 `autopilot`；若這輪改到 Worker / wrangler / migrations，則要跑 `autopilot-worker`。


## 2026-03-08 — 0.10.4
- 新增 `mo validate`、`mo preflight`、`mo preflight-worker`。
- `autopilot` / `autopilot-worker` 改為相容 alias，避免之後 preflight 與 autopilot 定義分叉。
- 之後 release 驗證至少要提供 `validate` 與 `preflight` 的執行與預期結果。


## 0.10.9
- 新增 `mo portfolio-verify`，後續每輪成交閉環驗收時，優先搭配 `mo runtime-invariants` 一起跑。

- 0.11.1：每次 release 必須先提供本輪實際改動檔案，並要求使用者先跑 `doctor` 驗版本，再跑目標腳本驗功能。


- 0.11.2：`recommendation-review` 需要先說明目前可回看交易日數，再輸出各 symbol 的 D0/D5/D10/D20；資料不足時要用清楚的 reason 標示，不可只顯示 `—`。

## 2026-03-08 — 0.11.6
- 新增 `mo recommendation-scoreboard`，後續批次推薦驗證將先看 scoreboard，再深入 individual review。


0.12.3: batch-level summary + top findings added to recommendation-scoreboard.
