## 0.13.7
- Full Pipeline Readiness Summary
- `mo recommendation-scoreboard` now prints `pipeline_readiness_summary`, `pipeline_readiness_findings`, and `pipeline_readiness_actions`.
- Verify with `npm run mo -- doctor` then `npm run mo -- recommendation-scoreboard`.

Next target: 0.13.7 execution validation unlock checks
