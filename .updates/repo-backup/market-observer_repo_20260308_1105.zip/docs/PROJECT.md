## 0.10.1 update
- 修正同一 `signal_date + symbol + side` 在重複 `/admin/run` 時會反覆新增新 `PENDING` 單的問題；現在同日已有 order 紀錄時會直接 dedupe。
- `executePendingOrders` 現在會把 `SKIPPED / EXECUTED` 寫入 `mo_execution_mark`，方便查核每輪實際處理結果。

## 0.10.0 update
- MO 已進入成交閉環第一階段：strategy output 不只會產生 `mo_orders`，也會在 recommendation 與 execution 兩端做成本感知過濾。
- 新增交易守門概念：`minQty`、`minNotionalTwd`、`roundTripCost`、`edge_lt_cost`。
- 目前 TW ETF 採保守規則：先過成本與最小量門檻，再進入 PENDING / EXECUTED / SKIPPED 流程。

# PROJECT

## Current state
- CLI / update / smoke / deploy pipeline stable
- ETF universe comes from env -> D1 -> default fallback
- Multi-asset engine now generates candidates from universe snapshots
- 0.9.0 adds conservative starter fallback so the system can move from pure observation to actionable recommendations
- LINE commands for operational verification: 狀態 / 建議 / debug / universe

- 0.9.1: final recommendation close-price mapping now resolves TW ETF prices from raw close, OHLC fallback, and candidate fallback before rejecting for invalid close.
