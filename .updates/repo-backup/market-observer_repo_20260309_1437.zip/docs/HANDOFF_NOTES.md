# HANDOFF NOTES

## Project identity
- Project: Market Observer (MO)
- Current verified version: 0.11.7
- System role: Recommendation Validation Engine
- Important: MO is **not** a real trading system. Simulated orders / portfolio tables exist only to validate recommendation effectiveness over a 20-trading-day observation window.

## Verified baseline before handoff
The following commands were validated in the current line before handoff:
- `npm run mo -- doctor`
- `npm run mo -- runtime-invariants`
- `npm run mo -- portfolio-verify`
- `npm run mo -- recommendation-review`
- `npm run mo -- recommendation-review-save`
- `npm run mo -- recommendation-scoreboard`

Key observed outputs from the verified baseline:
- `market-observer@0.11.7`
- `Runtime invariants OK`
- `Portfolio verify OK`
- `Recommendation review OK`
- `Recommendation review save OK`
- `Recommendation scoreboard OK`

## Current D1 recommendation-validation state
Latest known validated state in remote D1:
- review batch table contains `trade_date=2026-03-06`
- `review_universe=3`
- `max_review_horizon=D13`
- review items contain:
  - `00757`
  - `00878`
  - `00919`
- all current review items are `order_status=SKIPPED`
- scoreboard summary:
  - `total_batches=1`
  - `total_symbols=3`
  - `filled_orders=0`
  - `skipped_orders=3`
  - `pending_orders=0`
  - `latest_batch=2026-03-06`
  - `latest_universe=3`
  - `latest_horizon=D13`
  - `latest_available_trade_dates=14`

## Recommendation-validation features already landed
- `mo recommendation-review`
- `mo recommendation-review-save`
- `mo recommendation-scoreboard`
- `mo runtime-invariants`
- `mo portfolio-verify`
- guardrail / validation chain:
  - `mo guard`
  - `mo sanity`
  - `mo validate`
  - `mo preflight`
  - `mo preflight-worker`
  - `mo autopilot`
  - `mo autopilot-worker`

## Important workflow rules carried into the next window
- Always start from the uploaded `market-observer_dev_latest.zip`.
- Release filename must be exactly `market-observer_release_latest.zip`.
- First verification after any release must be `npm run mo -- doctor`.
- Do not claim a fix is complete until:
  1. version bump is visible in `doctor`
  2. the target script for this round has been validated successfully
- When the user types `handoff`, do **not** continue feature development. Produce a real handoff package instead.

## Next recommended task
Target next version: 0.11.8

Recommended feature:
- **Recommendation Outcome Metrics**

Suggested scope:
- extend scoreboard with checkpoint-level outcome metrics:
  - `D0`
  - `D5`
  - `D10`
  - `D20`
- add per-checkpoint summary fields such as:
  - evaluable count
  - coverage
  - positive count / positive rate
  - average return
- keep MO aligned with recommendation validation, not auto-trading

## New-window continuation instruction
Upload this handoff zip in the new chat, then send:

`讀取檔案中的 MO_START.md 並接手 market-observer 專案；目前版本 0.11.7，系統定位是 Recommendation Validation Engine，下一步做 0.11.8 Recommendation Outcome Metrics。`
