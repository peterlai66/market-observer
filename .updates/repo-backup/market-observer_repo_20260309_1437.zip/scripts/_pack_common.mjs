import { cpSync, existsSync, mkdirSync, mkdtempSync, readdirSync, renameSync, rmSync, statSync, createWriteStream } from 'node:fs';
import { dirname, join, relative, resolve, sep } from 'node:path';
import { tmpdir } from 'node:os';
import { execFileSync } from 'node:child_process';
import archiver from 'archiver';
import { nowTag } from './_util.mjs';

export function ensureDir(path) {
  mkdirSync(path, { recursive: true });
}

export function rotateLatest(outDir, latestName) {
  ensureDir(outDir);
  const bakDir = join(outDir, 'bak');
  ensureDir(bakDir);
  const latestPath = join(outDir, latestName);
  if (existsSync(latestPath)) {
    const archivedName = latestName.replace(/_latest\.zip$/i, `_${nowTag()}.zip`);
    renameSync(latestPath, join(bakDir, archivedName));
  }
}

function stageItems(rootDir, stageDir, items) {
  for (const item of items) {
    const src = join(rootDir, item);
    if (!existsSync(src)) continue;
    const dest = join(stageDir, item);
    cpSync(src, dest, { recursive: true, force: true });
  }
}

function normalizeEntryName(name) {
  return name.split(sep).join('/');
}

function addDirectoryRecursive(archive, rootDir, currentDir) {
  for (const name of readdirSync(currentDir)) {
    const full = join(currentDir, name);
    const st = statSync(full);
    const rel = normalizeEntryName(relative(rootDir, full));
    if (st.isDirectory()) {
      archive.append('', { name: `${rel}/` });
      addDirectoryRecursive(archive, rootDir, full);
    } else {
      archive.file(full, { name: rel });
    }
  }
}

async function zipDirectory(stageDir, zipPath) {
  rmSync(zipPath, { force: true });
  await new Promise((resolvePromise, rejectPromise) => {
    const output = createWriteStream(zipPath);
    const archive = archiver('zip', { zlib: { level: 9 } });

    output.on('close', resolvePromise);
    output.on('error', rejectPromise);
    archive.on('error', rejectPromise);
    archive.pipe(output);

    addDirectoryRecursive(archive, stageDir, stageDir);
    archive.finalize().catch(rejectPromise);
  });
}

export async function createZip(rootDir, zipPath, items) {
  ensureDir(dirname(zipPath));
  const stageDir = mkdtempSync(join(tmpdir(), 'mo-zip-'));
  try {
    stageItems(rootDir, stageDir, items);
    await zipDirectory(stageDir, zipPath);
    const st = statSync(zipPath);
    if (!st.size) throw new Error('zip created but empty');
    return st.size;
  } finally {
    rmSync(stageDir, { recursive: true, force: true });
  }
}

export function extractZip(zipPath, outDir) {
  rmSync(outDir, { recursive: true, force: true });
  ensureDir(outDir);
  if (process.platform === 'win32') {
    const ps = [
      '$ErrorActionPreference = "Stop"',
      'Add-Type -AssemblyName System.IO.Compression.FileSystem',
      `$zip = ${JSON.stringify(resolve(zipPath))}`,
      `$out = ${JSON.stringify(resolve(outDir))}`,
      'if (Test-Path $out) { Remove-Item -LiteralPath $out -Recurse -Force }',
      'New-Item -ItemType Directory -Path $out -Force | Out-Null',
      '[System.IO.Compression.ZipFile]::ExtractToDirectory($zip, $out)',
    ].join('; ');
    execFileSync('powershell', ['-NoProfile', '-Command', ps], { stdio: 'inherit' });
  } else {
    execFileSync('unzip', ['-q', zipPath, '-d', outDir], { stdio: 'inherit' });
  }
}

export function countFilesRecursive(dir) {
  if (!existsSync(dir)) return 0;
  let total = 0;
  for (const name of readdirSync(dir)) {
    const full = join(dir, name);
    const st = statSync(full);
    if (st.isDirectory()) total += countFilesRecursive(full);
    else total += 1;
  }
  return total;
}
