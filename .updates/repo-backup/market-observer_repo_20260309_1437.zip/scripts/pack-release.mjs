#!/usr/bin/env node
import { join, resolve } from 'node:path';
import { createZip, rotateLatest } from './_pack_common.mjs';
import { run } from './_util.mjs';

const root = resolve('.');
const outDir = join(root, '.updates', 'outbox');
const latestName = 'market-observer_release_latest.zip';
const zipPath = join(outDir, latestName);
const items = [
  'MO_START.md',
  'README.md',
  'BASELINE.json',
  'package.json',
  'package-lock.json',
  'tsconfig.json',
  'wrangler.jsonc',
  'worker-configuration.d.ts',
  'manifest.json',
  'VERSION',
  'CHANGELOG.md',
  'RELEASE_NOTES.md',
  'src',
  'scripts',
  'migrations',
  'docs',
  'developer',
  '.updates/README.md',
  '.editorconfig',
  '.gitignore',
  '.env.example',
  '.prettierrc',
  '.zipignore'
];

run('node', ['scripts/sync-structure.mjs']);
run('node', ['scripts/write-baseline.mjs']);
run('node', ['scripts/doctor.mjs']);
run('node', ['scripts/validate.mjs']);
rotateLatest(outDir, latestName);
await createZip(root, zipPath, items);
run('node', ['scripts/validate-artifacts.mjs']);
console.log(`Packed => ${zipPath}`);
