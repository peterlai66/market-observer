#!/usr/bin/env node
import { join, resolve } from 'node:path';
import { createZip, rotateLatest } from './_pack_common.mjs';

const root = resolve('.');
const outDir = join(root, '.updates', 'outbox');
const latestName = 'market-observer_dev_latest.zip';
const zipPath = join(outDir, latestName);
const items = [
  'MO_START.md',
  'README.md',
  'package.json',
  'package-lock.json',
  'tsconfig.json',
  'wrangler.jsonc',
  'worker-configuration.d.ts',
  'manifest.json',
  'VERSION',
  'CHANGELOG.md',
  'RELEASE_NOTES.md',
  'src',
  'scripts',
  'migrations',
  'docs',
  'developer',
  '.updates/README.md',
  '.editorconfig',
  '.gitignore',
  '.env.example',
  '.prettierrc',
  '.zipignore'
];

rotateLatest(outDir, latestName);
await createZip(root, zipPath, items);
console.log(`Packed => ${zipPath}`);
