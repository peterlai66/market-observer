# .updates directory contract

- inbox/: incoming patch / release package waiting for mo patch / mo update
- work/: temporary extraction and staging area
- bak/: archive of consumed patch / release packages
- repo-backup/: repository snapshot before patch / update
- outbox/: generated dev / patch / release / handoff artifacts (single root, file-name based)
- outbox/bak/: archived previous *_latest.zip artifacts
- history/: update history and operation records

Deprecated directories that must not exist anymore:
- outbox/dev/
- outbox/patch/
- outbox/release/
- outbox/handoff/
- .updates/backup/
