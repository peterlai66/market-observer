# MO_START

這是 **Market Observer (MO)** 專案的唯一入口文件。

本文件不是普通說明文件，而是 **AI Runtime Spec / 專案執行規格**。  
任何 AI 只要接手本專案，**必須先完整閱讀本文件，再開始任何修改**。

---

## 0. 核心原則（先讀）

### AI 必須遵守

- **先讀文件，再改程式**
- **先理解既有架構，再接續開發**
- **所有架構 / 功能 / 流程 / 目錄 / 檔案變更，都必須同步更新文件**
- **一般交付一律提供可透過 `mo update` 套用的 release zip**
- **修工具鏈時優先走 `mo patch`**
- **只有使用者明確輸入 `handoff` 時，才進入交接流程並產出 handoff 包**
- **`mo pack` 是 local 最新快照，不是 handoff 包**

### AI 不可做的事

- 未讀完文件就開始修改程式
- 未更新文件就修改流程、目錄、檔案、指令
- 把 `mo pack` 誤認為 handoff 完成品
- 把使用者上傳的 local pack 直接改名後交回，當成 handoff 包
- 用 `update` 去修 `update` 本身
- 在不記錄原因的情況下刪除系統目錄或重要檔案

### 若 AI 不確定

- **停止修改**
- 明確說明不確定點
- 等待使用者確認

---

## 1. AI 接手時的強制閱讀順序（不可跳）

當使用者說：

> 請依照 `MO_START.md` 接續開發專案

AI 必須先依序閱讀：

1. `MO_START.md`
2. `docs/PROJECT.md`
3. `docs/AI_MEMORY.md`
4. `docs/NEXT_TASK.md`
5. `developer/SCRIPTS_GUIDE.md`

必要時再閱讀：

6. `docs/AI_CONTEXT.md`
7. `developer/MO_DEBUG_GUIDE.md`
8. `docs/update_process.md`
9. `docs/setup.md`

**在完全理解上述文件前，不得修改任何程式碼。**

---

## 2. 唯一入口與唯一操作規則

### 唯一入口文件

- `MO_START.md`

### 唯一人工操作入口

- `mo` CLI

目前建議使用：

```bash
npm run mo -- <command>
```
