import { cpSync, existsSync, mkdirSync, mkdtempSync, renameSync, rmSync, statSync, readdirSync } from 'node:fs';
import { dirname, join, relative, resolve, sep } from 'node:path';
import { tmpdir } from 'node:os';
import { execFileSync } from 'node:child_process';
import { nowTag } from './_util.mjs';

export function ensureDir(path) {
  mkdirSync(path, { recursive: true });
}

export function rotateLatest(outDir, latestName) {
  ensureDir(outDir);
  const bakDir = join(outDir, 'bak');
  ensureDir(bakDir);
  const latestPath = join(outDir, latestName);
  if (existsSync(latestPath)) {
    const archivedName = latestName.replace(/_latest\.zip$/i, `_${nowTag()}.zip`);
    renameSync(latestPath, join(bakDir, archivedName));
  }
}

function stageItems(rootDir, stageDir, items) {
  for (const item of items) {
    const src = join(rootDir, item);
    if (!existsSync(src)) continue;
    const dest = join(stageDir, item);
    cpSync(src, dest, { recursive: true, force: true });
  }
}

async function zipDirectory(stageDir, zipPath) {
  rmSync(zipPath, { force: true });
  if (process.platform === 'win32') {
    const ps = [
      '$ErrorActionPreference = "Stop"',
      'Add-Type -AssemblyName System.IO.Compression.FileSystem',
      `$src = ${JSON.stringify(resolve(stageDir))}`,
      `$zip = ${JSON.stringify(resolve(zipPath))}`,
      'if (Test-Path $zip) { Remove-Item -LiteralPath $zip -Force }',
      '[System.IO.Compression.ZipFile]::CreateFromDirectory($src, $zip)',
    ].join('; ');
    execFileSync('powershell', ['-NoProfile', '-Command', ps], { stdio: 'inherit' });
    return;
  }
  execFileSync('zip', ['-qr', resolve(zipPath), '.'], { cwd: stageDir, stdio: 'inherit' });
}

export async function createZip(rootDir, zipPath, items) {
  ensureDir(dirname(zipPath));
  const stageDir = mkdtempSync(join(tmpdir(), 'mo-zip-'));
  try {
    stageItems(rootDir, stageDir, items);
    await zipDirectory(stageDir, zipPath);
    const st = statSync(zipPath);
    if (!st.size) throw new Error('zip created but empty');
    return st.size;
  } finally {
    rmSync(stageDir, { recursive: true, force: true });
  }
}

export function extractZip(zipPath, outDir) {
  rmSync(outDir, { recursive: true, force: true });
  ensureDir(outDir);
  if (process.platform === 'win32') {
    const ps = [
      '$ErrorActionPreference = "Stop"',
      'Add-Type -AssemblyName System.IO.Compression.FileSystem',
      `$zip = ${JSON.stringify(resolve(zipPath))}`,
      `$out = ${JSON.stringify(resolve(outDir))}`,
      'if (Test-Path $out) { Remove-Item -LiteralPath $out -Recurse -Force }',
      'New-Item -ItemType Directory -Path $out -Force | Out-Null',
      '[System.IO.Compression.ZipFile]::ExtractToDirectory($zip, $out)',
    ].join('; ');
    execFileSync('powershell', ['-NoProfile', '-Command', ps], { stdio: 'inherit' });
  } else {
    execFileSync('unzip', ['-q', zipPath, '-d', outDir], { stdio: 'inherit' });
  }
}

export function countFilesRecursive(dir) {
  if (!existsSync(dir)) return 0;
  let total = 0;
  for (const name of readdirSync(dir)) {
    const full = join(dir, name);
    const st = statSync(full);
    if (st.isDirectory()) total += countFilesRecursive(full);
    else total += 1;
  }
  return total;
}
