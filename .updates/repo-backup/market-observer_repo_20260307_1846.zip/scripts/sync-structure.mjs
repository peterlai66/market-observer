#!/usr/bin/env node
import { mkdirSync, existsSync, writeFileSync, rmSync } from 'node:fs';
import { join, resolve } from 'node:path';

const root = resolve('.');
const dirs = [
  '.updates/inbox',
  '.updates/outbox',
  '.updates/outbox/bak',
  '.updates/bak',
  '.updates/work',
  '.updates/history',
  '.updates/repo-backup',
  'docs/architecture',
  'developer',
];
const deprecatedDirs = [
  '.updates/outbox/dev',
  '.updates/outbox/patch',
  '.updates/outbox/release',
  '.updates/outbox/handoff',
  '.updates/outbox/dev/bak',
  '.updates/outbox/patch/bak',
  '.updates/outbox/release/bak',
  '.updates/outbox/handoff/bak',
  '.updates/backup',
];
for (const dir of dirs) {
  const p = join(root, dir);
  mkdirSync(p, { recursive: true });
  const keep = join(p, '.gitkeep');
  if (!existsSync(keep)) writeFileSync(keep, '');
}
for (const dir of deprecatedDirs) {
  const p = join(root, dir);
  if (existsSync(p)) rmSync(p, { recursive: true, force: true });
}
const updatesReadme = join(root, '.updates', 'README.md');
if (!existsSync(updatesReadme)) {
  writeFileSync(updatesReadme, `# .updates directory contract

- inbox/: incoming patch / release package waiting for mo patch / mo update
- work/: temporary extraction and staging area
- bak/: archive of consumed patch / release packages
- repo-backup/: repository snapshot before patch / update
- outbox/: generated dev / patch / release / handoff artifacts (distinguished by filename only)
- outbox/bak/: archived previous *_latest.zip artifacts
- history/: update history and operation records
`);
}
console.log('Structure synced.');
