## 0.8.0
- fix(toolchain): CLI 補回 `mo smoke`、`mo smoke-worker`，並將 `mo deploy` / `mo logs` 改為直接走 `npx wrangler ...`。
- fix(toolchain): Windows 下改由 `cmd.exe` 呼叫 `npm` / `npx` / `.cmd`，避免 `spawnSync npm.cmd EINVAL`。
- refactor(toolchain): `.updates/outbox/` 改為單一根目錄，dev / patch / release / handoff 全部靠檔名辨識。
- fix(update): `patch` / `update` / `sync-structure` / `smoke` 會自動清理 `.updates/backup` 與已廢除的 `.updates/outbox/*` 舊子目錄。
- docs(process): 同步更新 `MO_START.md`、`docs/commands.md`、`docs/update_process.md`、`developer/SCRIPTS_GUIDE.md`、`.updates/README.md`、`docs/PROJECT.md`、`docs/AI_MEMORY.md`、`docs/NEXT_TASK.md`、`docs/HANDOFF_NOTES.md`。

## 0.7.5-handoff
- fix(toolchain): `_util.run()` now throws on process spawn errors.
- feat(toolchain): add `smoke:worker` and document when to run it.
- docs(handoff): sync deploy flow, D0~D19 semantics, current runtime status, unresolved items.
