# .updates directory contract

Do not delete folders unless documentation explicitly says it is safe.

## folders
- `inbox/`：等待套用的 patch / release 包
- `work/`：patch / update 解壓工作區
- `bak/`：已套用的 patch / release 歷史
- `repo-backup/`：patch / update 前的備份快照
- `outbox/`：dev / patch / release / handoff 輸出，全部以檔名區分
- `outbox/bak/`：上一份 `*_latest.zip` 的歸檔
- `history/`：patch / update / handoff 執行紀錄

## note
- `backup/` 已 deprecated，不可再新增回來
- `outbox/dev`、`outbox/patch`、`outbox/release`、`outbox/handoff` 已 deprecated，成功 patch / update 後應自動清理
- 修工具鏈時應優先走 `patch`
- `mo pack` 的預期輸出位置是 `.updates/outbox/market-observer_dev_latest.zip`
- handoff 包檔名使用 `mo_handoff_YYYYMMDD_HHMM.zip`，但仍放在 `.updates/outbox/` 根目錄
