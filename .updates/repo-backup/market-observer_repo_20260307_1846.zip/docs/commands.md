# Commands

## 推薦用法
- `npm run mo -- doctor`
- `npm run mo -- smoke`
- `npm run mo -- smoke-worker`
- `npm run mo -- logs`
- `npm run mo -- deploy`
- `npm run mo -- pack`
- `npm run mo -- patch`
- `npm run mo -- release`
- `npm run mo -- update`
- `npm run mo -- upgrade`（`update` 別名）

## 說明
- `doctor`：檢查 repo 結構與必要目錄
- `smoke`：在暫存 repo 驗證 pack / patch / release / update 流程與 deprecated cleanup
- `smoke-worker`：驗證 Worker typecheck 與 `wrangler deploy --dry-run`
- `logs`：追 Cloudflare Workers logs
- `deploy`：部署 Worker
- `pack`：把 local 最新專案打包成 `.updates/outbox/market-observer_dev_latest.zip`
- `patch`：吃 `.updates/inbox/market-observer_patch_latest.zip`，只更新工具鏈與文件
- `release`：產出 `.updates/outbox/market-observer_release_latest.zip`
- `update`：吃 `.updates/inbox/market-observer_release_latest.zip`，建立 backup、套用到 repo root、歸檔到 `.updates/bak/`
- `upgrade`：相容別名，行為同 `update`

## 重要規則
- 所有 zip 一律輸出到 `.updates/outbox/` 根目錄，不再使用 `outbox/dev`、`outbox/release`、`outbox/handoff`、`outbox/patch`。
- 交付前如果有改到 toolchain，必須同步更新文件，不能只改程式。