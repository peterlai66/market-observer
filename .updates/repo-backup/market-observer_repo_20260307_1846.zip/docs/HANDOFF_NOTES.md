# HANDOFF NOTES

## 本次已補齊
- `mo smoke` / `mo smoke-worker` 正式接回 CLI。
- `mo deploy` / `mo logs` 改成直接走 `npx wrangler ...`，避開 Windows `npm.cmd` 問題。
- `_util.run()` 改為在 Windows 透過 `cmd.exe` 呼叫 `npm` / `npx` / `.cmd`，避免 `spawnSync npm.cmd EINVAL`。
- `.updates/outbox/` 收斂成單一根目錄，並把 dev / patch / release / handoff 全部改為用檔名辨識。
- `patch` / `update` / `sync-structure` / `smoke` 已納入 deprecated 目錄清理。
- 同步更新 `MO_START.md`、`docs/PROJECT.md`、`docs/AI_MEMORY.md`、`docs/NEXT_TASK.md`、`docs/commands.md`、`docs/update_process.md`、`developer/SCRIPTS_GUIDE.md`、`.updates/README.md`。

## 目前已知狀態
- local toolchain：`update` / `smoke` / `deploy` 可用。
- Worker：可 deploy、cron 有跑、latest_trade_date 可查。
- 線上功能缺口：daily summary 深化、strategy / orders / simulator 尚未完成。

## 仍未完成 / 待下一個 AI 接續
1. daily summary 與最近交易日摘要補寫流程。
2. strategy / orders / simulator 後續功能。
3. 若之後再調整 `.updates` 結構，必須把 migration cleanup 規則同步寫入文件與 smoke。