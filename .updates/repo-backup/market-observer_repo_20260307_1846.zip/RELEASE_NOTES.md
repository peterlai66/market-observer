## 0.8.0
- `mo smoke` / `mo smoke-worker` 正式回到 CLI，`mo deploy` / `mo logs` 直接走 `npx wrangler ...`。
- Windows toolchain 改為透過 `cmd.exe` 呼叫 `npm` / `npx` / `.cmd`，避免 `spawnSync npm.cmd EINVAL`。
- `.updates/outbox/` 現在只保留單一根目錄；dev / patch / release / handoff 一律靠檔名區分。
- `patch` / `update` 會自動清掉舊的 `outbox/dev`、`outbox/release`、`outbox/handoff`、`outbox/patch` 與 `.updates/backup`。
- 同步補齊版本、文件與交付規則，避免只改程式不改文件。
