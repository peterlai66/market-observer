## 0.8.5
- 強化 CLI 自我防錯：新增 `mo validate-artifacts` / `mo validate`，可檢查 `.updates/outbox/` 是否仍有 deprecated 子目錄，以及 release 檔名是否固定為 `market-observer_release_latest.zip`。
- `mo smoke` 現在會在 release 打包後自動執行 artifact validation，避免再次出現交付檔名不符合 `mo update` 契約而導致更新失敗。
- `doctor` 現在會把 `.updates/outbox/dev`、`patch`、`release`、`handoff` 視為錯誤，讓結構回退能更早被發現。
- 建議功能版交付前驗證順序：`npm run mo -- release` → `npm run mo -- validate-artifacts` → `npm run mo -- smoke`。

## 0.8.4
- 新增策略除錯可視化：建立 `mo_strategy_debug`，記錄每次 recommendation run 的 candidate / selected / rejected。
- LINE 新增 `debug / 除錯` 指令，deploy 後可直接驗證 universe 來源、candidate 數、recs 數，以及前幾名候選與被擋原因。
- 本版主軸不是放寬策略，而是先把 `candidate_count > 0 但 rec_count = 0` 的原因透明化。
- 建議 deploy 後驗證：`狀態`、`建議`、`debug`，必要時查 D1 `mo_strategy_debug`。

## 0.8.3
- 修正 ETF universe 只在 `topByValue` 內過濾，導致明明 D1 有 `etf_universe`，策略仍可能 `done 0/0` 的問題。
- 每日推薦現在會優先讀取 D1 `etf_universe enabled=1`，並從當日 `stocksAll` 快照找可交易候選。
- 修正 `mo_recommendation_log` 舊 schema 與 runtime 寫入欄位不一致的問題，並讓 `狀態` 可回讀 legacy log。
- 建議 deploy 後用 LINE 傳：`universe`、`狀態`、`建議` 驗證；必要時再查 D1 `mo_orders` / `mo_recommendation_log`。

# Release Notes

## 0.8.2
- MO 多標的推薦正式加入預設 ETF universe，預設池為：0050、006208、0056、00878、00919。
- 可用 `MO_UNIVERSE` 覆寫標的池；若當日 ETF 池沒有快照，系統才會回退用成交值排行補位。
- 新增 recommendation log，狀態查詢會看到最新建議日期、signal、標的池來源與建議筆數。
- LINE 新增 `universe / 標的池` 指令，可直接查看目前使用中的 ETF 池。
- 本版延續 0.8.1 CLI foundation，主軸回到 MO 策略本體。
