# BUG TRACKER

## Open Bugs

### BUG-20260307-04
- Title: Universe candidates are generated, but final recommendation selection returns zero recommendations.
- Status: Open in 0.8.4
- Evidence: `mo_recommendation_log` shows `candidate_count > 0` with `rec_count = 0`; LINE 顯示「明日建議：不動（無明顯機會）」。
- Current mitigation: 0.8.4 新增 `mo_strategy_debug` 與 LINE `debug / 除錯`，先讓被擋原因可觀測。
- Next action: 依 debug 結果決定要調整 threshold、budget gate、qty gate 或 signal gate。

## Fixed Bugs

### BUG-20260307-05
- Title: Release artifact delivered with a versioned filename instead of `market-observer_release_latest.zip`, causing `mo update` to fail.
- Status: Fixed in 0.8.5
- Resolution: 新增 `scripts/validate-artifacts.mjs`、`mo validate-artifacts`，並讓 smoke 在 release 後強制驗證 artifact 命名與 outbox 結構。
- Verification: `npm run mo -- release` 後執行 `npm run mo -- validate-artifacts`；若出現非 `market-observer_release_latest.zip` 的 release 檔或 deprecated outbox 子目錄，流程會失敗。

### BUG-20260307-03
- Title: `etf_universe` exists in D1, but strategy engine only filtered `topByValue`, causing `done 0/0` and no new recommendations.
- Status: Fixed in 0.8.3
- Resolution: universe 來源改為優先讀 D1 `etf_universe(enabled=1)`，並從 `stocksAll` 全量快照建立 universe 候選，不再只在 `topByValue` 內找。
- Verification: deploy 後可用 LINE `universe` / `狀態` / `建議` 與 D1 `mo_orders`、`mo_recommendation_log` 驗證。

### BUG-20260307-02
- Title: `mo_recommendation_log` runtime schema drift with existing migration / legacy logs.
- Status: Fixed in 0.8.3
- Resolution: `ensureMultiAssetTables` 會補齊 recommendation log 缺欄位；`狀態` 查詢可兼容 legacy schema 與 `recommendation_log`。
- Verification: `狀態` 不再因 log schema 差異失敗；新 tick 後可查到最新 recommendation log。

### BUG-20260307-01
- Title: Deprecated outbox subdirectories not fully removed from local repo
- Status: Fixed in 0.8.1
- Resolution: `apply-update` / `apply-patch` / `sync-structure` 現在會清理 `.updates/outbox/dev`、`.updates/outbox/release`、`.updates/outbox/handoff`、`.updates/outbox/patch`，並以單一 `.updates/outbox/` 結構為準。
- Verification: 使用者在 0.8.1 實測 `mo update` 後，本機 repo 已顯示 cleanup removed 並成功 `mo smoke` / `mo deploy`。

## Regression Guards
- All newly discovered bugs must be recorded here.
- Bug fixes must update status and mention the bug ID in CHANGELOG / RELEASE_NOTES when relevant.
- Release validation is based on the real package after `mo update`, not on chat claims.
