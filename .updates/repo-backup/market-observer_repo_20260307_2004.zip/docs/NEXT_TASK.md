# NEXT TASK

## Current baseline
- Stable base: 0.8.4
- CLI / toolchain baseline is stable after 0.8.1
- Universe is now consumed by engine (0.8.3)
- Strategy debug observability added (0.8.4)

## Immediate next task
1. Use LINE `debug / 除錯` and D1 `mo_strategy_debug` to identify why candidates are rejected.
2. Decide whether to adjust signal gate, budget gate, qty gate, or scoring threshold.
3. Keep release validation with `update -> smoke -> deploy`, then verify via LINE `狀態 / 建議 / debug`.
