import type { Env } from '../index';
import { buildAiSystemPrompt, buildAiUserPrompt, type AiExplainKind } from './prompt';

const OPENAI_RESPONSES_URL = 'https://api.openai.com/v1/responses';

function pickModel(env: Env): string {
	const raw = String(env.OPENAI_MODEL ?? '').trim();
	return raw || 'gpt-5-mini';
}

function extractOutputText(data: any): string {
	if (typeof data?.output_text === 'string' && data.output_text.trim()) return data.output_text.trim();
	const output = Array.isArray(data?.output) ? data.output : [];
	const texts: string[] = [];
	for (const item of output) {
		const content = Array.isArray(item?.content) ? item.content : [];
		for (const part of content) {
			if (typeof part?.text === 'string' && part.text.trim()) texts.push(part.text.trim());
			if (typeof part?.output_text === 'string' && part.output_text.trim()) texts.push(part.output_text.trim());
		}
	}
	return texts.join('\n').trim();
}

function safeText(v: unknown): string {
	return String(v ?? '').replace(/\s+/g, ' ').trim();
}

async function ensureAiAuditTable(env: Env): Promise<void> {
	await env.DB.prepare(`
		CREATE TABLE IF NOT EXISTS mo_ai_audit (
			id INTEGER PRIMARY KEY AUTOINCREMENT,
			called_at TEXT NOT NULL,
			kind TEXT NOT NULL,
			model TEXT NOT NULL,
			request_id TEXT,
			ok INTEGER NOT NULL DEFAULT 0,
			status_code INTEGER,
			duration_ms INTEGER,
			response_chars INTEGER,
			error TEXT,
			response_preview TEXT
		)
	`).run();
}

async function writeAiAudit(
	env: Env,
	entry: {
		calledAt: string;
		kind: AiExplainKind;
		model: string;
		requestId?: string;
		ok: boolean;
		statusCode?: number;
		durationMs?: number;
		responseChars?: number;
		error?: string;
		responsePreview?: string;
	},
): Promise<void> {
	try {
		await ensureAiAuditTable(env);
		await env.DB.prepare(
			`INSERT INTO mo_ai_audit (called_at, kind, model, request_id, ok, status_code, duration_ms, response_chars, error, response_preview)
			 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
		)
			.bind(
				entry.calledAt,
				entry.kind,
				entry.model,
				entry.requestId || null,
				entry.ok ? 1 : 0,
				entry.statusCode ?? null,
				entry.durationMs ?? null,
				entry.responseChars ?? null,
				entry.error ? safeText(entry.error).slice(0, 500) : null,
				entry.responsePreview ? safeText(entry.responsePreview).slice(0, 500) : null,
			)
			.run();
	} catch (e: any) {
		console.warn(`[AI] audit write failed kind=${entry.kind} msg=${safeText(e?.message || e).slice(0, 200)}`);
	}
}

export async function generateAiExplanation(
	env: Env,
	kind: AiExplainKind,
	payload: Record<string, unknown>,
): Promise<string> {
	const model = pickModel(env);
	const calledAt = new Date().toISOString();
	const startedAt = Date.now();
	if (!env.OPENAI_API_KEY) {
		await writeAiAudit(env, {
			calledAt,
			kind,
			model,
			ok: false,
			error: 'OPENAI_API_KEY not set',
			durationMs: 0,
		});
		throw new Error('OPENAI_API_KEY not set');
	}

	const timeoutMs = 2200;
	const ac = new AbortController();
	const timer = setTimeout(() => ac.abort(`timeout ${timeoutMs}ms`), timeoutMs);
	console.log(`[AI] call start kind=${kind} model=${model}`);

	try {
		const res = await fetch(OPENAI_RESPONSES_URL, {
			method: 'POST',
			headers: {
				'content-type': 'application/json',
				authorization: `Bearer ${env.OPENAI_API_KEY}`,
			},
			body: JSON.stringify({
				model,
				input: [
					{
						role: 'system',
						content: [{ type: 'input_text', text: buildAiSystemPrompt() }],
					},
					{
						role: 'user',
						content: [{ type: 'input_text', text: buildAiUserPrompt(kind, payload) }],
					},
				],
				text: {
					format: { type: 'text' },
				},
			}),
			signal: ac.signal,
		});

		const durationMs = Date.now() - startedAt;
		if (!res.ok) {
			const body = await res.text();
			const requestId = safeText(res.headers.get('x-request-id')) || undefined;
			console.warn(`[AI] call fail kind=${kind} model=${model} status=${res.status} durationMs=${durationMs}`);
			await writeAiAudit(env, {
				calledAt,
				kind,
				model,
				requestId,
				ok: false,
				statusCode: res.status,
				durationMs,
				error: `OpenAI responses failed: ${res.status} ${body.slice(0, 240)}`,
				responsePreview: body.slice(0, 240),
			});
			const err: any = new Error(`OpenAI responses failed: ${res.status} ${body.slice(0, 240)}`);
			err.__aiAudited = true;
			throw err;
		}

		const data = (await res.json()) as any;
		const text = extractOutputText(data);
		const requestId = safeText(data?.id || res.headers.get('x-request-id')) || undefined;
		if (!text) {
			console.warn(`[AI] call fail kind=${kind} model=${model} status=${res.status} durationMs=${durationMs} empty_output=1`);
			await writeAiAudit(env, {
				calledAt,
				kind,
				model,
				requestId,
				ok: false,
				statusCode: res.status,
				durationMs,
				error: 'OpenAI responses returned empty text',
			});
			const err: any = new Error('OpenAI responses returned empty text');
			err.__aiAudited = true;
			throw err;
		}

		console.log(`[AI] call ok kind=${kind} model=${model} status=${res.status} durationMs=${durationMs} chars=${text.length}`);
		await writeAiAudit(env, {
			calledAt,
			kind,
			model,
			requestId,
			ok: true,
			statusCode: res.status,
			durationMs,
			responseChars: text.length,
			responsePreview: text.slice(0, 240),
		});
		return text;
	} catch (e: any) {
		const durationMs = Date.now() - startedAt;
		const isAbort = String(e?.name || '') === 'AbortError' || String(e?.message || '').includes('timeout');
		const msg = isAbort ? `OpenAI responses timeout after ${timeoutMs}ms` : String(e?.message || e);
		console.warn(`[AI] call fail kind=${kind} model=${model} durationMs=${durationMs} msg=${safeText(msg).slice(0, 200)}`);
		if (!e?.__aiAudited) {
			await writeAiAudit(env, {
				calledAt,
				kind,
				model,
				ok: false,
				durationMs,
				error: msg,
			});
		}
		throw new Error(msg);
	} finally {
		clearTimeout(timer);
	}
}
