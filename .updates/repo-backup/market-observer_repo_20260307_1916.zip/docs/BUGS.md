# BUG TRACKER

## Open Bugs
- None.

## Fixed Bugs

### BUG-20260307-01
- Title: Deprecated outbox subdirectories not fully removed from local repo
- Status: Fixed in 0.8.1
- Resolution: `apply-update` / `apply-patch` / `sync-structure` 現在會清理 `.updates/outbox/dev`、`.updates/outbox/release`、`.updates/outbox/handoff`、`.updates/outbox/patch`，並以單一 `.updates/outbox/` 結構為準。
- Verification: 使用者在 0.8.1 實測 `mo update` 後，本機 repo 已顯示 cleanup removed 並成功 `mo smoke` / `mo deploy`。

## Regression Guards
- All newly discovered bugs must be recorded here.
- Bug fixes must update status and mention the bug ID in CHANGELOG / RELEASE_NOTES when relevant.
- Release validation is based on the real package after `mo update`, not on chat claims.
