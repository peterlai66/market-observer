# NEXT TASK

## Priority 1 — Daily Summary / Query
1. 讓 `昨日報告 / report` 在非交易日可自動補查最近交易日摘要；若摘要缺失，先補生成再回覆。
2. `status` 再補上最新 summary 日期、latest trade date 與 ready level 的對照，方便線上驗證。

## Priority 2 — Strategy / Orders
1. 以 ETF universe 為基礎，補上更明確的倉位規則（單檔上限、現金保留、分批進場）。
2. `mo_orders (PENDING)` 補上更完整的原因摘要：市場方向、alpha score、是否為 fallback。
3. 將 recommendation log 與 order execution 串起來，能追蹤 D0~D19 每日結果。

## Priority 3 — Simulation / Review
1. 補充模擬成交回顧查詢（例如最近 5 筆 EXECUTED / SKIPPED）。
2. 盤後推播增加「今天用了哪個 universe、是否 fallback」的摘要。
