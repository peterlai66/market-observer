# Release Notes

## 0.8.2
- MO 多標的推薦正式加入預設 ETF universe，預設池為：0050、006208、0056、00878、00919。
- 可用 `MO_UNIVERSE` 覆寫標的池；若當日 ETF 池沒有快照，系統才會回退用成交值排行補位。
- 新增 recommendation log，狀態查詢會看到最新建議日期、signal、標的池來源與建議筆數。
- LINE 新增 `universe / 標的池` 指令，可直接查看目前使用中的 ETF 池。
- 本版延續 0.8.1 CLI foundation，主軸回到 MO 策略本體。
