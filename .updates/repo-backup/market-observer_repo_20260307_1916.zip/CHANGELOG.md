## 0.8.2 - 2026-03-07
- Strategy: 新增預設 ETF universe（0050 / 006208 / 0056 / 00878 / 00919），多標的推薦優先在 ETF 池內挑選。
- Strategy: 支援 `MO_UNIVERSE` 覆寫標的池；當日若 universe 無快照，才回退到成交值排行，避免推薦流程中斷。
- Worker: 新增 `mo_recommendation_log`，記錄 signal、universe 來源、candidate 數、recommendation 數與 fallback 狀態。
- LINE: 新增 `universe / 標的池` 查詢，`狀態` 也會顯示最新 recommendation log。
- Docs: 同步更新 `MO_START.md`、`docs/PROJECT.md`、`docs/AI_MEMORY.md`、`docs/NEXT_TASK.md`、`docs/BUGS.md`、`RELEASE_NOTES.md`。

## 0.8.1
- fix(cli): restore stable `mo smoke` / `mo smoke-worker` commands and make `mo deploy` / `mo logs` call `npx wrangler ...` directly.
- fix(toolchain): move dev / patch / release latest zip outputs to `.updates/outbox/` root and archive prior latest artifacts in `.updates/outbox/bak/`.
- fix(migration): `sync-structure`, `apply-patch`, and `apply-update` now remove deprecated `.updates/backup` and deprecated outbox subdirectories from the actual repo.
- docs(process): add `docs/BUGS.md`, record BUG-20260307-01, and sync MO_START / commands / update process / project docs for the CLI foundation baseline.

## 0.7.5-handoff
- fix(toolchain): `_util.run()` now throws on process spawn errors.
- feat(toolchain): add `smoke:worker` and document when to run it.
- docs(handoff): sync deploy flow, D0~D19 semantics, current runtime status, unresolved items.

# 0.6.9

- Fix: `smoke:tools` now reuses source `node_modules` instead of running nested `npm install` in the sandbox, avoiding Windows npm CLI failures.

# 0.6.8

- Add toolchain smoke test script for pack / patch / release / update workflow.
- Fix doctor success output and patch cleanup import.
- Normalize generated zip entry paths for cross-platform compatibility.

# 0.5.4

- Fix: TWSE not-ready no longer blocks order generation; avoid clearing seeded PENDING orders when snapshot missing.
- Fix: Correct index direction using TWSE sign.

# Changelog

## v0.4.2-hotfix.1 — TWSE trade date fallback

- Fixed: When TWSE FMTQIK has no trade date (or API returns empty/changed schema), treat as NOT READY instead of throwing hard error. Writes status into mo_daily_mark.
## v0.4.2 (2026-03-05)

### Added
- D1 runtime audit tables (via migration `0005_add_runtime_audit_tables.sql`)
  - `mo_tick_audit` (tick dispatcher audit + de-dupe lock)
  - `mo_daily_mark` (daily market-data readiness + push markers)
  - `mo_execution_mark` (simulation / execution audit)

### Improved
- Tick dispatcher writes audit rows to `mo_tick_audit` and skips duplicates safely.
- `mo status` shows **health** by reading the latest audit rows from remote D1.

### Changed
- Cron trigger switched to a **global 15-minute heartbeat**: `*/15 * * * *` (market logic stays in code).

## 0.6.1
- 修正 mo pack / mo update 的命名與流程語意
- `mo pack` 改為輸出 `.updates/outbox/mo_local_latest.zip`
- `mo update` 對齊 `.updates/inbox/market-observer_release_latest.zip` → `.updates/bak/` → `.updates/work/` 流程
- 新增 `manifest.json`、`VERSION`、`docs/update_process.md`、`docs/setup.md`
- handoff 規則明確化：AI 需比對聊天室規則與 repo 差異後再產出 `mo_handoff*.zip`
