# HANDOFF NOTES

## Project identity
- Project: Market Observer (MO)
- Lockdown baseline version inside this package: 0.19.0
- System role: Market Observer / Recommendation + Simulation + Review pipeline

## Verified deployed behavior before handoff
Latest validated remote behavior from user logs:
- `/admin/run?force=1` resolves `tradeDate=2026-03-13` correctly
- `REPORT_GATE` is active
- `PUSH_GATE` is active
- `RECOMMENDATION_GATE` is active
- current bug: `reportStatus=SOURCE_DELAY reason=latest_trade_date=2026-03-13` even though all major sources already reached `2026-03-13`
- current bug: review / latest review display can still reference older checkpoint dates such as `2026-03-06`

## Current confirmed issues to carry forward
1. **Report validator bug**
   - Bug: validator treats `tradeDate == latest completed trading date` as `SOURCE_DELAY`
   - Correct logic:
     - weekday after market close: if all required sources are aligned to the latest completed trading date, `reportStatus=VALID`
     - weekend / non-trading day: if latest completed trading date is already complete, `reportStatus=VALID`

2. **Report header / summary reference date**
   - Current LINE report may show current calendar date even when some fields are still sourced from the latest completed trading date
   - Should show a clearer header such as `資料截至 YYYY-MM-DD` when needed

3. **Review horizon bug**
   - Current review progress can remain pinned at D1 / old review date
   - Expected behavior: auto-advance review horizon based on trading days since recommendation date

4. **Admin response state sync**
   - Ensure `/admin/run` response fields always reflect final gate result, especially `summary / rec / actionable / reportStatus / recStatus`

## Current versioning policy (must follow)
- Use Semantic Versioning strictly
- This package is `0.19.0` baseline
- Next version for the above fixes must be `0.19.1` because they are bug fixes, not new features
- Do not jump or keep blindly incrementing patch versions without meaning

## Release / baseline workflow
- Always develop from the uploaded `market-observer_dev_latest.zip`
- Never trust assistant-side temporary state over the uploaded baseline
- If baseline certainty is lost, ask the user to run `mo pack` and upload a fresh dev package
- Release artifact must be exactly `market-observer_release_latest.zip` unless the user explicitly asks for handoff

## Recommended next task
Target next version: 0.19.1

Required fixes:
- Fix report validator so `latest completed trading date` is accepted as VALID
- Fix report header date / `資料截至` behavior
- Fix review horizon auto progression
- Keep gates active and consistent with admin response fields

## New-window continuation instruction
Upload this handoff zip in the new chat, then send:

`讀取檔案中的 MO_START.md 繼續專案；以這份 handoff 包內的 0.19.0 baseline 為準，先修 0.19.1：report validator、report header、review horizon，並遵守 docs/HANDOFF_NOTES.md 的版本規則與 baseline 規則。`
