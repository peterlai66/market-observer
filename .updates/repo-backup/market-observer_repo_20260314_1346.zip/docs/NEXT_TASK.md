## 0.19.2 next
- Deploy and verify 0.19.1 on remote `/admin/run?force=1`, confirming `reportStatus=VALID` when sources align to the latest completed trading date.
- Re-run `npm run mo -- recommendation-review-save` on remote once enough future trade dates are available, so live-projected review horizon becomes persisted item-level review output.
- Verify LINE `最新報告` header and operator narration against weekday-before-close, weekday-after-close, and weekend scenarios.
- Re-check `/admin/run` response text so `summary / rec / actionable / reportStatus / recStatus` always match the final gate outcome.
