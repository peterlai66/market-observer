# PROJECT

## Current state
- CLI / update / smoke / deploy pipeline stable
- ETF universe comes from env -> D1 -> default fallback
- Multi-asset engine now generates candidates from universe snapshots
- 0.9.0 adds conservative starter fallback so the system can move from pure observation to actionable recommendations
- LINE commands for operational verification: 狀態 / 建議 / debug / universe
