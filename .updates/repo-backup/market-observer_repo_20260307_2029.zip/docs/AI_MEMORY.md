# AI MEMORY

- 0.8.1 established the stable CLI/toolchain baseline.
- 0.8.3 connected D1 `etf_universe` to the strategy engine.
- 0.8.4 added `mo_strategy_debug` and LINE `debug / 除錯`.
- 0.8.5 added artifact validation to prevent release naming regressions.
- 0.9.0 adds snapshot backfill + starter fallback so candidate-rich days no longer stall at `recs=0` without visibility.
