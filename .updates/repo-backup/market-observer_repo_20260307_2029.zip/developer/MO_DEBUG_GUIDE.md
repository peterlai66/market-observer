# MO DEBUG GUIDE

## update / patch 自檢
成功時至少要檢查：
- `.updates/repo-backup/` 有新增非空 zip
- `.updates/bak/` 有新增已吃掉的 package
- `.updates/history/` 有新增 json 記錄
- 終端機有成功摘要

若 `VERSION` 改了但上述三者沒有新增，不能視為 update 成功。


## Strategy debug (0.8.4)
- LINE: `debug` / `除錯`
- D1: `SELECT * FROM mo_strategy_debug ORDER BY id DESC LIMIT 20;`
- Purpose: explain why candidates were selected or rejected in the latest run.


## 0.9.0
- Use LINE `debug` first.
- If needed, inspect `mo_strategy_debug` in D1.
- `starter_fallback` means the engine saw candidates but normal gates still produced zero recs, so it opened an observation-style recommendation.
