# Release Notes

## 0.10.1
- 修正 MO 重複建單：同 `signal_date + symbol + side` 不再因重跑 `/admin/run` 一直新增 `PENDING`。
- `mo_recommendation_log.note` 新增 `inserted` / `deduped` 統計，驗證去重更直觀。
- `executePendingOrders()` 會把 `SKIPPED / EXECUTED` 寫入 `mo_execution_mark`，方便追蹤 pending 單後續處理結果。

## 驗證重點
1. 連跑兩次 `/admin/run?token=...&force=1`。
2. `mo_orders` 不應再出現同日重複新單。
3. `mo_recommendation_log.note` 應出現 `inserted=0|deduped=3` 類似字樣。
4. `mo_execution_mark` 應可看到 `filled=0/1` 的執行結果。
