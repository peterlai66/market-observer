
# Portfolio Closed-Loop Verification Queries

Use these queries after each `/admin/run` execution cycle.

## Orders
SELECT id, signal_date, symbol, side, status
FROM mo_orders
ORDER BY id DESC
LIMIT 20;

## Execution Marks
SELECT id, signal_date, trade_date, symbol, side, qty, filled
FROM mo_execution_mark
ORDER BY id DESC
LIMIT 20;

## Portfolio State
SELECT id, principal_twd, cash_twd, updated_at
FROM mo_portfolio_state
ORDER BY id DESC
LIMIT 5;

Purpose:
Verify the transition chain:

signals -> orders -> execution_mark -> portfolio_state
