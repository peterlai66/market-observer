## 0.10.1
- fix(mo): `persistRecommendations()` 改為同交易日 / 同 symbol / 同 side 去重寫入，不再因重跑 `/admin/run` 重複建立 `PENDING` 單。
- fix(exec): `executePendingOrders()` 現在會把 `SKIPPED` 與 `EXECUTED` 結果寫入 `mo_execution_mark`，方便驗證成交閉環。
- docs: 同步更新 `RELEASE_NOTES.md`、`docs/PROJECT.md`、`docs/BUGS.md`、`docs/NEXT_TASK.md`、`docs/AI_MEMORY.md`。

## 0.10.0
- 進入成交閉環第一階段：推薦與模擬成交都加入最低交易數量、最低名目金額與交易成本檢查，避免小額下單被手續費與稅費吃掉。
- BUY recommendation 現在會依市場套用最小下單量（TW ETF 100 股起）與最小交易金額門檻；若不符合，會在 `debug` / `mo_strategy_debug` 中明確標示 `qty_too_small`、`notional_too_small`、`edge_lt_cost`。
- 模擬成交（`executePendingOrders`）現在會把買進手續費、賣出手續費、ETF 賣出交易稅與保守滑價一起計入現金流，避免帳面成交但資金計算過度樂觀。
- `明日建議` 原因與 `debug` 選中原因會一起顯示成本摘要（`notional / cost`），讓你直接看到這筆單是否值得做。
- 本版主修：把「有建議但交易成本不合理」變成可觀測、可過濾、可追蹤的規則，而不是靠人工判斷。

## 0.9.1 - 2026-03-07
- strategy: fix TW ETF recommendation close-price mapping by resolving close from raw close / OHLC fallback / candidate fallback before final order selection.
- debug: include `px=<source>` in candidate lines and show `missing_close` / `invalid_close` with concrete price source for easier diagnosis.
- docs: sync `RELEASE_NOTES.md`, `docs/BUGS.md`, `docs/NEXT_TASK.md`, `docs/PROJECT.md`, `docs/AI_MEMORY.md`, `docs/commands.md`, `MO_START.md`, `developer/MO_DEBUG_GUIDE.md` for the 0.9.1 price-mapping fix.

## 0.9.0 - 2026-03-07
- feat(strategy): recommendation engine now uses a more resilient universe snapshot builder that backfills `close / chg / value` from parsed price maps and top-by-value rows, reducing `invalid_close` false negatives.
- feat(strategy): add conservative `starter_fallback` logic — when market signal is `TRY/AGGRESSIVE`, candidates exist, but normal selection still yields zero recommendations, the engine will create a small observation position instead of returning `0 recs`.
- feat(runtime): `buildStatusText` / `buildLatestRecs` / `buildStrategyDebugText` now call `ensureMultiAssetTables`, so debug/recommendation tables can self-heal even when remote D1 migrations lag behind.
- docs: sync `RELEASE_NOTES.md`, `docs/BUGS.md`, `docs/NEXT_TASK.md`, `docs/PROJECT.md`, `docs/AI_MEMORY.md`, `docs/commands.md`, `MO_START.md`, `developer/MO_DEBUG_GUIDE.md` for the 0.9 strategy baseline.

## 0.8.5 - 2026-03-07
- feat(toolchain): 新增 `scripts/validate-artifacts.mjs` 與 `mo validate-artifacts` / `mo validate`，用來檢查 release 交付物命名與 outbox 結構。
- feat(smoke): `mo smoke` 現在會在 release 打包後執行 artifact validation，避免再次交付錯誤檔名或殘留 deprecated outbox 子目錄。
- fix(doctor): `doctor` 現在會把 `.updates/outbox/dev|patch|release|handoff` 視為錯誤，不再只是警告。
- docs: 同步更新 `MO_START.md`、`docs/commands.md`、`docs/update_process.md`、`developer/SCRIPTS_GUIDE.md`、`.updates/README.md`、`docs/BUGS.md`，把 release 檔名與驗證流程寫成硬規則。

## 0.8.4 - 2026-03-07
- feat(debug): 新增 `mo_strategy_debug` runtime table，記錄多標的候選、入選、被擋原因與 alpha 分數。
- feat(line): 新增 LINE 指令 `debug / 除錯`，可直接查看最新 trade date 的 universe source、candidate 數、recs 數、Top candidates 與 rejected 原因。
- feat(status): recommendation 與 strategy debug 現在可用來判斷 `candidate_count > 0 但 rec_count = 0` 的實際原因。
- docs: 同步更新 release notes / commands / bugs / next task / project / AI memory / MO_START。

## 0.8.3
- Phase 4: 策略引擎改為優先讀取 D1 `etf_universe`（`enabled=1`）作為標的池；若 DB 無資料才回退 `MO_UNIVERSE` / `DEFAULT_UNIVERSE`。
- 以 `stocksAll` 全量快照建立 universe 候選池，不再只在 `topByValue` 內找 ETF，修正 `done 0/0` / `multi_asset_no_rec` 的主要原因。
- `mo_recommendation_log` 加入 schema drift 補欄位保護，兼容既有 migration；`狀態` 也能回讀 legacy recommendation log。
- LINE 驗證可用：`universe` / `標的池`、`狀態`、`建議`。

## 0.8.2 - 2026-03-07
- Strategy: 新增預設 ETF universe（0050 / 006208 / 0056 / 00878 / 00919），多標的推薦優先在 ETF 池內挑選。
- Strategy: 支援 `MO_UNIVERSE` 覆寫標的池；當日若 universe 無快照，才回退到成交值排行，避免推薦流程中斷。
- Worker: 新增 `mo_recommendation_log`，記錄 signal、universe 來源、candidate 數、recommendation 數與 fallback 狀態。
- LINE: 新增 `universe / 標的池` 查詢，`狀態` 也會顯示最新 recommendation log。
- Docs: 同步更新 `MO_START.md`、`docs/PROJECT.md`、`docs/AI_MEMORY.md`、`docs/NEXT_TASK.md`、`docs/BUGS.md`、`RELEASE_NOTES.md`。

## 0.8.1
- fix(cli): restore stable `mo smoke` / `mo smoke-worker` commands and make `mo deploy` / `mo logs` call `npx wrangler ...` directly.
- fix(toolchain): move dev / patch / release latest zip outputs to `.updates/outbox/` root and archive prior latest artifacts in `.updates/outbox/bak/`.
- fix(migration): `sync-structure`, `apply-patch`, and `apply-update` now remove deprecated `.updates/backup` and deprecated outbox subdirectories from the actual repo.
- docs(process): add `docs/BUGS.md`, record BUG-20260307-01, and sync MO_START / commands / update process / project docs for the CLI foundation baseline.

## 0.7.5-handoff
- fix(toolchain): `_util.run()` now throws on process spawn errors.
- feat(toolchain): add `smoke:worker` and document when to run it.
- docs(handoff): sync deploy flow, D0~D19 semantics, current runtime status, unresolved items.

# 0.6.9

- Fix: `smoke:tools` now reuses source `node_modules` instead of running nested `npm install` in the sandbox, avoiding Windows npm CLI failures.

# 0.6.8

- Add toolchain smoke test script for pack / patch / release / update workflow.
- Fix doctor success output and patch cleanup import.
- Normalize generated zip entry paths for cross-platform compatibility.

# 0.5.4

- Fix: TWSE not-ready no longer blocks order generation; avoid clearing seeded PENDING orders when snapshot missing.
- Fix: Correct index direction using TWSE sign.

# Changelog

## v0.4.2-hotfix.1 — TWSE trade date fallback

- Fixed: When TWSE FMTQIK has no trade date (or API returns empty/changed schema), treat as NOT READY instead of throwing hard error. Writes status into mo_daily_mark.
## v0.4.2 (2026-03-05)

### Added
- D1 runtime audit tables (via migration `0005_add_runtime_audit_tables.sql`)
  - `mo_tick_audit` (tick dispatcher audit + de-dupe lock)
  - `mo_daily_mark` (daily market-data readiness + push markers)
  - `mo_execution_mark` (simulation / execution audit)

### Improved
- Tick dispatcher writes audit rows to `mo_tick_audit` and skips duplicates safely.
- `mo status` shows **health** by reading the latest audit rows from remote D1.

### Changed
- Cron trigger switched to a **global 15-minute heartbeat**: `*/15 * * * *` (market logic stays in code).

## 0.6.1
- 修正 mo pack / mo update 的命名與流程語意
- `mo pack` 改為輸出 `.updates/outbox/mo_local_latest.zip`
- `mo update` 對齊 `.updates/inbox/market-observer_release_latest.zip` → `.updates/bak/` → `.updates/work/` 流程
- 新增 `manifest.json`、`VERSION`、`docs/update_process.md`、`docs/setup.md`
- handoff 規則明確化：AI 需比對聊天室規則與 repo 差異後再產出 `mo_handoff*.zip`
