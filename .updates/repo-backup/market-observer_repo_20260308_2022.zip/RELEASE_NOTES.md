# 0.11.7

- Fix `mo recommendation-scoreboard` so remote D1 queries normalize SQL before passing to Wrangler on Windows.
- Add empty-SQL guard in recommendation review query helper.

# 0.11.6
- Added `mo recommendation-scoreboard` to summarize saved recommendation review snapshots.
- Updated CLI/help/doctor/docs for the new verification command.

## 0.11.5
- 修正 `recommendation-review-save` 在 Windows / cmd 環境下以 `--command` 傳多行 SQL 造成 Wrangler 判定缺少 `--command` 的問題。
- `execSql()` 現在會先將 SQL 正規化為單行再送給 `wrangler d1 execute`。

## 0.11.3
- 新增 `mo recommendation-review-save`，把最新推薦批次 review 結果落表到 D1。
- 自動建立 `mo_recommendation_review_batches`、`mo_recommendation_review_items`。
- 為後續 scoreboard / 命中率統計建立正式 snapshot 基線。

## 0.11.3
- `mo recommendation-review` 輸出強化：新增 `max_review_horizon`、`available_checkpoints`、`pending_checkpoints`，並明確區分 `not-enough-trade-days`、`missing-close`、`signal-generated-but-not-filled`。

# Release Notes

## 0.11.1
- 新增 `mo recommendation-review`，用最新推薦批次回看 D0 / D5 / D10 / D20 的模擬表現。
- 明確校正 MO 定位：MO 是推薦驗證系統，不是實盤交易系統；portfolio / orders / execution marks 屬於推薦驗證用模擬資料層。
- 同步更新 `MO_START.md`、`docs/PROJECT.md`、`docs/AI_MEMORY.md`、`docs/NEXT_TASK.md`、`docs/BUGS.md`、`docs/FUTURE_SYSTEMS.md`、`docs/commands.md`、`developer/SCRIPTS_GUIDE.md`。

## 驗證重點
1. `npm run mo -- doctor` 後，版本應顯示為 `market-observer@0.11.1`。
2. `npm run mo -- recommendation-review` 應成功，輸出最新推薦批次的 D0 / D5 / D10 / D20 表現。
3. 若目前尚不足 20 個交易日資料，腳本應顯示 partial review / D20 summary skip，而不是失敗。

