# 0.6.9

- Fix: `smoke:tools` now reuses source `node_modules` instead of running nested `npm install` in the sandbox, avoiding Windows npm CLI failures.

# 0.6.8

- Add toolchain smoke test script for pack / patch / release / update workflow.
- Fix doctor success output and patch cleanup import.
- Normalize generated zip entry paths for cross-platform compatibility.

# 0.5.4

- Fix: TWSE not-ready no longer blocks order generation; avoid clearing seeded PENDING orders when snapshot missing.
- Fix: Correct index direction using TWSE sign.

# Changelog

## v0.4.2-hotfix.1 — TWSE trade date fallback

- Fixed: When TWSE FMTQIK has no trade date (or API returns empty/changed schema), treat as NOT READY instead of throwing hard error. Writes status into mo_daily_mark.
## v0.4.2 (2026-03-05)

### Added
- D1 runtime audit tables (via migration `0005_add_runtime_audit_tables.sql`)
  - `mo_tick_audit` (tick dispatcher audit + de-dupe lock)
  - `mo_daily_mark` (daily market-data readiness + push markers)
  - `mo_execution_mark` (simulation / execution audit)

### Improved
- Tick dispatcher writes audit rows to `mo_tick_audit` and skips duplicates safely.
- `mo status` shows **health** by reading the latest audit rows from remote D1.

### Changed
- Cron trigger switched to a **global 15-minute heartbeat**: `*/15 * * * *` (market logic stays in code).

## 0.6.1
- 修正 mo pack / mo update 的命名與流程語意
- `mo pack` 改為輸出 `.updates/outbox/mo_local_latest.zip`
- `mo update` 對齊 `.updates/inbox/market-observer_release_latest.zip` → `.updates/bak/` → `.updates/work/` 流程
- 新增 `manifest.json`、`VERSION`、`docs/update_process.md`、`docs/setup.md`
- handoff 規則明確化：AI 需比對聊天室規則與 repo 差異後再產出 `mo_handoff*.zip`

## v0.7.4
- add GPT intent router and report/watchlist command updates
- add smoke:worker
- fix Windows deploy execution in mo CLI
