1. 修 market_data_ready 與 D0 summary 生成
2. 讓 strategy engine 使用 universe，避免 done 0/0
3. 產生 mo_orders 並銜接 D1 模擬交易
4. 補 deploy-required 提示與非交易日行為
