# AI MEMORY

- v0.6.8：新增 `scripts/smoke-tools.mjs` 與 `npm run smoke:tools`，可在暫存 repo 驗證 `mo pack` / `mo patch` / `mo update` 主流程。
- v0.6.8：改用 `archiver` 產生 zip，避免 Windows 產包時把 `\` 寫進 zip entry 導致跨平台解壓路徑異常。
- v0.6.8：修正 `doctor.mjs` 成功輸出與 `apply-patch.mjs` 缺少 `rmSync` import。
- v0.6.6：`mo update` 由 preflight-only 改為真正套用到 repo root。
- v0.6.6：新增 `mo patch`，專門處理工具鏈與文件更新。
- v0.6.7-handoff：明確定義 `mo pack` 標準輸出為 `.updates/outbox/dev/mo_local_latest.zip`。
- v0.6.7-handoff：handoff 規則升級為「先比對、補齊、記錄未完成項，再產生新的 handoff 包」。
- v0.6.7-handoff：patch / update 成功後應清理 deprecated `.updates/backup`（若存在）。


- LINE 自然語言不做硬編碼 mapping；改採 GPT intent router。
- 指令正式名稱改為「盤後報告」，但保留「昨日報告 / report」相容。
