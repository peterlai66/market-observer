#!/usr/bin/env node
import { run } from './_util.mjs';

try {
	console.log('[0] wrangler --version');
	run('wrangler', ['--version']);
	console.log('[1] wrangler deploy --dry-run');
	run('wrangler', ['deploy', '--dry-run']);
	console.log('[2] typecheck');
	run('npm', ['run', 'typecheck']);
	console.log('[OK] Worker smoke passed');
} catch (e) {
	console.error(e instanceof Error ? e.message : e);
	process.exit(1);
}
