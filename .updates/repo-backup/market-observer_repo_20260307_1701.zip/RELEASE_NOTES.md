# Release Notes

## v0.7.4
- 新增 GPT intent router（有設定 OPENAI_API_KEY 時啟用）
- LINE 指令主名稱改為「盤後報告」，保留「昨日報告 / report」相容
- 新增「監控 / watchlist」指令
- 盤後報告改為對齊最新 mo_daily_mark.trade_date，若該交易日報告尚未生成會明確提示
- 新增 smoke:worker
- 修正 mo deploy 與 logs 在 Windows 的執行方式
- 修正 _util.mjs 子程序啟動失敗時不再假成功
