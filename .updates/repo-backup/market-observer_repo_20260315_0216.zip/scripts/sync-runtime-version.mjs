#!/usr/bin/env node
import { readFileSync, writeFileSync } from 'node:fs';
import { join, resolve } from 'node:path';

const root = resolve('.');
const version = readFileSync(join(root, 'VERSION'), 'utf-8').trim();
const target = join(root, 'src', 'index.ts');
const source = readFileSync(target, 'utf-8');
const pattern = /const APP_VERSION = ['"][^'"]+['"];?/;
if (!pattern.test(source)) {
  throw new Error('APP_VERSION constant not found in src/index.ts');
}
const next = source.replace(pattern, `const APP_VERSION = '${version}';`);
if (next !== source) {
  writeFileSync(target, next);
  console.log(`Synced APP_VERSION => ${version}`);
} else {
  console.log(`APP_VERSION already synced => ${version}`);
}
