# MO_START

這是 **Market Observer (MO)** 專案的唯一入口文件。

## AI 接手規則
當使用者說：

> 請依照 `MO_START.md` 接續開發專案

你必須先依序閱讀：
1. `MO_START.md`
2. `docs/PROJECT.md`
3. `docs/AI_MEMORY.md`
4. `docs/NEXT_TASK.md`
5. `developer/SCRIPTS_GUIDE.md`
6. 視需要再讀 `docs/AI_CONTEXT.md`、`developer/MO_DEBUG_GUIDE.md`

在理解文件前，不要直接修改程式。

## AI 權責
AI 必須：
- 尊重既有專案架構與 `.updates/` 目錄 contract
- 修改系統架構、功能、流程、目錄、檔案時同步更新相關文件
- 一般交付提供可透過 `mo update` 套用的 release zip
- 修工具鏈（scripts / docs / developer / MO_START）時優先走 `mo patch`
- 只有使用者明確輸入 `handoff` 時，才產出 handoff 包

AI 不可：
- 未更新文件就任意調整目錄結構
- 未記錄變更就刪除系統目錄或重要檔案
- 把 `mo pack` 誤當成 handoff
- 只改程式、不補文件與版本紀錄

## 唯一規則
- **唯一入口文件**：`MO_START.md`
- **唯一人工操作入口**：`mo` CLI（目前建議使用 `npm run mo -- <command>`；後續可收斂到 `npx mo <command>`）
- **`mo pack` 是 local 最新快照，不是 handoff**
- **`handoff` 是聊天交接指令**
- **一般交付一律是可透過 `mo update` 套用的 release zip**
- **修 `update` 本身時，不要再用 `update` 修 `update`；改走 `patch`**

## 開發流程
1. 使用者上傳 local 打包檔或 handoff 包
2. AI 先讀 `MO_START.md`
3. AI 依文件接續開發，不重新發明流程
4. 一般交付輸出 release zip
5. 使用者在 local 端執行 `mo update`

## handoff 正式流程
當使用者在聊天中輸入：

> `handoff`

且附上 local 打包檔時，AI 必須：
1. 檢查是否有附打包檔；沒有就明確要求補上。
2. 讀取檔案內容，並比對本聊天室中已定義的流程、規則、功能與未修復 bug。
3. 能立即修正的直接修進 repo；來不及修正的要明確記錄到 handoff 文件。
4. 打包新的 **handoff 包** 並上傳給使用者。
5. 明確提醒新視窗要輸入：`請依照 MO_START.md 接續開發專案`。

## Package / 命名規則
- `mo pack` 產物：`.updates/outbox/mo_local_latest.zip`
  - 用途：臨時把 local 最新檔案交給 AI
  - 不是 handoff 包
- `mo patch` 入口：`.updates/inbox/market-observer_patch_latest.zip`
  - 用途：只更新工具鏈與文件（scripts / docs / developer / MO_START / VERSION / RELEASE_NOTES）
- `mo_handoff_latest.zip`
  - 用途：只有 AI 在聊天 `handoff` 流程中產出的交接包
- `market-observer_release_latest.zip`
  - 用途：正式 update 入口包，放入 `.updates/inbox/` 後執行 `mo update`
- `_latest.zip` 只是入口別名，真正版本以 `manifest.json` 與 `VERSION` 為準。

## `.updates/` 結構定義
```text
.updates/
  README.md    ← 目錄 contract 說明
  inbox/       ← patch / release 入口
  outbox/      ← local pack / patch / release 輸出
    bak/       ← 舊 local pack
    patch/     ← 本地工具鏈 patch 輸出
      bak/     ← 舊 patch 輸出
    release/   ← 本地正式 release 輸出
      bak/     ← 舊 release 輸出
  bak/         ← mo patch / mo update 吃掉的封存包
  work/        ← mo patch / mo update 解壓工作區
  history/     ← mo patch / mo update 紀錄
  repo-backup/ ← mo patch / mo update 前的備份快照
```

## `mo patch` / `mo update` 規則
- `mo patch` 入口：`.updates/inbox/market-observer_patch_latest.zip`
  - 只更新工具鏈：`scripts/`、`docs/`、`developer/`、`MO_START.md`、`VERSION`、`RELEASE_NOTES.md`、`.updates/README.md`
- `mo update` 入口：`.updates/inbox/market-observer_release_latest.zip`
  - 用於完整專案更新
- 兩者都會：
  1. 先建立 `repo-backup`
  2. 驗證 backup 存在且非空
  3. 解壓到 `.updates/work/`
  4. 驗證 work 非空
  5. 套用檔案到 repo root
  6. 成功後才把 zip 移到 `.updates/bak/`
  7. 寫入 `.updates/history/` 紀錄
- 若失敗，`inbox` 內原始 zip 必須保留供重試。

## 文件維護規則（強制）
只要有修改，就必須同步更新相關文件；沒有更新文件的程式變更，視為未完成。
- 架構／流程改動 → `docs/PROJECT.md`
- 重要決策／里程碑 → `docs/AI_MEMORY.md`
- 下一步開發方向 → `docs/NEXT_TASK.md`
- 指令／腳本變動 → `developer/SCRIPTS_GUIDE.md`
- 更新流程改動 → `docs/update_process.md`
- 安裝或初始化改動 → `docs/setup.md`
- 除錯流程改動 → `developer/MO_DEBUG_GUIDE.md`
- 版本變更 → `RELEASE_NOTES.md`
- 目錄結構、重要檔案新增刪除 → `MO_START.md` + `docs/PROJECT.md` + `RELEASE_NOTES.md`
