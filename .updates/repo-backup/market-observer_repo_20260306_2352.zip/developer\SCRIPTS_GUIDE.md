# SCRIPTS GUIDE

## core commands
- `npm run mo -- doctor`
- `npm run mo -- pack`
- `npm run mo -- patch`
- `npm run mo -- release`
- `npm run mo -- update`

## pack family
- `pack:dev` → `.updates/outbox/mo_local_latest.zip`
- `pack:patch` → `.updates/outbox/patch/market-observer_patch_latest.zip`
- `pack:release` → `.updates/outbox/release/market-observer_release_latest.zip`

## patch / update responsibilities
### patch
用途：修工具鏈與文件。

只更新：
- `scripts/`
- `docs/`
- `developer/`
- `MO_START.md`
- `VERSION`
- `RELEASE_NOTES.md`
- `.updates/README.md`

### update
用途：完整專案更新。

更新 release 包內所有正式項目，並套用到 repo root。

## update pipeline contract
1. validate inbox package exists
2. create backup zip
3. verify backup non-empty
4. extract package to `.updates/work/`
5. verify work non-empty
6. copy staged files to repo root
7. archive used package to `.updates/bak/`
8. write history json

## failure rule
- 任何步驟失敗都必須中止
- 失敗時 `inbox` 內原始 zip 必須保留
- 不可出現只印成功但 backup 為空的假成功
