# PROJECT

## 專案定位
Market Observer (MO) 是以 **Cloudflare Workers + D1 + TWSE OpenAPI + LINE** 為核心的盤後市場觀察與建議系統。

## AI 協作原則
- `MO_START.md` 是唯一入口文件
- 新 AI 接手必須先讀文件，不可從零猜測專案結構
- 架構、流程、目錄 contract 一旦修改，必須同步更新文件並留痕
- 任何程式修改若未同步更新文件，視為未完成

## Runtime 架構
1. **MO CLI / Update System**
2. **Data Layer**：TWSE（MI_INDEX / FMTQIK / STOCK_DAY_ALL）
3. **Reliability Layer (D0)**：tradeDate quorum、schema guard、mismatch guard
4. **Feature / Recommendation Layer**
5. **Personal Portfolio Layer**
6. **Personal Risk Control Layer**
7. **Opportunity Analyzer**
8. **Notification Layer**

## `.updates` 正式結構
```text
.updates
├ README.md
├ inbox
├ work
├ bak
├ repo-backup
├ outbox
│  ├ bak
│  ├ patch
│  │  └ bak
│  └ release
│     └ bak
└ history
```

### 說明
- `backup/` 已 deprecated，v0.6.5 起移除
- `outbox/` 與 `history/` 都是正式結構的一部分，不可當成無用資料夾刪除
- `patch` 與 `update` 共用 `.updates/work`、`.updates/bak`、`.updates/history`、`.updates/repo-backup`

## CLI 原則
所有人工操作都優先透過 `mo`：
- `npm run mo -- doctor`
- `npm run mo -- logs`
- `npm run mo -- deploy`
- `npm run mo -- pack`
- `npm run mo -- patch`
- `npm run mo -- release`
- `npm run mo -- update`

## Toolchain 分工
- `patch`：修工具鏈與文件，不動 `src/`、`migrations/`
- `update`：完整專案更新
- `handoff`：AI 聊天交接包
