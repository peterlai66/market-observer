# Market Observer v0.5.5 (hotfix)

- Fixes premature post_close_done marking: post-close is marked done only after today's summary exists and is non-empty.
- Allows push-only placeholder at 16:00 even when summary is not ready, while keeping post-close retry active every 15 minutes.

# Market Observer v0.5.4 (stable)

- Orders generation no longer aborts when TWSE "not ready"; summary may skip but strategy/simulation can continue.
- Prevents wiping existing PENDING orders when no TWSE stock snapshot is available.
- Fixes index up/down direction by applying TWSE sign to change points.

# Market Observer v0.4.2-hotfix.1

- TWSE FMTQIK trade date missing no longer crashes daily process.
- Mark daily readiness into mo_daily_mark and skip until ready.

# Market Observer Release Notes

## 0.0.0 (2026-03-04 19:44)  [1e0b808]

### Other
- auto 20260304_1709
- Initial commit (by create-cloudflare CLI)

## 2026-03-04  Dev Tools Baseline

### Add
- `scripts/` dev tools
- `npm run pack:dev` / `npm run pack:release`
- `npm run send` (typecheck → commit → pack:dev → open artifacts)
- `npm run quick` (typecheck → deploy → tail)
- `npm run doctor` (check node/npm/wrangler/git + wrangler bindings)

### Notes
- Packaging includes: `src/`, `scripts/`, `migrations/`, `wrangler.jsonc`, `package.json`, `tsconfig.json`, `README.md`, `RELEASE_NOTES.md`

---

## 0.4.2 (2026-03-05)

### Added
- D1 runtime audit tables (migration `0005_add_runtime_audit_tables.sql`)
  - `mo_tick_audit`: tick dispatcher audit + de-dupe lock
  - `mo_daily_mark`: daily market-data readiness + push markers
  - `mo_execution_mark`: simulation / execution audit

### Improved
- Tick dispatcher writes audit rows and safely skips duplicate ticks.
- `mo status` includes health summary pulled from remote D1.

### Changed
- Cron trigger switched to global heartbeat: `*/15 * * * *`
