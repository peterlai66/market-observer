# NEXT TASK

1. 收斂 CLI 使用方式到 `npx mo <command>`（若決定採用）。
2. 補 `mo patch` / `mo update` 的自動化 smoke test。
3. 視需要讓 update 支援刪除清單或 manifest。
