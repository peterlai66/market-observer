# AI MEMORY

- v0.6.6：`mo update` 由 preflight-only 改為真正套用到 repo root。
- v0.6.6：新增 `mo patch`，專門處理工具鏈與文件更新。
