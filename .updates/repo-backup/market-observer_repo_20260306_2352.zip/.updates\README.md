# .updates directory contract

Do not delete folders unless documentation explicitly says it is safe.

## folders
- `inbox/`：等待套用的 patch / release 包
- `work/`：patch / update 解壓工作區
- `bak/`：已套用的 patch / release 歷史
- `repo-backup/`：patch / update 前的備份快照
- `outbox/`：本 repo 產出的 pack / patch / release 包
- `history/`：patch / update 執行紀錄

## note
- `backup/` 已 deprecated，不可再新增回來
- 修工具鏈時應優先走 `patch`
