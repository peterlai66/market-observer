#!/usr/bin/env node
import { run } from './_util.mjs';

function log(step, msg) {
  console.log(`[${step}] ${msg}`);
}

try {
  log('0', 'wrangler --version');
  run('npx', ['wrangler', '--version']);

  log('1', 'wrangler deploy --dry-run');
  run('npx', ['wrangler', 'deploy', '--dry-run']);

  log('2', 'wrangler d1 migrations list line_etf_monitor_v36');
  run('npx', ['wrangler', 'd1', 'migrations', 'list', 'line_etf_monitor_v36']);

  console.log('[OK] Worker smoke passed');
} catch (e) {
  console.error(e instanceof Error ? e.message : String(e));
  process.exit(1);
}
