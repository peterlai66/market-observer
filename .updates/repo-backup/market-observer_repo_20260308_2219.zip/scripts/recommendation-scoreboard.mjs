#!/usr/bin/env node
import { fmtPct, runQuery } from './_recommendation_review_lib.mjs';

const mode = (process.argv[2] || 'remote').trim().toLowerCase();
const remote = mode !== 'local';

console.log(`MO Recommendation Scoreboard (${remote ? 'remote' : 'local'})`);

const batchRows = runQuery(`
SELECT trade_date, review_universe, available_trade_dates, max_review_horizon, review_generated_at
FROM mo_recommendation_review_batches
ORDER BY review_generated_at DESC, trade_date DESC
` , remote);

const itemRows = runQuery(`
SELECT trade_date, symbol, order_status, review_note, d0_return, d5_return, d10_return, d20_return
FROM mo_recommendation_review_items
ORDER BY reviewed_at DESC, trade_date DESC, symbol ASC
`, remote);

const totalBatches = batchRows.length;
const totalSymbols = itemRows.length;
const filledOrders = itemRows.filter((r) => String(r.order_status || '').toUpperCase() === 'EXECUTED').length;
const skippedOrders = itemRows.filter((r) => String(r.order_status || '').toUpperCase() === 'SKIPPED').length;
const pendingOrders = itemRows.filter((r) => String(r.order_status || '').toUpperCase() === 'PENDING').length;
const skipRatio = totalSymbols > 0 ? (skippedOrders / totalSymbols) * 100 : 0;
const filledRatio = totalSymbols > 0 ? (filledOrders / totalSymbols) * 100 : 0;

console.log('');
console.log(`total_batches=${totalBatches}`);
console.log(`total_symbols=${totalSymbols}`);
console.log(`filled_orders=${filledOrders}`);
console.log(`skipped_orders=${skippedOrders}`);
console.log(`pending_orders=${pendingOrders}`);
console.log('');
console.log(`skip_ratio=${skipRatio.toFixed(2)}%`);
console.log(`filled_ratio=${filledRatio.toFixed(2)}%`);

if (totalBatches > 0) {
  const latest = batchRows[0];
  console.log('');
  console.log(`latest_batch=${latest.trade_date}`);
  console.log(`latest_universe=${latest.review_universe}`);
  console.log(`latest_horizon=D${latest.max_review_horizon}`);
  console.log(`latest_available_trade_dates=${latest.available_trade_dates}`);
}

const checkpoints = [
  { label: 'D0', key: 'd0_return' },
  { label: 'D5', key: 'd5_return' },
  { label: 'D10', key: 'd10_return' },
  { label: 'D20', key: 'd20_return' },
];

const statuses = ['EXECUTED', 'SKIPPED', 'PENDING'];
const normalizedItems = itemRows.map((row) => ({
  ...row,
  order_status: String(row?.order_status || '').trim().toUpperCase() || 'UNKNOWN',
}));

const avg = (values) => values.length ? values.reduce((sum, value) => sum + value, 0) / values.length : NaN;
const fmtMaybePct = (values) => values.length ? fmtPct(avg(values)) : '—';
const ratio = (num, den) => den > 0 ? `${((num / den) * 100).toFixed(2)}%` : '0.00%';
const windows = [1, 3, 5];
const latestTradeDates = [...new Set(batchRows.map((row) => String(row.trade_date || '')))].filter(Boolean);
const diagnosisRecords = [];

function buildStatusSummary(rows, key, totalEvaluable) {
  const values = rows.map((row) => Number(row?.[key])).filter((value) => Number.isFinite(value));
  const win = values.filter((value) => value > 0).length;
  const loss = values.filter((value) => value < 0).length;
  const flat = values.filter((value) => value === 0).length;
  const decisive = win + loss;
  return {
    evaluable: values.length,
    shareOfEvaluable: ratio(values.length, totalEvaluable),
    averageReturn: fmtMaybePct(values),
    positiveRate: ratio(win, values.length),
    winRate: ratio(win, values.length),
    lossRate: ratio(loss, values.length),
    flatRate: ratio(flat, values.length),
    expectancy: fmtMaybePct(values),
    decisiveRate: ratio(decisive, values.length),
  };
}


function buildDiagnosis(checkpointLabel, evaluableRows, key, totalEvaluable) {
  const values = evaluableRows.map((row) => Number(row?.[key])).filter((value) => Number.isFinite(value));
  const averageValue = values.length ? avg(values) : NaN;
  const positive = values.filter((value) => value > 0).length;
  const win = positive;
  const loss = values.filter((value) => value < 0).length;
  const flat = values.filter((value) => value === 0).length;
  const decisive = win + loss;
  const statusCounts = {
    executed: evaluableRows.filter((row) => row.order_status === 'EXECUTED').length,
    skipped: evaluableRows.filter((row) => row.order_status === 'SKIPPED').length,
    pending: evaluableRows.filter((row) => row.order_status === 'PENDING').length,
  };
  const dominantEntry = Object.entries(statusCounts).sort((a, b) => b[1] - a[1])[0] || ['none', 0];
  const [dominantStatus, dominantCount] = dominantEntry;
  const dominantShare = evaluableRows.length > 0 ? (dominantCount / evaluableRows.length) * 100 : 0;

  let gatePressure = 'LOW';
  if (statusCounts.skipped >= Math.max(1, evaluableRows.length * 0.6)) gatePressure = 'HIGH';
  else if (statusCounts.skipped >= Math.max(1, evaluableRows.length * 0.3)) gatePressure = 'MEDIUM';

  let edgeState = 'NO_DATA';
  if (values.length > 0) {
    if (decisive === 0) edgeState = 'FLAT_SAMPLE';
    else if (averageValue > 0 && positive >= loss) edgeState = 'POSITIVE_EDGE';
    else if (averageValue < 0 && loss > positive) edgeState = 'NEGATIVE_EDGE';
    else edgeState = 'MIXED_EDGE';
  }

  let horizonSignalStrength = 'NONE';
  if (values.length > 0) {
    const decisiveShare = decisive / values.length;
    if (decisiveShare === 0) horizonSignalStrength = 'INERT';
    else if (decisiveShare < 0.34) horizonSignalStrength = 'WEAK';
    else if (decisiveShare < 0.67) horizonSignalStrength = 'MODERATE';
    else horizonSignalStrength = 'STRONG';
  }

  const interpretationParts = [];
  if (gatePressure === 'HIGH') interpretationParts.push('execution-gate-dominant');
  else if (gatePressure === 'MEDIUM') interpretationParts.push('mixed-gate-influence');
  else interpretationParts.push('execution-gate-light');

  if (edgeState === 'FLAT_SAMPLE') interpretationParts.push('flat-sample');
  else if (edgeState === 'POSITIVE_EDGE') interpretationParts.push('positive-edge');
  else if (edgeState === 'NEGATIVE_EDGE') interpretationParts.push('negative-edge');
  else if (edgeState === 'MIXED_EDGE') interpretationParts.push('mixed-edge');
  else interpretationParts.push('no-data');

  interpretationParts.push(`${checkpointLabel.toLowerCase()}-${horizonSignalStrength.toLowerCase()}`);

  return {
    dominantStatus,
    dominantStatusShare: `${dominantShare.toFixed(2)}%`,
    gatePressure,
    edgeState,
    horizonSignalStrength,
    executionCoverageGap: ratio(totalEvaluable - statusCounts.executed, totalEvaluable),
    interpretation: interpretationParts.join('-'),
  };
}

console.log('');
console.log('checkpoint_outcomes:');
for (const checkpoint of checkpoints) {
  const evaluableRows = normalizedItems.filter((row) => Number.isFinite(Number(row?.[checkpoint.key])));
  const values = evaluableRows.map((row) => Number(row?.[checkpoint.key]));
  const evaluable = values.length;
  const coverage = totalSymbols > 0 ? (evaluable / totalSymbols) * 100 : 0;
  const positive = values.filter((value) => value > 0).length;
  const positiveRate = evaluable > 0 ? (positive / evaluable) * 100 : 0;
  const average = evaluable > 0 ? avg(values) : NaN;

  console.log(`${checkpoint.label}_evaluable=${evaluable}`);
  console.log(`${checkpoint.label}_coverage=${coverage.toFixed(2)}%`);
  console.log(`${checkpoint.label}_positive=${positive}`);
  console.log(`${checkpoint.label}_positive_rate=${positiveRate.toFixed(2)}%`);
  console.log(`${checkpoint.label}_average_return=${fmtPct(average)}`);
  console.log('');

  const winRows = evaluableRows.filter((row) => Number(row?.[checkpoint.key]) > 0);
  const lossRows = evaluableRows.filter((row) => Number(row?.[checkpoint.key]) < 0);
  const flatRows = evaluableRows.filter((row) => Number(row?.[checkpoint.key]) === 0);
  const win = winRows.length;
  const loss = lossRows.length;
  const flat = flatRows.length;
  const avgOfRows = (rows) => rows.length
    ? fmtPct(rows.reduce((sum, row) => sum + Number(row?.[checkpoint.key]), 0) / rows.length)
    : '—';

  console.log(`${checkpoint.label}_classification:`);
  console.log(`win=${win}`);
  console.log(`loss=${loss}`);
  console.log(`flat=${flat}`);
  console.log(`win_rate=${ratio(win, evaluable)}`);
  console.log(`loss_rate=${ratio(loss, evaluable)}`);
  console.log(`flat_rate=${ratio(flat, evaluable)}`);

  for (const status of statuses) {
    const rows = evaluableRows.filter((row) => row.order_status === status);
    const key = status.toLowerCase();
    console.log(`${key}_evaluable=${rows.length}`);
    console.log(`${key}_average_return=${avgOfRows(rows)}`);
  }
  console.log('');

  const decisive = win + loss;
  const avgWin = avg(winRows.map((row) => Number(row?.[checkpoint.key])));
  const avgLoss = avg(lossRows.map((row) => Number(row?.[checkpoint.key])));
  const edgeRatio = Number.isFinite(avgWin) && Number.isFinite(avgLoss) && avgLoss !== 0
    ? `${Math.abs(avgWin / avgLoss).toFixed(2)}x`
    : '—';

  console.log(`${checkpoint.label}_performance:`);
  console.log(`expectancy=${fmtPct(average)}`);
  console.log(`avg_win_return=${fmtPct(avgWin)}`);
  console.log(`avg_loss_return=${fmtPct(avgLoss)}`);
  console.log(`edge_ratio=${edgeRatio}`);
  console.log(`nonflat_evaluable=${decisive}`);
  console.log(`decisive_rate=${ratio(decisive, evaluable)}`);
  console.log('');

  console.log(`${checkpoint.label}_rolling:`);
  for (const window of windows) {
    const chosenDates = latestTradeDates.slice(0, window);
    const rows = evaluableRows.filter((row) => chosenDates.includes(String(row.trade_date || '')));
    const rowValues = rows.map((row) => Number(row?.[checkpoint.key])).filter((value) => Number.isFinite(value));
    const label = `last_${window}_batch`;
    console.log(`${label}_count=${Math.min(window, latestTradeDates.length)}`);
    console.log(`${label}_evaluable=${rows.length}`);
    console.log(`${label}_average_return=${fmtMaybePct(rowValues)}`);
    console.log(`${label}_positive_rate=${ratio(rowValues.filter((value) => value > 0).length, rowValues.length)}`);
  }
  console.log('');

  const statusGroups = {
    overall: evaluableRows,
    executed: evaluableRows.filter((row) => row.order_status === 'EXECUTED'),
    skipped: evaluableRows.filter((row) => row.order_status === 'SKIPPED'),
    pending: evaluableRows.filter((row) => row.order_status === 'PENDING'),
  };

  console.log(`${checkpoint.label}_execution_summary:`);
  for (const [name, rows] of Object.entries(statusGroups)) {
    const summary = buildStatusSummary(rows, checkpoint.key, evaluable);
    console.log(`${name}_evaluable=${summary.evaluable}`);
    console.log(`${name}_share_of_evaluable=${summary.shareOfEvaluable}`);
    console.log(`${name}_average_return=${summary.averageReturn}`);
    console.log(`${name}_positive_rate=${summary.positiveRate}`);
    console.log(`${name}_win_rate=${summary.winRate}`);
    console.log(`${name}_loss_rate=${summary.lossRate}`);
    console.log(`${name}_flat_rate=${summary.flatRate}`);
    console.log(`${name}_expectancy=${summary.expectancy}`);
    console.log(`${name}_decisive_rate=${summary.decisiveRate}`);
  }
  console.log('');

  const diagnosis = buildDiagnosis(checkpoint.label, evaluableRows, checkpoint.key, evaluable);
  console.log(`${checkpoint.label}_diagnosis:`);
  console.log(`dominant_status=${diagnosis.dominantStatus}`);
  console.log(`dominant_status_share=${diagnosis.dominantStatusShare}`);
  console.log(`gate_pressure=${diagnosis.gatePressure}`);
  console.log(`edge_state=${diagnosis.edgeState}`);
  console.log(`horizon_signal_strength=${diagnosis.horizonSignalStrength}`);
  console.log(`execution_coverage_gap=${diagnosis.executionCoverageGap}`);
  console.log(`interpretation=${diagnosis.interpretation}`);
  console.log('');

  diagnosisRecords.push({
    checkpoint: checkpoint.label,
    evaluable,
    executedEvaluable: statusGroups.executed.length,
    skippedEvaluable: statusGroups.skipped.length,
    pendingEvaluable: statusGroups.pending.length,
    positive,
    positiveRate,
    average,
    decisiveRate: evaluable > 0 ? (decisive / evaluable) * 100 : 0,
    diagnosis,
  });
}

function mostCommon(records, getter, fallback = '—') {
  const counts = new Map();
  for (const record of records) {
    const value = getter(record);
    counts.set(value, (counts.get(value) || 0) + 1);
  }
  const sorted = [...counts.entries()].sort((a, b) => b[1] - a[1] || String(a[0]).localeCompare(String(b[0])));
  return sorted[0]?.[0] ?? fallback;
}

function uniqueFindings(items) {
  return [...new Set(items.filter(Boolean))];
}


function buildActionableRecommendations(records, batchSummary) {
  const recommendations = [];
  const avgExecutedShare = batchSummary.avgExecutedShare;
  const avgPositiveRate = batchSummary.avgPositiveRate;
  const maxGap = batchSummary.maxExecutionCoverageGap;

  if (avgExecutedShare < 10) {
    recommendations.push('collect-executed-samples-before-judging-strategy-edge');
  }

  if (batchSummary.gatePressureConsensus === 'HIGH' || maxGap >= 50) {
    recommendations.push('audit-skip-gates-and-rejected-reasons-before-tuning-ranking');
  }

  if (batchSummary.edgeStateConsensus === 'FLAT_SAMPLE') {
    recommendations.push('avoid-edge-optimization-until-nonflat-samples-appear');
  } else if (batchSummary.edgeStateConsensus === 'NEGATIVE_EDGE') {
    recommendations.push('tighten-candidate-quality-or-risk-filters-before-expanding-execution');
  } else if (batchSummary.edgeStateConsensus === 'POSITIVE_EDGE' && avgExecutedShare < 50) {
    recommendations.push('consider-careful-gate-relaxation-to-capture-positive-edge');
  }

  if (batchSummary.horizonSignalConsensus === 'INERT' || batchSummary.strongestHorizonSignal === 'INERT') {
    recommendations.push('defer-horizon-selection-until-signal-strength-exceeds-inert');
  }

  if (avgPositiveRate === 0 && avgExecutedShare === 0) {
    recommendations.push('prioritize-data-coverage-over-performance-interpretation');
  }

  if (recommendations.length === 0) {
    recommendations.push('current-batch-ready-for-next-layer-comparison-and-ranking');
  }

  return [...new Set(recommendations)].slice(0, 7);
}



function extractStructuredReasonMarks(note) {
  const raw = String(note || '').trim();
  if (!raw || raw.toLowerCase() === 'ok') return [];
  return raw
    .split(',')
    .map((part) => part.trim())
    .filter(Boolean)
    .map((part) => part.split('|')[0].trim())
    .filter(Boolean)
    .map((mark) => {
      const m = String(mark || '').trim().match(/^(D\d+)\s*:(.+)$/i);
      if (m) {
        return { checkpoint: m[1].toUpperCase(), rawMark: String(m[2] || '').trim() };
      }
      return { checkpoint: 'UNSCOPED', rawMark: String(mark || '').trim() };
    });
}

function extractReasonMarks(note) {
  return extractStructuredReasonMarks(note).map((entry) => entry.checkpoint !== 'UNSCOPED' ? `${entry.checkpoint}:${entry.rawMark}` : entry.rawMark);
}

function normalizeReasonMark(mark) {
  const raw = String(mark || '').trim();
  if (!raw) return { normalized: 'unknown', family: 'other' };
  const withoutCheckpoint = raw.replace(/^D\d+\s*:/i, '').trim();
  const t = withoutCheckpoint.toLowerCase();

  if (t === 'signal-generated-but-not-filled') {
    return { normalized: 'signal-generated-but-not-filled', family: 'execution_gate' };
  }
  if (t === 'not-enough-trade-days') {
    return { normalized: 'not-enough-trade-days', family: 'data_coverage' };
  }
  if (t === 'missing-close') {
    return { normalized: 'missing-close', family: 'data_gap' };
  }
  if (t.includes('notional') || t.includes('budget') || t.includes('qty')) {
    return { normalized: 'sizing-or-notional-constraint', family: 'sizing_liquidity' };
  }
  if (t.includes('liquidity') || t.includes('spread') || t.includes('volume')) {
    return { normalized: 'liquidity-constraint', family: 'sizing_liquidity' };
  }
  if (t.includes('risk') || t.includes('volatility') || t.includes('drawdown')) {
    return { normalized: 'risk-constraint', family: 'risk_guard' };
  }
  if (t.includes('price')) {
    return { normalized: 'price-constraint', family: 'price_guard' };
  }
  if (t.includes('rank') || t.includes('ranking') || t.includes('selection')) {
    return { normalized: 'ranking-filter', family: 'ranking_filter' };
  }
  if (t.includes('invalid') || t.includes('bad-data')) {
    return { normalized: 'invalid-data', family: 'data_quality' };
  }
  if (t.includes('missing')) {
    return { normalized: 'missing-data', family: 'data_gap' };
  }
  return { normalized: t || 'unknown', family: 'other' };
}

function buildSkipReasonBreakdown(rows) {
  const skippedRows = rows.filter((row) => row.order_status === 'SKIPPED');
  const reasonCounts = new Map();
  const familyCounts = new Map();

  for (const row of skippedRows) {
    const marks = extractStructuredReasonMarks(row.review_note);
    const usable = marks.length ? marks : [{ checkpoint: 'UNSCOPED', rawMark: 'unknown' }];
    for (const mark of usable) {
      const normalized = normalizeReasonMark(mark.rawMark);
      reasonCounts.set(normalized.normalized, (reasonCounts.get(normalized.normalized) || 0) + 1);
      familyCounts.set(normalized.family, (familyCounts.get(normalized.family) || 0) + 1);
    }
  }

  const sortDesc = (entries) => [...entries].sort((a, b) => b[1] - a[1] || String(a[0]).localeCompare(String(b[0])));
  const sortedReasons = sortDesc(reasonCounts.entries());
  const sortedFamilies = sortDesc(familyCounts.entries());
  const totalMarks = sortedReasons.reduce((sum, [, count]) => sum + count, 0);
  const topReason = sortedReasons[0]?.[0] ?? '—';
  const topReasonCount = sortedReasons[0]?.[1] ?? 0;
  const topFamily = sortedFamilies[0]?.[0] ?? '—';
  const topFamilyCount = sortedFamilies[0]?.[1] ?? 0;

  return {
    skippedRows: skippedRows.length,
    totalReasonMarks: totalMarks,
    topReason,
    topReasonShare: totalMarks > 0 ? ((topReasonCount / totalMarks) * 100).toFixed(2) + '%' : '0.00%',
    topFamily,
    topFamilyShare: totalMarks > 0 ? ((topFamilyCount / totalMarks) * 100).toFixed(2) + '%' : '0.00%',
    sortedReasons,
    sortedFamilies,
  };
}



function buildDataQualitySummary(skipBreakdown) {
  const familyMap = new Map(skipBreakdown.sortedFamilies);
  const reasonMap = new Map(skipBreakdown.sortedReasons);
  const total = skipBreakdown.totalReasonMarks || 0;
  const dataGapCount = familyMap.get('data_gap') || 0;
  const dataCoverageCount = familyMap.get('data_coverage') || 0;
  const dataQualityCount = familyMap.get('data_quality') || 0;
  const executionGateCount = familyMap.get('execution_gate') || 0;
  const dataRelatedCount = dataGapCount + dataCoverageCount + dataQualityCount;
  const dominantDataIssueEntry = [...reasonMap.entries()]
    .filter(([reason]) => ['missing-close', 'missing-data', 'not-enough-trade-days', 'invalid-data'].includes(reason))
    .sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]))[0] || ['—', 0];
  const [dominantDataIssue, dominantDataIssueCount] = dominantDataIssueEntry;

  let severity = 'LOW';
  const dataShare = total > 0 ? (dataRelatedCount / total) * 100 : 0;
  const missingShare = total > 0 ? (dataGapCount / total) * 100 : 0;
  if (dataShare >= 70 || missingShare >= 50) severity = 'CRITICAL';
  else if (dataShare >= 50) severity = 'HIGH';
  else if (dataShare >= 20) severity = 'MEDIUM';

  return {
    dataRelatedShare: total > 0 ? `${dataShare.toFixed(2)}%` : '0.00%',
    dominantDataIssue,
    dominantDataIssueShare: dataRelatedCount > 0 ? `${((dominantDataIssueCount / dataRelatedCount) * 100).toFixed(2)}%` : '0.00%',
    coverageIssueShare: total > 0 ? `${((dataCoverageCount / total) * 100).toFixed(2)}%` : '0.00%',
    missingDataIssueShare: total > 0 ? `${((dataGapCount / total) * 100).toFixed(2)}%` : '0.00%',
    dataQualityIssueShare: total > 0 ? `${((dataQualityCount / total) * 100).toFixed(2)}%` : '0.00%',
    executionGateShare: total > 0 ? `${((executionGateCount / total) * 100).toFixed(2)}%` : '0.00%',
    dataBlockingSeverity: severity,
    counts: {
      total,
      dataRelatedCount,
      dataGapCount,
      dataCoverageCount,
      dataQualityCount,
      executionGateCount,
      dominantDataIssueCount,
    },
  };
}

function buildDataQualityFindings(summary) {
  const findings = [];
  const counts = summary.counts;
  if (counts.dataRelatedCount > 0 && counts.dataRelatedCount >= counts.executionGateCount) {
    findings.push('data-issues-dominate-skip-pressure');
  }
  if (summary.dominantDataIssue === 'missing-close') {
    findings.push('missing-close-is-primary-data-failure');
  }
  if (summary.dominantDataIssue === 'not-enough-trade-days' || counts.dataCoverageCount > 0) {
    findings.push('trade-date-coverage-insufficient-for-some-checkpoints');
  }
  if (counts.executionGateCount > 0 && counts.dataRelatedCount > counts.executionGateCount) {
    findings.push('execution-gate-secondary-to-data-issues');
  }
  if (summary.dataBlockingSeverity === 'CRITICAL') {
    findings.push('data-blocking-severity-critical');
  }
  if (!findings.length) findings.push('no-material-data-quality-findings');
  return [...new Set(findings)].slice(0, 7);
}

function buildDataQualityActionables(summary) {
  const actions = [];
  const counts = summary.counts;
  if (summary.dominantDataIssue === 'missing-close') {
    actions.push('backfill-missing-close-series-before-adjusting-gates');
  }
  if (counts.dataCoverageCount > 0) {
    actions.push('extend-trade-date-coverage-before-judging-longer-horizons');
  }
  if (counts.dataRelatedCount > counts.executionGateCount) {
    actions.push('fix-data-pipeline-before-relaxing-execution-thresholds');
  }
  if (counts.dataQualityCount > 0) {
    actions.push('validate-price-integrity-and-bad-data-filters');
  }
  if (summary.dataBlockingSeverity === 'CRITICAL') {
    actions.push('treat-data-repair-as-release-blocker-for-strategy-evaluation');
  }
  if (!actions.length) {
    actions.push('no-material-data-quality-action-required');
  }
  return [...new Set(actions)].slice(0, 7);
}


function buildEvaluationReadiness(dataQualitySummary, diagnosisRecords) {
  const parsePct = (value) => {
    const n = Number.parseFloat(String(value || '0').replace('%', ''));
    return Number.isFinite(n) ? n : 0;
  };

  const totalExecutedEvaluable = diagnosisRecords.reduce((sum, record) => sum + (record.executedEvaluable || 0), 0);
  const totalNonflatEvaluable = diagnosisRecords.reduce((sum, record) => sum + (record.nonflatEvaluable || 0), 0);
  const dataRelatedShare = parsePct(dataQualitySummary.dataRelatedShare);

  const strategyEvaluable = totalExecutedEvaluable > 0;
  const releaseBlocker = dataQualitySummary.dataBlockingSeverity === 'CRITICAL';

  let primaryBlocker = 'none';
  if (dataRelatedShare >= 50 || dataQualitySummary.dataBlockingSeverity === 'CRITICAL') primaryBlocker = 'data_gap';
  else if (!strategyEvaluable) primaryBlocker = 'execution_samples';
  else if (totalNonflatEvaluable < 10) primaryBlocker = 'sample_depth';

  const blockerReason = primaryBlocker === 'data_gap'
    ? (dataQualitySummary.dominantDataIssue || 'missing-close')
    : (primaryBlocker === 'execution_samples' ? 'no-executed-samples' : (primaryBlocker === 'sample_depth' ? 'insufficient-nonflat-samples' : 'none'));

  const dataSufficiency = dataRelatedShare > 50 ? 'INSUFFICIENT' : (dataRelatedShare >= 20 ? 'PARTIAL' : 'SUFFICIENT');
  const executionSampleStatus = totalExecutedEvaluable === 0 ? 'EMPTY' : (totalExecutedEvaluable < 5 ? 'SPARSE' : 'READY');
  const strategyEdgeAssessable = totalNonflatEvaluable >= 10 && strategyEvaluable && dataSufficiency === 'SUFFICIENT';

  let recommendedNextPhase = 'STRATEGY_TUNING';
  if (releaseBlocker || primaryBlocker === 'data_gap') recommendedNextPhase = 'DATA_REPAIR';
  else if (!strategyEvaluable) recommendedNextPhase = 'EXECUTION_COLLECTION';
  else if (!strategyEdgeAssessable) recommendedNextPhase = 'EDGE_COLLECTION';

  return {
    strategyEvaluable,
    releaseBlocker,
    primaryBlocker,
    blockerReason,
    dataSufficiency,
    executionSampleStatus,
    strategyEdgeAssessable,
    recommendedNextPhase,
  };
}


function buildDataCoverageMap(rows) {
  const skippedRows = rows.filter((row) => row.order_status === 'SKIPPED');
  const symbolMap = new Map();

  const ensureSymbol = (symbol) => {
    if (!symbolMap.has(symbol)) {
      symbolMap.set(symbol, {
        symbol,
        skippedRows: 0,
        totalReasonMarks: 0,
        dataRelatedMarks: 0,
        missingCloseMarks: 0,
        notEnoughTradeDaysMarks: 0,
        invalidDataMarks: 0,
        executionGateMarks: 0,
        checkpointCounts: new Map(),
        reasonCounts: new Map(),
        familyCounts: new Map(),
      });
    }
    return symbolMap.get(symbol);
  };

  for (const row of skippedRows) {
    const symbol = String(row.symbol || 'UNKNOWN').trim() || 'UNKNOWN';
    const entry = ensureSymbol(symbol);
    entry.skippedRows += 1;
    const marks = extractStructuredReasonMarks(row.review_note);
    const usable = marks.length ? marks : [{ checkpoint: 'UNSCOPED', rawMark: 'unknown' }];
    for (const mark of usable) {
      const normalized = normalizeReasonMark(mark.rawMark);
      entry.totalReasonMarks += 1;
      entry.reasonCounts.set(normalized.normalized, (entry.reasonCounts.get(normalized.normalized) || 0) + 1);
      entry.familyCounts.set(normalized.family, (entry.familyCounts.get(normalized.family) || 0) + 1);
      entry.checkpointCounts.set(mark.checkpoint, (entry.checkpointCounts.get(mark.checkpoint) || 0) + 1);
      if (['data_gap', 'data_coverage', 'data_quality'].includes(normalized.family)) entry.dataRelatedMarks += 1;
      if (normalized.normalized === 'missing-close') entry.missingCloseMarks += 1;
      if (normalized.normalized === 'not-enough-trade-days') entry.notEnoughTradeDaysMarks += 1;
      if (normalized.normalized === 'invalid-data') entry.invalidDataMarks += 1;
      if (normalized.family === 'execution_gate') entry.executionGateMarks += 1;
    }
  }

  const severityOrder = { CRITICAL: 4, HIGH: 3, MEDIUM: 2, LOW: 1, NONE: 0 };
  const results = [...symbolMap.values()].map((entry) => {
    const topReason = [...entry.reasonCounts.entries()].sort((a, b) => b[1] - a[1] || String(a[0]).localeCompare(String(b[0])))[0] || ['—', 0];
    const topCheckpoint = [...entry.checkpointCounts.entries()].sort((a, b) => b[1] - a[1] || String(a[0]).localeCompare(String(b[0])))[0] || ['UNSCOPED', 0];
    const dataRelatedShare = entry.totalReasonMarks > 0 ? (entry.dataRelatedMarks / entry.totalReasonMarks) * 100 : 0;
    let severity = 'LOW';
    if (entry.missingCloseMarks > 0 || dataRelatedShare >= 70) severity = 'CRITICAL';
    else if (entry.notEnoughTradeDaysMarks > 0 || dataRelatedShare >= 50) severity = 'HIGH';
    else if (entry.dataRelatedMarks > 0 || entry.executionGateMarks > 0) severity = 'MEDIUM';
    const primaryIssue = topReason[0];
    let repairAction = 'review-symbol-skip-notes';
    if (primaryIssue === 'missing-close') repairAction = 'backfill-close-series';
    else if (primaryIssue === 'not-enough-trade-days') repairAction = 'extend-trade-date-coverage';
    else if (primaryIssue === 'invalid-data') repairAction = 'repair-invalid-price-data';
    else if (entry.executionGateMarks > entry.dataRelatedMarks) repairAction = 'inspect-execution-path';

    return {
      symbol: entry.symbol,
      skippedRows: entry.skippedRows,
      totalReasonMarks: entry.totalReasonMarks,
      dataRelatedMarks: entry.dataRelatedMarks,
      dataRelatedShare,
      missingCloseMarks: entry.missingCloseMarks,
      notEnoughTradeDaysMarks: entry.notEnoughTradeDaysMarks,
      invalidDataMarks: entry.invalidDataMarks,
      executionGateMarks: entry.executionGateMarks,
      primaryIssue,
      primaryIssueCount: topReason[1],
      primaryIssueShare: entry.totalReasonMarks > 0 ? (topReason[1] / entry.totalReasonMarks) * 100 : 0,
      primaryCheckpoint: topCheckpoint[0],
      primaryCheckpointCount: topCheckpoint[1],
      blockerSeverity: severity,
      repairAction,
    };
  }).sort((a, b) => {
    const sev = (severityOrder[b.blockerSeverity] || 0) - (severityOrder[a.blockerSeverity] || 0);
    if (sev !== 0) return sev;
    const mc = b.missingCloseMarks - a.missingCloseMarks;
    if (mc !== 0) return mc;
    const dr = b.dataRelatedShare - a.dataRelatedShare;
    if (dr !== 0) return dr;
    return a.symbol.localeCompare(b.symbol);
  });

  return {
    symbols: results,
    repairTargets: results.filter((entry) => entry.blockerSeverity !== 'LOW' || entry.primaryIssue !== 'unknown').slice(0, 7),
  };
}

function buildGateRecommendations(skipBreakdown) {
  const recommendations = [];
  const topFamily = skipBreakdown.topFamily;
  if (topFamily === 'execution_gate') recommendations.push('inspect-execution-gate-thresholds-before-model-tuning');
  if (topFamily === 'data_coverage') recommendations.push('improve-review-data-coverage-before-attributing-skip-pressure-to-ranking');
  if (topFamily === 'sizing_liquidity') recommendations.push('review-budget-min-qty-and-notional-constraints');
  if (topFamily === 'ranking_filter') recommendations.push('audit-ranking-cutoffs-and-selection-thresholds');
  if (topFamily === 'data_quality') recommendations.push('repair-price-and-close-data-quality-issues-before-expanding-universe');
  if (skipBreakdown.topReason === 'signal-generated-but-not-filled') recommendations.push('trace-unfilled-orders-from-signal-to-order-fill-gates');
  if (!recommendations.length && skipBreakdown.skippedRows > 0) recommendations.push('review-dominant-skip-reason-before-changing-strategy-logic');
  return [...new Set(recommendations)].slice(0, 5);
}




function statusFromSeverity(severity) {
  if (severity === 'CRITICAL' || severity === 'HIGH') return 'BLOCKED';
  if (severity === 'MEDIUM') return 'WARNING';
  return 'CLEARED';
}

function transitionGateForEntry(entry) {
  if (entry.primaryIssue === 'missing-close') return 'close-series-backfill-complete';
  if (entry.primaryIssue === 'not-enough-trade-days') return 'trade-date-coverage-extended';
  if (entry.primaryIssue === 'invalid-data') return 'invalid-price-data-repaired';
  if (entry.executionGateMarks > entry.dataRelatedMarks) return 'execution-path-validated';
  return 'repair-notes-reviewed';
}

function buildSymbolRepairTransitions(coverageMap, evaluationReadiness) {
  const symbols = (coverageMap.symbols || []).map((entry, index) => {
    const currentStatus = statusFromSeverity(entry.blockerSeverity);
    const targetStatus = currentStatus === 'BLOCKED' ? 'WARNING' : (currentStatus === 'WARNING' ? 'CLEARED' : 'CLEARED');
    const transitionGate = transitionGateForEntry(entry);
    const readinessAfterTransition = targetStatus === 'CLEARED'
      ? (evaluationReadiness.strategyEvaluable ? 'STRATEGY_EVALUATION' : 'VALIDATE_EXECUTION_AFTER_REPAIR')
      : 'VALIDATE_REPAIRED_DATA';
    return {
      ...entry,
      priority: `P${Math.min(index + 1, 9)}`,
      currentStatus,
      targetStatus,
      transitionGate,
      readinessAfterTransition,
    };
  });

  const blockedToWarning = symbols.filter((entry) => entry.currentStatus === 'BLOCKED').length;
  const warningToCleared = symbols.filter((entry) => entry.currentStatus === 'WARNING').length;
  const alreadyCleared = symbols.filter((entry) => entry.currentStatus === 'CLEARED').length;
  const gateCounts = {}
  for (const entry of symbols) {
    gateCounts[entry.transitionGate] = (gateCounts[entry.transitionGate] || 0) + 1;
  }
  const dominantTransitionGate = Object.entries(gateCounts).sort((a,b)=> b[1]-a[1] || String(a[0]).localeCompare(String(b[0])))[0]?.[0] || '—';
  const nextTransitionPhase = blockedToWarning > 0
    ? 'REPAIR_BLOCKERS'
    : (warningToCleared > 0 ? 'VALIDATE_REPAIRED_DATA' : 'STRATEGY_EVALUATION');

  return {
    symbols,
    summary: {
      trackedSymbols: symbols.length,
      blockedToWarningCandidates: blockedToWarning,
      warningToClearedCandidates: warningToCleared,
      alreadyCleared,
      dominantTransitionGate,
      nextTransitionPhase,
    },
  };
}

function buildSymbolRepairTransitionActions(transitions, evaluationReadiness) {
  const actions = [];
  if ((transitions.summary.blockedToWarningCandidates || 0) > 0) {
    actions.push('promote-blocked-symbols-to-warning-by-closing-primary-repair-gates');
  }
  if ((transitions.summary.warningToClearedCandidates || 0) > 0) {
    actions.push('validate-warning-symbols-and-clear-them-after-repair-checks');
  }
  if ((evaluationReadiness.executionSampleStatus || 'EMPTY') === 'EMPTY') {
    actions.push('collect-executed-samples-after-symbols-exit-blocked-state');
  }
  if ((transitions.summary.alreadyCleared || 0) > 0) {
    actions.push('advance-cleared-symbols-to-strategy-evaluation');
  }
  if (!actions.length) actions.push('maintain-current-symbol-transition-state');
  return [...new Set(actions)].slice(0, 7);
}

function buildRepairReadiness(coverageMap, evaluationReadiness) {
  const severityOrder = { CRITICAL: 4, HIGH: 3, MEDIUM: 2, LOW: 1, NONE: 0 };
  const symbols = coverageMap.symbols || [];
  const blockedSymbols = symbols.filter((entry) => (severityOrder[entry.blockerSeverity] || 0) >= 3);
  const warningSymbols = symbols.filter((entry) => entry.blockerSeverity === 'MEDIUM');
  const clearedSymbols = symbols.filter((entry) => (severityOrder[entry.blockerSeverity] || 0) <= 1);
  const repairActionCounts = new Map();
  for (const entry of coverageMap.repairTargets || []) {
    repairActionCounts.set(entry.repairAction, (repairActionCounts.get(entry.repairAction) || 0) + 1);
  }
  const dominantRepairAction = [...repairActionCounts.entries()].sort((a, b) => b[1] - a[1] || String(a[0]).localeCompare(String(b[0])))[0]?.[0] || '—';
  let blockerClearanceStatus = 'CLEARED';
  if (evaluationReadiness.releaseBlocker || blockedSymbols.length > 0) blockerClearanceStatus = 'BLOCKED';
  else if (warningSymbols.length > 0 || !evaluationReadiness.strategyEvaluable) blockerClearanceStatus = 'PARTIAL';

  let repairProgressStage = 'READY_FOR_STRATEGY_EVALUATION';
  if (blockerClearanceStatus === 'BLOCKED') repairProgressStage = 'DATA_REPAIR_REQUIRED';
  else if (!evaluationReadiness.strategyEvaluable || !evaluationReadiness.strategyEdgeAssessable) repairProgressStage = 'POST_REPAIR_VALIDATION';

  const readyForStrategyEvaluation = blockerClearanceStatus === 'CLEARED'
    && evaluationReadiness.strategyEvaluable
    && evaluationReadiness.strategyEdgeAssessable;

  const postRepairNextPhase = readyForStrategyEvaluation
    ? 'STRATEGY_EVALUATION'
    : (blockerClearanceStatus === 'BLOCKED' ? 'DATA_REPAIR' : 'VALIDATE_REPAIRED_DATA');

  return {
    trackedSymbols: symbols.length,
    blockedSymbols: blockedSymbols.length,
    warningSymbols: warningSymbols.length,
    clearedSymbols: clearedSymbols.length,
    criticalTargets: symbols.filter((entry) => entry.blockerSeverity === 'CRITICAL').length,
    highTargets: symbols.filter((entry) => entry.blockerSeverity === 'HIGH').length,
    mediumTargets: warningSymbols.length,
    dominantRepairAction,
    blockerClearanceStatus,
    repairProgressStage,
    readyForStrategyEvaluation,
    postRepairNextPhase,
  };
}

function buildRepairProgressFindings(repairReadiness, coverageMap, evaluationReadiness) {
  const findings = [];
  if (repairReadiness.blockerClearanceStatus === 'BLOCKED') findings.push('repair-blockers-still-open');
  if ((repairReadiness.criticalTargets || 0) > 0) findings.push('critical-symbol-repair-targets-remain');
  if ((repairReadiness.dominantRepairAction || '—') === 'backfill-close-series') findings.push('close-series-backfill-remains-primary-repair-path');
  if (evaluationReadiness.executionSampleStatus === 'EMPTY') findings.push('post-repair-execution-validation-still-pending');
  if (repairReadiness.readyForStrategyEvaluation) findings.push('repair-state-ready-for-strategy-evaluation');
  if (!findings.length) findings.push('repair-readiness-stable-no-new-findings');
  return findings.slice(0, 7);
}

function buildRepairProgressActions(repairReadiness, coverageMap, evaluationReadiness) {
  const actions = [];
  if (repairReadiness.blockerClearanceStatus === 'BLOCKED') actions.push('close-open-repair-targets-before-promoting-strategy-work');
  if ((repairReadiness.dominantRepairAction || '—') === 'backfill-close-series') actions.push('complete-close-series-backfill-for-priority-symbols');
  if ((repairReadiness.highTargets || 0) > 0 || (repairReadiness.mediumTargets || 0) > 0) actions.push('rerun-scoreboard-after-data-backfill-to-check-blocker-clearance');
  if (evaluationReadiness.executionSampleStatus === 'EMPTY') actions.push('collect-first-executed-samples-after-data-repair');
  if (repairReadiness.readyForStrategyEvaluation) actions.push('advance-to-strategy-evaluation-and-edge-validation');
  if (!actions.length) actions.push('maintain-current-repair-state-and-monitor-new-blockers');
  return [...new Set(actions)].slice(0, 7);
}


if (diagnosisRecords.length > 0) {
  const dominantStatusConsensus = mostCommon(diagnosisRecords, (record) => record.diagnosis.dominantStatus);
  const gatePressureConsensus = mostCommon(diagnosisRecords, (record) => record.diagnosis.gatePressure);
  const edgeStateConsensus = mostCommon(diagnosisRecords, (record) => record.diagnosis.edgeState);
  const horizonSignalConsensus = mostCommon(diagnosisRecords, (record) => record.diagnosis.horizonSignalStrength);

  const strongestSignalOrder = { STRONG: 4, MODERATE: 3, WEAK: 2, INERT: 1, NONE: 0 };
  const strongestSignalRecord = [...diagnosisRecords].sort((a, b) => {
    const scoreDiff = (strongestSignalOrder[b.diagnosis.horizonSignalStrength] ?? -1) - (strongestSignalOrder[a.diagnosis.horizonSignalStrength] ?? -1);
    if (scoreDiff !== 0) return scoreDiff;
    const decisiveDiff = b.decisiveRate - a.decisiveRate;
    if (decisiveDiff !== 0) return decisiveDiff;
    return a.checkpoint.localeCompare(b.checkpoint);
  })[0];

  const maxGapRecord = [...diagnosisRecords].sort((a, b) => {
    const aGap = Number.parseFloat(String(a.diagnosis.executionCoverageGap).replace('%', '')) || 0;
    const bGap = Number.parseFloat(String(b.diagnosis.executionCoverageGap).replace('%', '')) || 0;
    return bGap - aGap || a.checkpoint.localeCompare(b.checkpoint);
  })[0];

  const avgPositiveRate = diagnosisRecords.length
    ? diagnosisRecords.reduce((sum, record) => sum + record.positiveRate, 0) / diagnosisRecords.length
    : NaN;
  const avgExecutedShare = diagnosisRecords.length
    ? diagnosisRecords.reduce((sum, record) => sum + (record.evaluable > 0 ? (record.executedEvaluable / record.evaluable) * 100 : 0), 0) / diagnosisRecords.length
    : NaN;
  const maxExecutionCoverageGap = Number.parseFloat(String(maxGapRecord?.diagnosis.executionCoverageGap ?? '0').replace('%', '')) || 0;
  const batchSummary = {
    dominantStatusConsensus,
    gatePressureConsensus,
    edgeStateConsensus,
    horizonSignalConsensus,
    strongestHorizonCheckpoint: strongestSignalRecord?.checkpoint ?? '—',
    strongestHorizonSignal: strongestSignalRecord?.diagnosis.horizonSignalStrength ?? '—',
    maxExecutionCoverageGap,
    maxExecutionCoverageGapCheckpoint: maxGapRecord?.checkpoint ?? '—',
    avgPositiveRate: Number.isFinite(avgPositiveRate) ? avgPositiveRate : NaN,
    avgExecutedShare: Number.isFinite(avgExecutedShare) ? avgExecutedShare : NaN,
  };

  console.log('batch_level_summary:');
  console.log(`evaluated_checkpoints=${diagnosisRecords.length}`);
  console.log(`dominant_status_consensus=${dominantStatusConsensus}`);
  console.log(`gate_pressure_consensus=${gatePressureConsensus}`);
  console.log(`edge_state_consensus=${edgeStateConsensus}`);
  console.log(`horizon_signal_consensus=${horizonSignalConsensus}`);
  console.log(`strongest_horizon_checkpoint=${batchSummary.strongestHorizonCheckpoint}`);
  console.log(`strongest_horizon_signal=${batchSummary.strongestHorizonSignal}`);
  console.log(`max_execution_coverage_gap=${Number.isFinite(batchSummary.maxExecutionCoverageGap) ? `${batchSummary.maxExecutionCoverageGap.toFixed(2)}%` : '0.00%'}`);
  console.log(`max_execution_coverage_gap_checkpoint=${batchSummary.maxExecutionCoverageGapCheckpoint}`);
  console.log(`average_positive_rate=${Number.isFinite(batchSummary.avgPositiveRate) ? `${batchSummary.avgPositiveRate.toFixed(2)}%` : '—'}`);
  console.log(`average_executed_share=${Number.isFinite(batchSummary.avgExecutedShare) ? `${batchSummary.avgExecutedShare.toFixed(2)}%` : '—'}`);
  console.log('');

  const findings = uniqueFindings([
    diagnosisRecords.every((record) => record.diagnosis.dominantStatus === 'skipped') ? 'skipped-dominates-all-checkpoints' : '',
    diagnosisRecords.every((record) => record.executedEvaluable === 0) ? 'no-executed-samples-observed' : '',
    diagnosisRecords.every((record) => record.diagnosis.gatePressure === 'HIGH') ? 'execution-gate-pressure-high-across-checkpoints' : '',
    diagnosisRecords.every((record) => record.diagnosis.edgeState === 'FLAT_SAMPLE') ? 'all-checkpoints-flat-sample' : '',
    diagnosisRecords.every((record) => record.diagnosis.horizonSignalStrength === 'INERT') ? 'horizon-signal-inert-across-checkpoints' : '',
    diagnosisRecords.some((record) => (Number.parseFloat(String(record.diagnosis.executionCoverageGap).replace('%', '')) || 0) >= 50) ? 'execution-coverage-gap-material' : '',
    strongestSignalRecord ? `strongest-horizon-${strongestSignalRecord.checkpoint.toLowerCase()}-${String(strongestSignalRecord.diagnosis.horizonSignalStrength || '').toLowerCase()}` : '',
  ]);

  console.log('top_findings:');
  findings.forEach((finding, index) => {
    console.log(`${index + 1}=${finding}`);
  });
  if (findings.length === 0) console.log('1=no-material-findings');
  console.log('');

  const recommendations = buildActionableRecommendations(diagnosisRecords, batchSummary);
  console.log('actionable_recommendations:');
  recommendations.forEach((recommendation, index) => {
    console.log(`${index + 1}=${recommendation}`);
  });
  if (recommendations.length === 0) console.log('1=no-action-required');
  console.log('');

  const skipBreakdown = buildSkipReasonBreakdown(normalizedItems);
  console.log('skip_reason_breakdown:');
  console.log(`skipped_rows=${skipBreakdown.skippedRows}`);
  console.log(`total_reason_marks=${skipBreakdown.totalReasonMarks}`);
  console.log(`top_reason=${skipBreakdown.topReason}`);
  console.log(`top_reason_share=${skipBreakdown.topReasonShare}`);
  console.log(`top_gate_family=${skipBreakdown.topFamily}`);
  console.log(`top_gate_family_share=${skipBreakdown.topFamilyShare}`);
  console.log('');

  console.log('gate_attribution:');
  if (skipBreakdown.sortedFamilies.length) {
    skipBreakdown.sortedFamilies.forEach(([family, count], index) => {
      const share = skipBreakdown.totalReasonMarks > 0 ? ((count / skipBreakdown.totalReasonMarks) * 100).toFixed(2) + '%' : '0.00%';
      console.log(`${index + 1}=${family}|count=${count}|share=${share}`);
    });
  } else {
    console.log('1=no-skip-gate-data');
  }
  console.log('');

  console.log('top_skip_reasons:');
  if (skipBreakdown.sortedReasons.length) {
    skipBreakdown.sortedReasons.slice(0, 7).forEach(([reason, count], index) => {
      const share = skipBreakdown.totalReasonMarks > 0 ? ((count / skipBreakdown.totalReasonMarks) * 100).toFixed(2) + '%' : '0.00%';
      console.log(`${index + 1}=${reason}|count=${count}|share=${share}`);
    });
  } else {
    console.log('1=no-skip-reasons-observed');
  }
  console.log('');

  const gateRecommendations = buildGateRecommendations(skipBreakdown);
  console.log('gate_actionables:');
  gateRecommendations.forEach((recommendation, index) => {
    console.log(`${index + 1}=${recommendation}`);
  });
  if (gateRecommendations.length === 0) console.log('1=no-gate-action-required');
  console.log('');

  const dataQualitySummary = buildDataQualitySummary(skipBreakdown);
  console.log('data_quality_summary:');
  console.log(`data_related_reason_share=${dataQualitySummary.dataRelatedShare}`);
  console.log(`dominant_data_issue=${dataQualitySummary.dominantDataIssue}`);
  console.log(`dominant_data_issue_share=${dataQualitySummary.dominantDataIssueShare}`);
  console.log(`coverage_issue_share=${dataQualitySummary.coverageIssueShare}`);
  console.log(`missing_data_issue_share=${dataQualitySummary.missingDataIssueShare}`);
  console.log(`data_quality_issue_share=${dataQualitySummary.dataQualityIssueShare}`);
  console.log(`execution_gate_share=${dataQualitySummary.executionGateShare}`);
  console.log(`data_blocking_severity=${dataQualitySummary.dataBlockingSeverity}`);
  console.log('');

  const dataQualityFindings = buildDataQualityFindings(dataQualitySummary);
  console.log('data_quality_findings:');
  dataQualityFindings.forEach((finding, index) => {
    console.log(`${index + 1}=${finding}`);
  });
  if (dataQualityFindings.length === 0) console.log('1=no-material-data-quality-findings');
  console.log('');

  const dataQualityActions = buildDataQualityActionables(dataQualitySummary);
  console.log('data_quality_actionables:');
  dataQualityActions.forEach((action, index) => {
    console.log(`${index + 1}=${action}`);
  });
  if (dataQualityActions.length === 0) console.log('1=no-material-data-quality-action-required');
  console.log('');

  const evaluationReadiness = buildEvaluationReadiness(dataQualitySummary, diagnosisRecords);
  console.log('evaluation_readiness:');
  console.log(`strategy_evaluable=${evaluationReadiness.strategyEvaluable ? 'true' : 'false'}`);
  console.log(`release_blocker=${evaluationReadiness.releaseBlocker ? 'true' : 'false'}`);
  console.log(`primary_blocker=${evaluationReadiness.primaryBlocker}`);
  console.log(`blocker_reason=${evaluationReadiness.blockerReason}`);
  console.log(`data_sufficiency=${evaluationReadiness.dataSufficiency}`);
  console.log(`execution_sample_status=${evaluationReadiness.executionSampleStatus}`);
  console.log(`strategy_edge_assessable=${evaluationReadiness.strategyEdgeAssessable ? 'true' : 'false'}`);
  console.log(`recommended_next_phase=${evaluationReadiness.recommendedNextPhase}`);
  console.log('');

  const coverageMap = buildDataCoverageMap(normalizedItems);
  console.log('data_coverage_map:');
  if (coverageMap.symbols.length) {
    coverageMap.symbols.forEach((entry, index) => {
      console.log(`${index + 1}=${entry.symbol}|skipped_rows=${entry.skippedRows}|reason_marks=${entry.totalReasonMarks}|data_related_share=${entry.dataRelatedShare.toFixed(2)}%|missing_close=${entry.missingCloseMarks}|not_enough_trade_days=${entry.notEnoughTradeDaysMarks}|execution_gate=${entry.executionGateMarks}|primary_issue=${entry.primaryIssue}|primary_checkpoint=${entry.primaryCheckpoint}|blocker_severity=${entry.blockerSeverity}`);
    });
  } else {
    console.log('1=no-symbol-level-coverage-issues');
  }
  console.log('');

  console.log('repair_targets:');
  if (coverageMap.repairTargets.length) {
    coverageMap.repairTargets.forEach((entry, index) => {
      console.log(`${index + 1}=${entry.symbol}|priority=P${Math.min(index + 1, 9)}|issue=${entry.primaryIssue}|checkpoint=${entry.primaryCheckpoint}|severity=${entry.blockerSeverity}|action=${entry.repairAction}`);
    });
  } else {
    console.log('1=no-priority-repair-targets');
  }
  console.log('');

  const repairReadiness = buildRepairReadiness(coverageMap, evaluationReadiness);
  console.log('repair_readiness_summary:');
  console.log(`tracked_symbols=${repairReadiness.trackedSymbols}`);
  console.log(`blocked_symbols=${repairReadiness.blockedSymbols}`);
  console.log(`warning_symbols=${repairReadiness.warningSymbols}`);
  console.log(`cleared_symbols=${repairReadiness.clearedSymbols}`);
  console.log(`critical_targets=${repairReadiness.criticalTargets}`);
  console.log(`high_targets=${repairReadiness.highTargets}`);
  console.log(`medium_targets=${repairReadiness.mediumTargets}`);
  console.log(`dominant_repair_action=${repairReadiness.dominantRepairAction}`);
  console.log(`blocker_clearance_status=${repairReadiness.blockerClearanceStatus}`);
  console.log(`repair_progress_stage=${repairReadiness.repairProgressStage}`);
  console.log(`ready_for_strategy_evaluation=${repairReadiness.readyForStrategyEvaluation ? 'true' : 'false'}`);
  console.log(`post_repair_next_phase=${repairReadiness.postRepairNextPhase}`);
  console.log('');

  const repairProgressFindings = buildRepairProgressFindings(repairReadiness, coverageMap, evaluationReadiness);
  console.log('repair_progress_findings:');
  repairProgressFindings.forEach((finding, index) => {
    console.log(`${index + 1}=${finding}`);
  });
  if (repairProgressFindings.length === 0) console.log('1=no-repair-progress-findings');
  console.log('');

  const repairProgressActions = buildRepairProgressActions(repairReadiness, coverageMap, evaluationReadiness);
  console.log('repair_progress_actions:');
  repairProgressActions.forEach((action, index) => {
    console.log(`${index + 1}=${action}`);
  });
  if (repairProgressActions.length === 0) console.log('1=no-repair-progress-actions');
  console.log('');

  const symbolTransitions = buildSymbolRepairTransitions(coverageMap, evaluationReadiness);
  console.log('symbol_repair_status_transitions:');
  if (symbolTransitions.symbols.length) {
    symbolTransitions.symbols.forEach((entry, index) => {
      console.log(`${index + 1}=${entry.symbol}|priority=${entry.priority}|current_status=${entry.currentStatus}|target_status=${entry.targetStatus}|transition_gate=${entry.transitionGate}|readiness_after_transition=${entry.readinessAfterTransition}`);
    });
  } else {
    console.log('1=no-symbol-repair-transitions');
  }
  console.log('');

  console.log('repair_transition_summary:');
  console.log(`tracked_symbols=${symbolTransitions.summary.trackedSymbols}`);
  console.log(`blocked_to_warning_candidates=${symbolTransitions.summary.blockedToWarningCandidates}`);
  console.log(`warning_to_cleared_candidates=${symbolTransitions.summary.warningToClearedCandidates}`);
  console.log(`already_cleared=${symbolTransitions.summary.alreadyCleared}`);
  console.log(`dominant_transition_gate=${symbolTransitions.summary.dominantTransitionGate}`);
  console.log(`next_transition_phase=${symbolTransitions.summary.nextTransitionPhase}`);
  console.log('');

  const symbolTransitionActions = buildSymbolRepairTransitionActions(symbolTransitions, evaluationReadiness);
  console.log('repair_transition_actions:');
  symbolTransitionActions.forEach((action, index) => {
    console.log(`${index + 1}=${action}`);
  });
  if (symbolTransitionActions.length === 0) console.log('1=no-repair-transition-actions');
  console.log('');
}

console.log('Recommendation scoreboard OK');
