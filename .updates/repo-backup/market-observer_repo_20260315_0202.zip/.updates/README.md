MO updates workspace
