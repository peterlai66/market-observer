## 0.10.1 update
- toolchain 修正：`deploy` / `logs` 改用 `npx wrangler ...`，減少本機 PATH 問題。
- 新增 GPT-4o mini 解釋層：LINE 可用 `解釋狀態`、`解釋報告`、`解釋建議`。
- 修正 AI 開啟後 webhook 可能卡住不回應的問題：OpenAI 呼叫現在有短 timeout，失敗時會自動降級回原始摘要。

## 0.10.0 update
- MO 已進入成交閉環第一階段：strategy output 不只會產生 `mo_orders`，也會在 recommendation 與 execution 兩端做成本感知過濾。
- 新增交易守門概念：`minQty`、`minNotionalTwd`、`roundTripCost`、`edge_lt_cost`。
- 目前 TW ETF 採保守規則：先過成本與最小量門檻，再進入 PENDING / EXECUTED / SKIPPED 流程。

# PROJECT

## Current state
- CLI / update / smoke / deploy pipeline stable
- ETF universe comes from env -> D1 -> default fallback
- Multi-asset engine now generates candidates from universe snapshots
- 0.9.0 adds conservative starter fallback so the system can move from pure observation to actionable recommendations
- LINE commands for operational verification: 狀態 / 建議 / debug / universe

- 0.9.1: final recommendation close-price mapping now resolves TW ETF prices from raw close, OHLC fallback, and candidate fallback before rejecting for invalid close.
