## 0.14.2
- Added weekly operator message layer for report payload shaping and publish-ready messaging.

# 0.14.0

- Added weekly_run_gating_summary / findings / actions to recommendation-scoreboard.
- Added weekly report vs simulation gating based on operator decision.

## 0.13.9
- Add `operator_final_decision_summary`, `operator_final_decision_findings`, and `operator_final_decision_actions` to `mo recommendation-scoreboard`.
- Collapse the full repair->unlock pipeline into a final operator decision view for immediate next action.

# Release Notes

## 0.13.8
- Added pipeline advancement criteria layer to recommendation-scoreboard.
- Added pipeline_advancement_summary and pipeline_advancement_actions.


## 0.13.7
- add pipeline_readiness_summary / pipeline_readiness_findings / pipeline_readiness_actions
- summarize repair, warning, recheck, promotion, and unlock state into one top-level pipeline view

## 0.13.6
- add strategy evaluation unlock layer to recommendation-scoreboard
- add symbol_strategy_evaluation_unlock / strategy_evaluation_unlock_summary / strategy_evaluation_unlock_actions

## 0.13.5
- add post-repair recheck outcome layer to recommendation-scoreboard
- add symbol_post_repair_recheck_outcomes / post_repair_recheck_summary / post_repair_recheck_actions

0.13.5
0.13.2
- Added symbol_repair_status_transitions, repair_transition_summary, and repair_transition_actions.

## 0.13.0
- Repair Progress / Blocker Clearance
- `mo recommendation-scoreboard` 新增 `repair_readiness_summary`、`repair_progress_findings`、`repair_progress_actions`。
- 會在 `data_coverage_map` / `repair_targets` 之後，直接判斷 blocker 是否仍未解除，以及修復後是否已可進入 `STRATEGY_EVALUATION`。
- 驗證順序：先 `npm run mo -- doctor`，再 `npm run mo -- recommendation-scoreboard`，最後確認已出現 `repair_readiness_summary:`、`repair_progress_findings:`、`repair_progress_actions:`。

0.12.9

## 0.12.9
- Data Coverage Map / Repair Targets
- `mo recommendation-scoreboard` 新增 `data_coverage_map` 與 `repair_targets`。
- 會依 symbol 彙總 skip reason、data-related share、主要 issue、主要 checkpoint 與 blocker severity，直接指出優先修資料的標的。
- 驗證順序：先 `npm run mo -- doctor`，再 `npm run mo -- recommendation-scoreboard`，最後確認已出現 `data_coverage_map:` 與 `repair_targets:`。

0.12.8

## 0.12.7
- Data Quality Action Layer
- `mo recommendation-scoreboard` 在 `skip_reason_breakdown / gate_attribution / top_skip_reasons / gate_actionables` 之後，新增 `data_quality_summary`、`data_quality_findings`、`data_quality_actionables`。
- 會直接判讀資料缺口是否主導 skip，例如 `missing-close`、`not-enough-trade-days` 是否比 execution gate 更需要優先修復。
- 驗證順序：先 `npm run mo -- doctor`，再 `npm run mo -- recommendation-scoreboard`，最後確認已出現 data quality 三個新區塊。

## 0.12.6
- Structured Skip Reason Normalization
- `mo recommendation-scoreboard` 修正會一併查詢 `review_note`，不再把 skipped rows 全部誤歸為 `unknown`。
- 新增 structured normalization：把 `D20:not-enough-trade-days`、`D5:missing-close`、`signal-generated-but-not-filled` 等標記正規化成穩定 skip reason。
- `skip_reason_breakdown` / `gate_attribution` / `top_skip_reasons` 會優先輸出 normalization 後的 reason 與 gate family，例如 `data_coverage`、`data_gap`、`execution_gate`。
- 驗證順序：先 `npm run mo -- doctor`，再 `npm run mo -- recommendation-scoreboard`，最後確認不再只看到 `unknown / other`。

## 0.12.5
- Actionable Recommendations Layer
- `mo recommendation-scoreboard` 在 `batch_level_summary` / `top_findings` 之後，新增 `actionable_recommendations` 區塊。
- 依據 gate pressure、executed share、edge state、horizon signal，自動輸出下一步建議，例如先補 executed samples、先查 skip gate、暫緩 horizon 最適化。
- 驗證順序：先 `npm run mo -- doctor`，再 `npm run mo -- recommendation-scoreboard`，最後檢查 `actionable_recommendations:` 是否有正常輸出。

## 0.12.3
- Batch-Level Summary / Top Findings
- `mo recommendation-scoreboard` 在各 checkpoint diagnosis 之後，新增 `batch_level_summary` 與 `top_findings` 區塊。
- `batch_level_summary` 會輸出 `dominant_status_consensus`、`gate_pressure_consensus`、`edge_state_consensus`、`horizon_signal_consensus`、`strongest_horizon_checkpoint`、`max_execution_coverage_gap`、`average_positive_rate`、`average_executed_share`。
- `top_findings` 會直接列出本批次最重要的觀察，讓 scoreboard 從可讀提升到可快速判讀。

## 0.12.2
- Recommendation Diagnosis Layer
- `mo recommendation-scoreboard` 在既有 outcome / classification / performance / rolling / execution_summary 之外，新增 `D0 / D5 / D10 / D20` 的 `diagnosis` 區塊。
- 每個 checkpoint 會額外輸出 `dominant_status`、`dominant_status_share`、`gate_pressure`、`edge_state`、`horizon_signal_strength`、`execution_coverage_gap`、`interpretation`。
- 驗證順序：先 `npm run mo -- doctor`，再 `npm run mo -- recommendation-scoreboard`，最後檢查各 checkpoint 的 `*_diagnosis`。

## 0.12.1
- Execution-Aware Performance Summary
- `mo recommendation-scoreboard` 在既有 outcome / classification / performance / rolling 之外，新增 `D0 / D5 / D10 / D20` 的 `execution_summary` 區塊。
- 每個 checkpoint 會額外輸出 `overall / executed / skipped / pending` 的：`evaluable`、`share_of_evaluable`、`average_return`、`positive_rate`、`win_rate`、`loss_rate`、`flat_rate`、`expectancy`、`decisive_rate`。
- 驗證順序：先 `npm run mo -- doctor`，再 `npm run mo -- recommendation-scoreboard`，最後檢查各 checkpoint 的 `*_execution_summary`。

## 0.12.0
- Recommendation Performance Engine
- `mo recommendation-scoreboard` 新增 checkpoint performance 指標：`expectancy`、`avg_win_return`、`avg_loss_return`、`edge_ratio`、`nonflat_evaluable`、`decisive_rate`。
- 新增 rolling 視角：`last_1_batch` / `last_3_batch` / `last_5_batch` 的 evaluable、average_return、positive_rate。
- 新增 `BASELINE.json` 與 `mo baseline`；release 會自動寫入 locked baseline manifest。
- 驗證順序：先 `npm run mo -- doctor`，再 `npm run mo -- recommendation-scoreboard`，最後 `npm run mo -- baseline`。

Recommendation Outcome Classification

## 0.11.9

本版擴充 `mo recommendation-scoreboard`，在既有 D0 / D5 / D10 / D20 outcome metrics 之外，新增 outcome classification 區塊：
- `win / loss / flat`
- `win_rate / loss_rate / flat_rate`
- `executed / skipped / pending` 的 `evaluable` 與 `average_return`

用途：讓 scoreboard 在目前樣本多為 skipped 或回報為 `+0.00%` 時，能更清楚區分是「真的 flat」還是「不同 execution status 的混合結果」。

建議驗證：
1. `npm run mo -- doctor`
2. `npm run mo -- recommendation-scoreboard`

預期：
- 舊的 summary 欄位與 D0 / D5 / D10 / D20 outcome metrics 仍存在
- 每個 checkpoint 下面新增 classification 區塊
- 會顯示 `win / loss / flat` 與 `executed / skipped / pending` 切片

## 0.11.8
- Extend `mo recommendation-scoreboard` with checkpoint outcome summary for D0 / D5 / D10 / D20.
- New outcome metrics: `evaluable`, `coverage`, `positive`, `positive_rate`, `average_return`.
- Existing scoreboard summary fields remain unchanged for backward compatibility.

# 0.11.7

- Fix `mo recommendation-scoreboard` so remote D1 queries normalize SQL before passing to Wrangler on Windows.
- Add empty-SQL guard in recommendation review query helper.

# 0.11.6
- Added `mo recommendation-scoreboard` to summarize saved recommendation review snapshots.
- Updated CLI/help/doctor/docs for the new verification command.

## 0.11.5
- 修正 `recommendation-review-save` 在 Windows / cmd 環境下以 `--command` 傳多行 SQL 造成 Wrangler 判定缺少 `--command` 的問題。
- `execSql()` 現在會先將 SQL 正規化為單行再送給 `wrangler d1 execute`。

## 0.11.3
- 新增 `mo recommendation-review-save`，把最新推薦批次 review 結果落表到 D1。
- 自動建立 `mo_recommendation_review_batches`、`mo_recommendation_review_items`。
- 為後續 scoreboard / 命中率統計建立正式 snapshot 基線。

## 0.11.3
- `mo recommendation-review` 輸出強化：新增 `max_review_horizon`、`available_checkpoints`、`pending_checkpoints`，並明確區分 `not-enough-trade-days`、`missing-close`、`signal-generated-but-not-filled`。

# Release Notes

## 0.11.1
- 新增 `mo recommendation-review`，用最新推薦批次回看 D0 / D5 / D10 / D20 的模擬表現。
- 明確校正 MO 定位：MO 是推薦驗證系統，不是實盤交易系統；portfolio / orders / execution marks 屬於推薦驗證用模擬資料層。
- 同步更新 `MO_START.md`、`docs/PROJECT.md`、`docs/AI_MEMORY.md`、`docs/NEXT_TASK.md`、`docs/BUGS.md`、`docs/FUTURE_SYSTEMS.md`、`docs/commands.md`、`developer/SCRIPTS_GUIDE.md`。

## 驗證重點
1. `npm run mo -- doctor` 後，版本應顯示為 `market-observer@0.11.1`。
2. `npm run mo -- recommendation-review` 應成功，輸出最新推薦批次的 D0 / D5 / D10 / D20 表現。
3. 若目前尚不足 20 個交易日資料，腳本應顯示 partial review / D20 summary skip，而不是失敗。



- 0.14.2: added weekly_delivery_formatting_summary / weekly_delivery_formatting_blocks / weekly_delivery_formatting_actions for LINE/email/log payload shaping.
