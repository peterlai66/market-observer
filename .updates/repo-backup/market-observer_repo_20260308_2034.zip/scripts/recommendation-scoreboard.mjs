#!/usr/bin/env node
import { fmtPct, runQuery } from './_recommendation_review_lib.mjs';

const mode = (process.argv[2] || 'remote').trim().toLowerCase();
const remote = mode !== 'local';

console.log(`MO Recommendation Scoreboard (${remote ? 'remote' : 'local'})`);

const batchRows = runQuery(`
SELECT trade_date, review_universe, available_trade_dates, max_review_horizon, review_generated_at
FROM mo_recommendation_review_batches
ORDER BY review_generated_at DESC, trade_date DESC
` , remote);

const itemRows = runQuery(`
SELECT trade_date, symbol, order_status, d0_return, d5_return, d10_return, d20_return
FROM mo_recommendation_review_items
ORDER BY reviewed_at DESC, trade_date DESC, symbol ASC
`, remote);

const totalBatches = batchRows.length;
const totalSymbols = itemRows.length;
const filledOrders = itemRows.filter((r) => String(r.order_status || '').toUpperCase() === 'EXECUTED').length;
const skippedOrders = itemRows.filter((r) => String(r.order_status || '').toUpperCase() === 'SKIPPED').length;
const pendingOrders = itemRows.filter((r) => String(r.order_status || '').toUpperCase() === 'PENDING').length;
const skipRatio = totalSymbols > 0 ? (skippedOrders / totalSymbols) * 100 : 0;
const filledRatio = totalSymbols > 0 ? (filledOrders / totalSymbols) * 100 : 0;

console.log('');
console.log(`total_batches=${totalBatches}`);
console.log(`total_symbols=${totalSymbols}`);
console.log(`filled_orders=${filledOrders}`);
console.log(`skipped_orders=${skippedOrders}`);
console.log(`pending_orders=${pendingOrders}`);
console.log('');
console.log(`skip_ratio=${skipRatio.toFixed(2)}%`);
console.log(`filled_ratio=${filledRatio.toFixed(2)}%`);

if (totalBatches > 0) {
  const latest = batchRows[0];
  console.log('');
  console.log(`latest_batch=${latest.trade_date}`);
  console.log(`latest_universe=${latest.review_universe}`);
  console.log(`latest_horizon=D${latest.max_review_horizon}`);
  console.log(`latest_available_trade_dates=${latest.available_trade_dates}`);
}

const checkpoints = [
  { label: 'D0', key: 'd0_return' },
  { label: 'D5', key: 'd5_return' },
  { label: 'D10', key: 'd10_return' },
  { label: 'D20', key: 'd20_return' },
];

console.log('');
console.log('checkpoint_outcomes:');
for (const checkpoint of checkpoints) {
  const values = itemRows
    .map((row) => Number(row?.[checkpoint.key]))
    .filter((value) => Number.isFinite(value));
  const evaluable = values.length;
  const coverage = totalSymbols > 0 ? (evaluable / totalSymbols) * 100 : 0;
  const positive = values.filter((value) => value > 0).length;
  const positiveRate = evaluable > 0 ? (positive / evaluable) * 100 : 0;
  const average = evaluable > 0 ? values.reduce((sum, value) => sum + value, 0) / evaluable : NaN;

  console.log(`${checkpoint.label}_evaluable=${evaluable}`);
  console.log(`${checkpoint.label}_coverage=${coverage.toFixed(2)}%`);
  console.log(`${checkpoint.label}_positive=${positive}`);
  console.log(`${checkpoint.label}_positive_rate=${positiveRate.toFixed(2)}%`);
  console.log(`${checkpoint.label}_average_return=${fmtPct(average)}`);
  console.log('');
}

console.log('Recommendation scoreboard OK');
