## 0.11.2
- `mo recommendation-review` 輸出強化：新增 `max_review_horizon`、`available_checkpoints`、`pending_checkpoints`，並明確區分 `not-enough-trade-days`、`missing-close`、`signal-generated-but-not-filled`。

# Changelog

## 0.11.1
- feat(review): 新增 `scripts/recommendation-review.mjs` 與 `mo recommendation-review`，回看最新推薦批次在 D0 / D5 / D10 / D20 的模擬表現。
- docs(scope): 明確校正 MO 為推薦驗證系統，不將模擬資料層誤解為實盤交易系統。
- docs(tooling): 同步更新 `MO_START.md`、`docs/PROJECT.md`、`docs/AI_MEMORY.md`、`docs/NEXT_TASK.md`、`docs/BUGS.md`、`docs/FUTURE_SYSTEMS.md`、`docs/commands.md`、`developer/SCRIPTS_GUIDE.md`。
