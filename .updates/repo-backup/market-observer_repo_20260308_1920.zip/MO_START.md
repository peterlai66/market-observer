## Runtime trading rules (0.10.0)
- Recommendation and execution must reject trades that are too small to survive costs.
- Minimum trade quantity / notional and transaction cost checks are part of the strategy, not optional UI hints.
- Any future change to recommendation sizing must preserve cost-aware guards and update docs/BUGS.md / CHANGELOG.md / RELEASE_NOTES.md together.

# MO_START

這是 Market Observer (MO) 專案的唯一入口文件。任何 AI 接手本專案時，必須先讀本文件，再讀 `docs/PROJECT.md`、`docs/AI_MEMORY.md`、`docs/NEXT_TASK.md`、`docs/BUGS.md`、`developer/SCRIPTS_GUIDE.md`。

## 1. 核心原則
- 使用者只負責提需求、定框架、做線上驗收；不手動改程式。
- AI 負責實作、同步文件、產出 release / patch / handoff。
- 一般交付一律提供可透過 `mo update` 套用的 release zip。
- 只有使用者明確輸入 `handoff` 時，才進入交接流程並產出 handoff 包。
- 所有已定案流程與規格都要同步寫入文件，不可只留在聊天室。
- 每次 release 必須同步更新相關文件，不可只改程式不改文件。
- 所有新發現 bug 必須寫入 `docs/BUGS.md`。

## 2. 基線與回歸防護
- Release 正式交付檔名必須固定為 `market-observer_release_latest.zip`；任何版本號式 release 檔名都視為交付失敗。
- 每次產出 release 後都必須先通過 `mo validate-artifacts`，再視為可交付。
- 所有後續開發都必須建立在最近一次成功通過 `mo update`、`mo smoke`、`mo deploy` 的版本上。
- `scripts/`、`package.json`、`MO_START.md`、`docs/commands.md`、`developer/SCRIPTS_GUIDE.md` 視為 toolchain 必檢區。
- 已存在的正式 CLI 指令不可無故消失，尤其是：`mo doctor`、`mo smoke`、`mo smoke-worker`、`mo guard`、`mo sanity`、`mo validate`、`mo preflight`、`mo preflight-worker`、`mo runtime-invariants`、`mo portfolio-verify`、`mo recommendation-review`、`mo autopilot`、`mo validate-artifacts`、`mo deploy`、`mo logs`、`mo update`。
- 交付判定以使用者 update 後實際拿到的內容為準，不以聊天室描述為準。

## 3. update / deploy 分流
- `update`：把 release / patch 套用到 local repo。
- `deploy`：把 Worker 發佈到 Cloudflare。
- 若 release 包含 `src/`、`wrangler.jsonc`、`migrations/`、`worker-configuration.d.ts`，update 後必須 deploy。

## 4. 測試流程
### 工具鏈 / 文件修改
- `npm run mo -- smoke`
- `npm run mo -- guard`
- `npm run mo -- sanity`
- `npm run mo -- update`
- `npm run mo -- autopilot`

### Worker 程式修改
- `npm run mo -- smoke`
- `npm run mo -- smoke-worker`
- `npm run mo -- guard`
- `npm run mo -- sanity`
- `npm run mo -- update`
- `npm run mo -- autopilot-worker`
- `npm run mo -- deploy`

## 5. outbox 結構契約
- 所有最新 zip 一律放在 `.updates/outbox/` 根目錄。
- 只靠檔名區分用途：`market-observer_dev_latest.zip`、`market-observer_patch_latest.zip`、`market-observer_release_latest.zip`、`mo_handoff_*.zip`。
- AI 交付 release 時，不可改用 `market-observer_release_<version>.zip` 之類名稱。
- `.updates/outbox/dev`、`.updates/outbox/patch`、`.updates/outbox/release`、`.updates/outbox/handoff` 都是廢棄結構，update / patch / sync-structure 必須自動刪除。
- `.updates/outbox/bak/` 保留作為舊 `_latest.zip` 的歸檔位置。


## 5A. 開發循環規則
- 每次 release 交付後，先做驗證與討論，再決定下一輪架構 / 功能。
- 每次 release 交付時，AI 必須先列出本輪實際改動檔案；至少包含目標腳本、VERSION、package.json、CHANGELOG.md、RELEASE_NOTES.md。
- 每次 release 驗證時，第一步固定為 `npm run mo -- doctor`；若版本號未更新到本輪版本，不得繼續做功能驗證。
- 未經版本驗證與目標腳本驗證，不得宣稱「已完成修正」或「已完成開發」。
- 若本輪目標是修某支腳本，交付後第一個功能驗證必須只驗那支腳本，不可一開始就要求使用者跑大範圍驗證鏈。
- 下一輪開始開發前，使用者必須先提供 `market-observer_dev_latest.zip`。
- AI 必須以使用者提供的 dev 包為基底實作，並把聊天室已定案內容同步寫入文件。
- AI 不可跳過 dev 包直接假設 repo 狀態；若沒有 dev 包，不得聲稱已完成可 update 的 release。
- release 交付檔名固定為 `market-observer_release_latest.zip`，不可要求使用者手動改名補救。

## 6. D0~D19 的正式定義
- D0~D19 代表 20 個交易日的模擬週期。
- D0 = 模擬第 1 個交易日，D1 = 模擬第 2 個交易日，依此類推。
- 不要把 D0 / D1 理解成市場慣例的當日 / 次日術語。

## 7. 主循環
1. 取得最新可用交易日市場資料。
2. 生成該交易日盤後報告。
3. 根據盤後報告產生買進 / 賣出建議。
4. 下一個交易日用最高 / 最低價模擬是否成交。
5. 更新模擬持倉與績效，持續滾動。

## 8. 非交易日規則
- 週末 / 國定假日不生成新的盤後報告。
- 查詢盤後報告時，顯示最近交易日的報告。
- 若最近交易日摘要尚未生成，系統應補寫該交易日摘要，而不是直接回空。

## 9. handoff 流程
1. 使用者 local 執行 `npm run mo -- pack`。
2. 使用者上傳 `market-observer_dev_latest.zip`。
3. 使用者輸入 `handoff`。
4. AI 必須先比對 repo、文件、規則、已知 bug、未完成功能。
5. AI 補齊可補項，並列出未完成事項。
6. AI 產出新的 handoff 包：`mo_handoff_YYYYMMDD_HHMM.zip`。
7. 新視窗輸入：`讀取檔案中的 MO_START.md 並繼續開發專案`。

## 10. Strategy Universe
- Universe 來源優先順序：`MO_UNIVERSE` → D1 `etf_universe(enabled=1)` → 預設 ETF universe `0050`、`006208`、`0056`、`00878`、`00919`。
- 推薦流程必須優先使用 universe，而且要從當日 `stocksAll` 全量快照建立候選；只有當日無快照時才可 fallback 到成交值排行。
- universe / fallback 狀態要同步寫入 log 與文件。


## Release delivery rule
- When a feature changes LINE behaviour or strategy logic, release notes must include LINE 驗證指令、預期結果、必要的 D1 / log 驗證方式。
- Newly discovered bugs must be recorded in `docs/BUGS.md`.


## 0.9.0 Strategy baseline
- The latest verified development baseline is 0.9.0.
- For functionality releases, always include LINE verification steps (`狀態`, `建議`, `debug`, `universe`) and any required PowerShell D1 commands.
- Strategy releases must update RELEASE_NOTES / CHANGELOG / BUGS / NEXT_TASK together.

- When a strategy change depends on price fields, release notes and debug output must state the exact fallback order for price resolution.

## 0.10.3 toolchain autopilot
- 新增 `mo autopilot`：固定串 `doctor -> smoke -> guard -> sanity`。
- 新增 `mo autopilot-worker`：固定串 `doctor -> smoke -> smoke-worker -> guard -> sanity`。
- 目的是把每輪 release / deploy 前的例行巡檢變成單一指令，減少 AI 漏跑檢查。

## 0.10.4 validate/preflight
- 新增 `mo validate`：固定串 `guard -> sanity -> validate-artifacts`，把 release 契約檢查收斂成單一指令。
- 新增 `mo preflight`：固定串 `doctor -> smoke -> validate`。
- 新增 `mo preflight-worker`：固定串 `doctor -> smoke -> smoke-worker -> validate`。
- `mo autopilot` / `mo autopilot-worker` 改為相容別名，內部轉呼叫 preflight 流程，避免巡檢定義分叉。


## 0.10.8 runtime-invariants parser fix
- `mo runtime-invariants` 必須能正確解析 `wrangler.jsonc`（含註解與 trailing comma）；若腳本需要讀設定檔，不可直接對 JSONC 使用 `JSON.parse`。
- `mo preflight-worker` / `mo autopilot-worker` 的驗收前提，是 `runtime-invariants` 能先單獨成功。

## 0.10.5 runtime invariants
- 新增 `mo runtime-invariants`：直接檢查 remote D1 的 `cash_twd`、`mo_positions`、`mo_execution_mark`、`mo_orders` 一致性。
- `mo preflight-worker` / `mo autopilot-worker` 現在必須把 runtime invariants 一起跑完，deploy 前不只驗工具鏈，也驗資料層。
- Runtime invariants 至少要攔下：負現金、非有限/非正持倉、portfolio snapshot 缺失或落後 execution mark、`EXECUTED` 缺 `exec_date`。


## 0.10.9 portfolio verify
- 新增 `mo portfolio-verify`：直接檢查 remote D1 的 `mo_portfolio_state`、`mo_positions`、`mo_orders(status=EXECUTED)` 與 `mo_execution_mark(filled=1)` 是否彼此一致。
- 若目前尚無 executed orders，腳本必須明確輸出 skip，而不是把空狀態誤判為錯誤。
- FS-01 Portfolio Closed Loop v2 的資料層驗收，優先使用 `mo runtime-invariants` + `mo portfolio-verify`。

## 0.11.0 recommendation review
- MO 不是實盤交易系統；portfolio / orders / execution marks 在此專案中屬於推薦驗證用的模擬資料層。
- 新增 `mo recommendation-review`：用最新推薦批次檢視 D0 / D5 / D10 / D20 表現，驗證推薦標的是否有效。
- 推薦驗證優先看 `mo recommendation-review` 與 `mo portfolio-verify`，而不是把 MO 解讀成真實交易執行系統。

## 0.11.1 delivery proof + recommendation review schema guard
- `mo recommendation-review` 不可假設 `mo_orders` 存在 `score` 等非必要欄位；查詢前必須先以 schema 探測決定可用欄位。
- 每次 release 交付都必須先附「本輪實際改動檔案」與「先驗版本、再驗功能」的驗證順序。

## 0.11.2 recommendation review clarity
- `mo recommendation-review` 的輸出必須先說明目前可回看交易日數與可用 checkpoint；資料不足時要明確區分 `not-enough-trade-days`、`missing-close`、`signal-generated-but-not-filled`。
