## 0.10.0 update
- MO 已進入成交閉環第一階段：strategy output 不只會產生 `mo_orders`，也會在 recommendation 與 execution 兩端做成本感知過濾。
- 新增交易守門概念：`minQty`、`minNotionalTwd`、`roundTripCost`、`edge_lt_cost`。
- 目前 TW ETF 採保守規則：先過成本與最小量門檻，再進入 PENDING / EXECUTED / SKIPPED 流程。

# PROJECT

## Current state
- CLI / update / smoke / deploy pipeline stable
- ETF universe comes from env -> D1 -> default fallback
- Multi-asset engine now generates candidates from universe snapshots
- 0.9.0 adds conservative starter fallback so the system can move from pure observation to actionable recommendations
- LINE commands for operational verification: 狀態 / 建議 / debug / universe

- 0.9.1: final recommendation close-price mapping now resolves TW ETF prices from raw close, OHLC fallback, and candidate fallback before rejecting for invalid close.

- 0.10.1 已修正同交易日重複建單問題；`mo_orders` 改為 idempotent insert，重跑 `/admin/run` 只會記錄 dedupe，不再污染訂單表。
- `mo_execution_mark` 現在會記錄 `SKIPPED / EXECUTED` 結果，方便驗證 pending 單後續是否真的被處理。


## 0.10.2 toolchain guardrail
- 新增 `mo guard` / `mo sanity`，用來在 release 前先攔下 AI 偏離流程、錯誤檔名、文件未同步、版本不同步等問題。
- `pack:release` 會自動串起 `sync-structure` → `doctor` → `guard` → `sanity` → `validate-artifacts`。
- 正式開發循環固定為：release 驗證 / 討論 → 使用者提供 `market-observer_dev_latest.zip` → AI 開發 → release。


## 0.10.3 autopilot preflight
- 新增 `mo autopilot` / `mo autopilot-worker`，把 release 前與 deploy 前的例行巡檢收斂成單一指令。
- 目標是讓 AI 與使用者在每輪驗證時不再漏跑 doctor / smoke / guard / sanity。


## 0.10.4 validate/preflight
- 新增 `mo validate`，把 `guard / sanity / validate-artifacts` 收斂成單一 release 契約檢查。
- 新增 `mo preflight` / `mo preflight-worker`，把 release 前與 deploy 前的固定巡檢進一步明文化。
- `mo autopilot` 現在作為相容入口，統一轉呼叫 preflight。


## 0.10.8 runtime-invariants hotfix
- 修正 `runtime-invariants` 讀取 `wrangler.jsonc` 時無法處理 JSONC 註解 / trailing comma 的問題。
- `preflight-worker` / `autopilot-worker` 現在可真正把 runtime invariants 跑完，而不是在設定解析階段就失敗。

## 0.10.5 runtime consistency
- 新增 `mo runtime-invariants`，deploy 前可直接查 remote D1 的 `mo_portfolio_state`、`mo_positions`、`mo_execution_mark`、`mo_orders` 是否一致。
- `mo preflight-worker` / `mo autopilot-worker` 現在不只驗工具鏈，還會驗資料層：負現金、非有限持倉、缺 snapshot / stale snapshot、`EXECUTED` 缺 `exec_date`。
