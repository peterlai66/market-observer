## 0.19.5 next
- Deploy 0.19.4 and verify `/admin/status` plus `/admin/simulation/preview` both return `version=0.19.4` and reflect the latest pending recommendation batch correctly.
- After preview output is confirmed, use `/admin/run?force=1` on the next live market day and compare real execution results against the 0.19.4 dry-run preview.
- If preview and live execution diverge, next focus is a dedicated execution audit endpoint that diff-checks `preview vs actual fill` by symbol.
