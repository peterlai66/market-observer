# NEXT TASK

- 驗證 Cloudflare logs 中 AI 呼叫是否固定顯示 `model=gpt-4o-mini`。
- 驗證 `mo_ai_audit` 是否正確記錄成功 / timeout / disabled 三種狀態。
- 下一輪聚焦：將 FMTQIK tradeDate 解析改為取最新日期而非首筆日期。

# NEXT TASK

- 驗證 LINE `report / 最新報告 / 本週報告` 是否已回傳最新 cycle/review 狀態，而非只顯示舊的 `twse_daily_summary`。
- 開始設計 0.17.x 的 operator narration / GPT explain layer，讓最新 operator report 能轉成 LINE 友善說明。
- 下一輪聚焦：把最新 operator report 主動投遞到 LINE，而不只提供查詢。

## 0.16.1
- recommendation-review-save now respects review-side fill fallback when SIM_FILL_POLICY=RANGE_OR_CLOSE, promoting eligible D0 range misses into executed review samples for scoreboard accumulation.

# NEXT TASK

- 驗證 `SIM_FILL_POLICY=RANGE_OR_CLOSE` 是否開始產生第一批 `EXECUTED` 樣本。
- 若第一批 executed sample 仍不足，再評估是否切到 `NEXT_OPEN` 或放寬 entry range。
- 在 scoreboard 補一層 executed sample accumulation / first-fill milestone。

- 追蹤 execution gate breakdown，確認主要阻塞是否為價格區間未觸發、資金不足或交易門檻。
- 依 execution:* 結果決定是否調整 simulated fill policy 或 entry range。

## 0.14.9 next target
- Continue extending TW future trade-date coverage so D5 / D10 / D20 unlock naturally after D0.
- Add execution-gate diagnostics for `signal-generated-but-not-filled` once coverage is no longer the primary blocker.
- Keep using the locked release baseline workflow for every new AI development round.

## 0.14.8 next target
- P1 TW price backfill repair: backfill missing `00757.TW` / `00919.TW` history into `prices_daily` and extend `00878.TW` beyond 2026-03-02.
- Add a dedicated CLI diagnostic to print `prices_daily` coverage gaps by symbol/date before weekly simulation runs.
- Keep review items canonical-only (`.TW`) and add one-shot cleanup for historical bare-symbol duplicates still remaining in remote D1.


## 0.14.4
- Daily cycle engine foundation is in place.
- `src/index.ts` now tracks `mo_cycle_state`, extends retry window to next-day open, and allows recommendation/simulation bootstrap before report push finishes.
- LINE now supports `ai 狀態` / `ai 報告` / `ai 建議` for GPT explanation.
- Verify with `npm run mo -- doctor`, `npm run typecheck`, deploy, then LINE `狀態`, `建議`, `ai 狀態`.

Next target: 0.14.5 cycle scoreboard + actionable / report_only tracking in CLI status and review outputs.

## 0.14.2
- Added weekly operator message layer for report payload shaping and publish-ready messaging.

## 0.13.9
- Operator final decision summary
- `mo recommendation-scoreboard` now prints `operator_final_decision_summary`, `operator_final_decision_findings`, and `operator_final_decision_actions`.
- Verify with `npm run mo -- doctor` then `npm run mo -- recommendation-scoreboard`.

Next target: 0.14.0 operator execution checklist
## 0.13.7
- Full Pipeline Readiness Summary
- `mo recommendation-scoreboard` now prints `pipeline_readiness_summary`, `pipeline_readiness_findings`, and `pipeline_readiness_actions`.
- Verify with `npm run mo -- doctor` then `npm run mo -- recommendation-scoreboard`.

Next target: 0.13.7 execution validation unlock checks


- 0.14.2: added weekly_delivery_formatting_summary / weekly_delivery_formatting_blocks / weekly_delivery_formatting_actions for LINE/email/log payload shaping.

## after 0.14.8
1. 驗證 `recommendation-review-save` 是否成功回填 00757.TW / 00919.TW / 00878.TW 的 2026-03 月 close rows。
2. 若 D0 已解鎖，持續累積未來交易日，觀察 D5 / D10 何時解鎖。
3. 若 TWSE monthly endpoint 對部分 ETF 無資料，補第二來源 backfill。
