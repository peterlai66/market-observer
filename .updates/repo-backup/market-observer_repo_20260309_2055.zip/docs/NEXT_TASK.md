## 0.14.5
- TW canonical symbol repair is now in place for universe/order/review flows.
- `src/index.ts` now persists daily TW closes into `prices_daily` and migrates legacy bare TW symbols in core MO tables to `XXXX.TW`.
- `scripts/_recommendation_review_lib.mjs` now normalizes TW symbols and falls back to `prices_daily` close lookup when raw snapshot matching is insufficient.
- Verify with `npm run mo -- doctor`, `npm run mo -- guard`, deploy, then `npm run mo -- recommendation-review-save` and `npm run mo -- recommendation-scoreboard`.

Next target: 0.14.6 cycle scoreboard + actionable / report_only tracking in CLI status and review outputs, plus explicit TW price backfill diagnostics.

## 0.14.2
- Added weekly operator message layer for report payload shaping and publish-ready messaging.

## 0.13.9
- Operator final decision summary
- `mo recommendation-scoreboard` now prints `operator_final_decision_summary`, `operator_final_decision_findings`, and `operator_final_decision_actions`.
- Verify with `npm run mo -- doctor` then `npm run mo -- recommendation-scoreboard`.

Next target: 0.14.0 operator execution checklist
## 0.13.7
- Full Pipeline Readiness Summary
- `mo recommendation-scoreboard` now prints `pipeline_readiness_summary`, `pipeline_readiness_findings`, and `pipeline_readiness_actions`.
- Verify with `npm run mo -- doctor` then `npm run mo -- recommendation-scoreboard`.

Next target: 0.13.7 execution validation unlock checks


- 0.14.2: added weekly_delivery_formatting_summary / weekly_delivery_formatting_blocks / weekly_delivery_formatting_actions for LINE/email/log payload shaping.
