## 0.19.7 next
- Deploy 0.19.6 and verify weekend sandbox flow end to end: preview -> commit -> audit -> reset.
- After commit, confirm `/admin/execution/audit` shows preview/actual MATCH and `/admin/status` shows sandbox snapshot active.
- After reset, confirm `latestExecuted` returns to `-`, positions return to baseline, and `latestSignal` falls back to pending-only state.
- If any mismatch remains, next step is to align cycle aggregation (`cycleReady`) with signal execution state.

## 0.19.6 next
- Deploy 0.19.5 and verify `/admin/version`, `/admin/status`, `/admin/simulation/preview`, `/admin/execution/audit` all return `version=0.19.5`.
- On the next live market day, run `/admin/run?force=1` once and compare `/admin/execution/audit` output against actual `EXECUTED / SKIPPED` results symbol by symbol.
- If execution audit shows mismatches, next step is a dedicated sandbox commit/reset flow so preview validation can be committed and cleared before formal live runs.
