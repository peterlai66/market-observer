## 0.10.1
- 補齊 handoff 必讀文件：新增 `docs/FUTURE_SYSTEMS.md`，把未來系統藍圖正式落地成文件，不再只留在聊天室。
- `MO_START.md` 現在要求接手 AI 必讀 `docs/FUTURE_SYSTEMS.md`；若 handoff 包缺這份文件，視為交接資訊不完整。
- 本版先修正交接遺漏風險，讓後續開發 portfolio closed loop v2 / PnL visibility / system guard 有固定依據。

## 0.10.0
- 新增成本感知交易守門：推薦與模擬成交都會考慮最低交易量、最低名目金額與交易成本，避免無意義的小額買賣。
- 台股 ETF BUY 建議現在至少需要達到合理股數與名目金額，若不符合會在 `debug` 看到 `qty_too_small`、`notional_too_small` 或 `edge_lt_cost`。
- `debug` / `mo_strategy_debug` 的 selected / rejected reason 會顯示 `notional` 與 `cost` 摘要，方便直接判斷是訊號問題還是成本問題。
- 模擬成交時，現金會扣除買進手續費與滑價；賣出時會扣除手續費、ETF 賣出交易稅與滑價，資金曲線更接近真實。
- 下一步重點：把成交後的持倉、成本、資金變化與最低利潤門檻再往下延伸到完整 portfolio 閉環。

## 0.9.1
- 修正 TW ETF 在 recommendation final gate 的價格欄位映射，優先取收盤價，若缺值則回退到 OHLC 或候選快照可用價格，避免 `missing_close / invalid_close` 把候選全部擋掉。
- `debug / 除錯` 現在會在候選與拒絕原因中顯示 `px=<來源>`，方便直接看出價格是來自 `raw.close`、`raw.ohl_avg`、`priceByCode.close` 等來源。
- 這版主修 `BUG-20260307-08`，目標是讓 `candidate -> recommendation` 能真正落地為新建議，而不是停在 `recs=0`。

## 0.9.0
- 進入策略版：若 `signal=TRY/AGGRESSIVE`、已有 candidates，但主篩選最後仍為 `0 recs`，系統會建立一筆保守的 `starter_fallback` 觀察倉建議，避免長期只看到「不動」而無法驗證策略鏈。
- universe 候選現在會優先使用全量快照，並在缺資料時自動回填 `close / chg / value`，降低因欄位缺漏造成的 `invalid_close` / `qty_zero`。
- `狀態` / `建議` / `debug` 會先自動確保 multi-asset runtime tables 存在，減少 migration 尚未 apply 時的功能中斷。
- 本版驗證重點：LINE `狀態`、`建議`、`debug`；若市場條件允許，預期不再固定停在 `candidate > 0, recs = 0`。

## 0.8.5
- 強化 CLI 自我防錯：新增 `mo validate-artifacts` / `mo validate`，可檢查 `.updates/outbox/` 是否仍有 deprecated 子目錄，以及 release 檔名是否固定為 `market-observer_release_latest.zip`。
- `mo smoke` 現在會在 release 打包後自動執行 artifact validation，避免再次出現交付檔名不符合 `mo update` 契約而導致更新失敗。
- `doctor` 現在會把 `.updates/outbox/dev`、`patch`、`release`、`handoff` 視為錯誤，讓結構回退能更早被發現。
- 建議功能版交付前驗證順序：`npm run mo -- release` → `npm run mo -- validate-artifacts` → `npm run mo -- smoke`。

## 0.8.4
- 新增策略除錯可視化：建立 `mo_strategy_debug`，記錄每次 recommendation run 的 candidate / selected / rejected。
- LINE 新增 `debug / 除錯` 指令，deploy 後可直接驗證 universe 來源、candidate 數、recs 數，以及前幾名候選與被擋原因。
- 本版主軸不是放寬策略，而是先把 `candidate_count > 0 但 rec_count = 0` 的原因透明化。
- 建議 deploy 後驗證：`狀態`、`建議`、`debug`，必要時查 D1 `mo_strategy_debug`。

## 0.8.3
- 修正 ETF universe 只在 `topByValue` 內過濾，導致明明 D1 有 `etf_universe`，策略仍可能 `done 0/0` 的問題。
- 每日推薦現在會優先讀取 D1 `etf_universe enabled=1`，並從當日 `stocksAll` 快照找可交易候選。
- 修正 `mo_recommendation_log` 舊 schema 與 runtime 寫入欄位不一致的問題，並讓 `狀態` 可回讀 legacy log。
- 建議 deploy 後用 LINE 傳：`universe`、`狀態`、`建議` 驗證；必要時再查 D1 `mo_orders` / `mo_recommendation_log`。

# Release Notes

## 0.8.2
- MO 多標的推薦正式加入預設 ETF universe，預設池為：0050、006208、0056、00878、00919。
- 可用 `MO_UNIVERSE` 覆寫標的池；若當日 ETF 池沒有快照，系統才會回退用成交值排行補位。
- 新增 recommendation log，狀態查詢會看到最新建議日期、signal、標的池來源與建議筆數。
- LINE 新增 `universe / 標的池` 指令，可直接查看目前使用中的 ETF 池。
- 本版延續 0.8.1 CLI foundation，主軸回到 MO 策略本體。
