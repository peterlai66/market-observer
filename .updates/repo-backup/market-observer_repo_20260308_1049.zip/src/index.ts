import { DEFAULT_UNIVERSE } from './config/universe';

export interface Env {
	DB: D1Database;
	LINE_CHANNEL_ACCESS_TOKEN: string;
	LINE_PUSH_USER_ID: string;
	/** 用於 /admin/run 手動觸發 */
	ADMIN_TOKEN?: string;

	// ===== Feature flags (string: "1" / "0") =====
	FEATURE_MULTI_ASSET?: string; // 多標的推薦 + 模擬成交
	FEATURE_SIM?: string; // 是否執行模擬成交（不開就只產出建議）
	MO_UNIVERSE?: string; // 以逗號分隔的推薦標的池覆寫
}

/** 台灣今天日期（僅當資料本身沒提供日期時，當 fallback 用） */
function twTodayString(): string {
	return new Intl.DateTimeFormat('en-CA', {
		timeZone: 'Asia/Taipei',
		year: 'numeric',
		month: '2-digit',
		day: '2-digit',
	}).format(new Date());
}

async function upsertDailyMark(env: Env, tradeDate: string, readyLevel: 'NONE' | 'PARTIAL' | 'FULL', note?: string) {
	try {
		await env.DB.prepare(
			`INSERT INTO mo_daily_mark (trade_date, ready_level, fetched_at, note, updated_at)
			 VALUES (?, ?, datetime('now'), ?, datetime('now'))
			 ON CONFLICT(trade_date) DO UPDATE SET
			   ready_level=excluded.ready_level,
			   fetched_at=excluded.fetched_at,
			   note=excluded.note,
			   updated_at=excluded.updated_at`,
		)
			.bind(tradeDate, readyLevel, note ?? null)
			.run();
	} catch (e) {
		// audit 不中斷主流程
		console.warn('upsertDailyMark failed', e);
	}
}

function twNowHM(): { hh: number; mm: number } {
	const parts = new Intl.DateTimeFormat('en-CA', {
		timeZone: 'Asia/Taipei',
		hour: '2-digit',
		minute: '2-digit',
		hour12: false,
	}).formatToParts(new Date());
	const hh = Number(parts.find((p) => p.type === 'hour')?.value ?? '0');
	const mm = Number(parts.find((p) => p.type === 'minute')?.value ?? '0');
	return { hh, mm };
}

function hmToMin(hh: number, mm: number): number {
	return hh * 60 + mm;
}

function inWindow(hh: number, mm: number, startHH: number, startMM: number, endHH: number, endMM: number): boolean {
	const t = hmToMin(hh, mm);
	const a = hmToMin(startHH, startMM);
	const b = hmToMin(endHH, endMM);
	return t >= a && t <= b;
}

function envFlag(env: Env, key: keyof Env, def: boolean): boolean {
	const v = (env as any)[key];
	if (v == null) return def;
	const s = String(v).trim().toLowerCase();
	return s === '1' || s === 'true' || s === 'yes' || s === 'on';
}


type UniverseSource = 'default' | 'env' | 'db';

function normalizeUniverseSymbol(symbol: string): string {
	const s = String(symbol || '').trim().toUpperCase();
	if (!s) return '';
	if (s.endsWith('.TW')) return s.slice(0, -3);
	if (s.endsWith('.US')) return s.slice(0, -3);
	return s;
}

function parseUniverseOverride(env: Env): string[] | null {
	const raw = String(env.MO_UNIVERSE ?? '').trim();
	if (!raw) return null;
	const symbols = raw
		.split(',')
		.map((x) => normalizeUniverseSymbol(x))
		.filter(Boolean);
	return symbols.length ? symbols : null;
}

async function getActiveUniverse(env: Env): Promise<{ symbols: string[]; source: UniverseSource }> {
	const override = parseUniverseOverride(env);
	if (override?.length) return { symbols: override, source: 'env' };
	try {
		const rs = await env.DB.prepare("SELECT symbol FROM etf_universe WHERE enabled=1 ORDER BY CASE tier WHEN 'core' THEN 1 WHEN 'attack' THEN 2 WHEN 'defense' THEN 3 ELSE 9 END, market, symbol").all<any>();
		const symbols = (rs?.results ?? [])
			.map((r: any) => normalizeUniverseSymbol(String(r?.symbol ?? '')))
			.filter(Boolean);
		if (symbols.length) return { symbols, source: 'db' };
	} catch (e) {
		console.warn('getActiveUniverse db failed', e);
	}
	return { symbols: [...DEFAULT_UNIVERSE].map((x) => normalizeUniverseSymbol(x)), source: 'default' };
}

function filterUniverseCandidates(topByValue: any[], symbols: string[]): any[] {
	if (!symbols.length) return [];
	const wanted = new Set(symbols.map((x) => normalizeUniverseSymbol(x)));
	const rows = topByValue.filter((x) => wanted.has(normalizeUniverseSymbol(String(x?.code ?? ''))));
	const rank = new Map(symbols.map((s, i) => [normalizeUniverseSymbol(s), i]));
	return rows.sort((a, b) => Number(rank.get(normalizeUniverseSymbol(String(a?.code ?? ''))) ?? 999) - Number(rank.get(normalizeUniverseSymbol(String(b?.code ?? ''))) ?? 999));
}

function pickFirstFinite(values: Array<unknown>): number {
	for (const v of values) {
		const n = Number(v);
		if (Number.isFinite(n)) return n;
	}
	return NaN;
}

function resolveCandidateClose(args: { raw?: any; px?: any; top?: any }): { close: number; source: string } {
	const { raw, px, top } = args;
	const rawClose = getNum(raw, ['收盤價', 'Close', 'close', '收盤', 'ClosingPrice', 'lastPrice', 'LastPrice']);
	if (Number.isFinite(rawClose) && rawClose > 0) return { close: rawClose, source: 'raw.close' };

	const pxClose = Number(px?.close ?? NaN);
	if (Number.isFinite(pxClose) && pxClose > 0) return { close: pxClose, source: 'priceByCode.close' };

	const topClose = Number(top?.close ?? NaN);
	if (Number.isFinite(topClose) && topClose > 0) return { close: topClose, source: 'topByValue.close' };

	const rawOpen = getNum(raw, ['開盤價', 'Open', 'open', '開盤']);
	const rawHigh = getNum(raw, ['最高價', 'High', 'high', '最高']);
	const rawLow = getNum(raw, ['最低價', 'Low', 'low', '最低']);
	const avgOhl = [rawOpen, rawHigh, rawLow].filter((x) => Number.isFinite(x) && Number(x) > 0);
	if (avgOhl.length) {
		const close = round2(avgOhl.reduce((a, b) => a + Number(b), 0) / avgOhl.length);
		return { close, source: avgOhl.length === 1 ? 'raw.ohl_single' : 'raw.ohl_avg' };
	}

	const pxFallback = pickFirstFinite([px?.open, px?.high, px?.low]);
	if (Number.isFinite(pxFallback) && pxFallback > 0) return { close: pxFallback, source: 'priceByCode.ohl' };

	const topFallback = pickFirstFinite([top?.open, top?.high, top?.low]);
	if (Number.isFinite(topFallback) && topFallback > 0) return { close: topFallback, source: 'topByValue.ohl' };

	return { close: NaN, source: 'missing' };
}

function buildUniverseSnapshotCandidates(stocksAll: any[], symbols: string[], priceByCode?: Map<string, any>, topByValue?: any[]): any[] {
	if (!Array.isArray(stocksAll) || !stocksAll.length || !symbols.length) return [];
	const wanted = new Set(symbols.map((x) => normalizeUniverseSymbol(x)));
	const rank = new Map(symbols.map((s, i) => [normalizeUniverseSymbol(s), i]));
	const topMap = new Map<string, any>((topByValue ?? []).map((r: any) => [normalizeUniverseSymbol(String(r?.code ?? '')), r]));
	const rows: any[] = [];
	for (const r of stocksAll) {
		const code = normalizeUniverseSymbol(getStr(r, ['證券代號', 'Code', 'code', 'StockCode']));
		if (!code || !wanted.has(code)) continue;
		const px = priceByCode?.get(code) ?? null;
		const top = topMap.get(code) ?? null;
		const { close, source: closeSource } = resolveCandidateClose({ raw: r, px, top });
		const chgRaw = getNum(r, ['漲跌價差', 'Change', 'chg', '漲跌', '漲跌價差(元)']);
		const valueRaw = getNum(r, ['成交金額', 'TradeValue', 'tradeValue', 'value', '成交金額(元)', 'TradeValue(元)']);
		const chg = Number.isFinite(chgRaw) ? chgRaw : Number(px?.chg ?? top?.chg ?? NaN);
		const value = Number.isFinite(valueRaw) ? valueRaw : Number(top?.value ?? 0);
		rows.push({
			code,
			name: getStr(r, ['證券名稱', 'Name', 'name', 'StockName']) || String(px?.name ?? top?.name ?? ''),
			close,
			chg,
			value,
			closeSource,
			hasClose: Number.isFinite(close) && close > 0,
			hasValue: Number.isFinite(value) && value > 0,
		});
	}
	return rows.sort((a, b) => Number(rank.get(normalizeUniverseSymbol(a.code)) ?? 999) - Number(rank.get(normalizeUniverseSymbol(b.code)) ?? 999));
}

function toNumber(s: unknown): number {
	if (s == null) return NaN;
	const str = String(s).trim();
	if (!str || str === '--') return NaN;
	return Number(str.replace(/,/g, ''));
}

function formatYi(n: number): string {
	if (!Number.isFinite(n)) return '—';
	const yi = n / 1e8;
	if (yi >= 100) return `${yi.toFixed(0)}億`;
	if (yi >= 10) return `${yi.toFixed(1)}億`;
	return `${yi.toFixed(2)}億`;
}

type SignalLevel = 'AGGRESSIVE' | 'TRY' | 'HOLD';

function round2(n: number): number {
	return Math.round(n * 100) / 100;
}

type MarketCode = 'TW' | 'US';
type TradeCostProfile = {
	market: MarketCode;
	minQty: number;
	minNotionalTwd: number;
	commissionRate: number;
	minCommissionTwd: number;
	sellTaxRate: number;
	slippageRate: number;
	minEdgeRate: number;
};

const TRADE_COST_TW_ETF: TradeCostProfile = {
	market: 'TW',
	minQty: 100,
	minNotionalTwd: 10000,
	commissionRate: 0.001425,
	minCommissionTwd: 20,
	sellTaxRate: 0.001,
	slippageRate: 0.0005,
	minEdgeRate: 0.01,
};

const TRADE_COST_US_ETF: TradeCostProfile = {
	market: 'US',
	minQty: 1,
	minNotionalTwd: 15000,
	commissionRate: 0.001,
	minCommissionTwd: 15,
	sellTaxRate: 0,
	slippageRate: 0.001,
	minEdgeRate: 0.012,
};

function detectMarketBySymbol(symbol: string): MarketCode {
	const s = String(symbol || '').trim().toUpperCase();
	if (/^\d{4,6}(\.TW)?$/.test(s)) return 'TW';
	return 'US';
}

function getTradeCostProfile(symbol: string): TradeCostProfile {
	return detectMarketBySymbol(symbol) === 'TW' ? TRADE_COST_TW_ETF : TRADE_COST_US_ETF;
}

function calcCommissionTwd(notionalTwd: number, profile: TradeCostProfile): number {
	if (!Number.isFinite(notionalTwd) || notionalTwd <= 0) return 0;
	return Math.max(profile.minCommissionTwd, round2(notionalTwd * profile.commissionRate));
}

function calcTradeCostEstimate(args: { symbol: string; side: MoOrderSide; price: number; qty: number }): {
	notionalTwd: number;
	commissionTwd: number;
	taxTwd: number;
	slippageTwd: number;
	totalTwd: number;
	profile: TradeCostProfile;
} {
	const profile = getTradeCostProfile(args.symbol);
	const notionalTwd = round2(Math.max(0, args.price) * Math.max(0, args.qty));
	const commissionTwd = calcCommissionTwd(notionalTwd, profile);
	const taxTwd = args.side === 'SELL' ? round2(notionalTwd * profile.sellTaxRate) : 0;
	const slippageTwd = round2(notionalTwd * profile.slippageRate);
	const totalTwd = round2(commissionTwd + taxTwd + slippageTwd);
	return { notionalTwd, commissionTwd, taxTwd, slippageTwd, totalTwd, profile };
}

function estimateRoundTripCostTwd(symbol: string, notionalTwd: number): number {
	const profile = getTradeCostProfile(symbol);
	const buyCommission = calcCommissionTwd(notionalTwd, profile);
	const sellCommission = calcCommissionTwd(notionalTwd, profile);
	const sellTax = round2(notionalTwd * profile.sellTaxRate);
	const slip = round2(notionalTwd * profile.slippageRate * 2);
	return round2(buyCommission + sellCommission + sellTax + slip);
}

function expectedEdgeRateForSignal(signal: SignalLevel, score: number): number {
	const base = signal === 'AGGRESSIVE' ? 0.018 : signal === 'TRY' ? 0.012 : 0.008;
	const bonus = Math.max(0, (Number(score || 0) - 60) / 1000);
	return round2(base + bonus);
}

function buildTradeGuardResult(args: { symbol: string; side: MoOrderSide; price: number; qty: number; signal?: SignalLevel; score?: number }): {
	ok: boolean;
	reason?: string;
	costText?: string;
	notionalTwd: number;
	totalCostTwd: number;
	profile: TradeCostProfile;
} {
	const cost = calcTradeCostEstimate({ symbol: args.symbol, side: args.side, price: args.price, qty: args.qty });
	const { profile, notionalTwd } = cost;
	if (!Number.isFinite(args.qty) || args.qty < profile.minQty) {
		return { ok: false, reason: `qty_too_small min=${profile.minQty}`, costText: `notional=${Math.round(notionalTwd)} cost=${Math.round(cost.totalTwd)}`, notionalTwd, totalCostTwd: cost.totalTwd, profile };
	}
	if (notionalTwd < profile.minNotionalTwd) {
		return { ok: false, reason: `notional_too_small min=${Math.round(profile.minNotionalTwd)}`, costText: `notional=${Math.round(notionalTwd)} cost=${Math.round(cost.totalTwd)}`, notionalTwd, totalCostTwd: cost.totalTwd, profile };
	}
	if (args.side === 'BUY') {
		const edgeRate = expectedEdgeRateForSignal(args.signal ?? 'TRY', Number(args.score ?? 0));
		const minEdge = Math.max(profile.minEdgeRate, edgeRate);
		const requiredProfit = round2(notionalTwd * minEdge);
		const roundTripCost = estimateRoundTripCostTwd(args.symbol, notionalTwd);
		if (requiredProfit <= roundTripCost) {
			return { ok: false, reason: `edge_lt_cost edge=${Math.round(requiredProfit)} cost=${Math.round(roundTripCost)}`, costText: `notional=${Math.round(notionalTwd)} rtCost=${Math.round(roundTripCost)}`, notionalTwd, totalCostTwd: roundTripCost, profile };
		}
	}
	return { ok: true, costText: `notional=${Math.round(notionalTwd)} cost=${Math.round(cost.totalTwd)}`, notionalTwd, totalCostTwd: cost.totalTwd, profile };
}

function decideSignalLevel(args: { dir: string; up: number; down: number; concentration: number; valid: number }): SignalLevel {
	const { dir, up, down, concentration, valid } = args;

	// 資料不足 → 保守不動
	if (valid < 200) return 'HOLD';

	const upStrong = up > down * 1.2;
	const downStrong = down > up * 1.2;
	const concHigh = Number.isFinite(concentration) && concentration >= 0.25;

	// 積極：大盤上漲 + 多數上漲 + 資金不過度集中
	if (dir === '上漲' && upStrong && !concHigh) return 'AGGRESSIVE';

	// 試單：盤面分歧（沒有明顯共識）
	if (!upStrong && !downStrong) return 'TRY';

	// 不動：大盤下跌 + 多數下跌 + 資金集中（偏保守）
	if (dir === '下跌' && downStrong && concHigh) return 'HOLD';

	return 'TRY';
}

function pickTargetFromTop5(top5: any[]): { code: string; name: string; close: number } | null {
	// 你要求：從成交前 5 挑，但不要太像追最熱 → 優先挑第 2~4 名
	const candidates = top5.slice(1, 4).filter((x) => Number.isFinite(x?.close));
	if (!candidates.length) return null;

	// 優先挑「今天收盤是上漲（chg > 0）」的，沒有就用第一個
	const upOnDay = candidates.filter((x) => Number.isFinite(x?.chg) && x.chg > 0);
	const pick = (upOnDay.length ? upOnDay : candidates)[0];

	return { code: pick.code, name: pick.name, close: pick.close };
}

async function linePush(env: Env, text: string): Promise<void> {
	const res = await fetch('https://api.line.me/v2/bot/message/push', {
		method: 'POST',
		headers: {
			Authorization: `Bearer ${env.LINE_CHANNEL_ACCESS_TOKEN}`,
			'Content-Type': 'application/json',
		},
		body: JSON.stringify({
			to: env.LINE_PUSH_USER_ID,
			messages: [{ type: 'text', text }],
		}),
	});

	if (!res.ok) {
		const body = await res.text();
		throw new Error(`LINE push failed: ${res.status} ${body}`);
	}
}

async function lineReply(env: Env, replyToken: string, text: string): Promise<void> {
	const res = await fetch('https://api.line.me/v2/bot/message/reply', {
		method: 'POST',
		headers: {
			Authorization: `Bearer ${env.LINE_CHANNEL_ACCESS_TOKEN}`,
			'Content-Type': 'application/json',
		},
		body: JSON.stringify({
			replyToken,
			messages: [{ type: 'text', text }],
		}),
	});

	if (!res.ok) {
		const body = await res.text();
		throw new Error(`LINE reply failed: ${res.status} ${body}`);
	}
}

function safeText(s: unknown): string {
	return String(s ?? '')
		.replace(/\r/g, '')
		.trim();
}

function normalizeTwseSummaryText(txt: string): string {
	let out = txt;

	// Fix direction text if sign and percent disagree (common when sign column missing)
	out = out.replace(/(大盤：[^｜]+｜)上漲\s+([0-9.,]+)點（-/, '$1下跌 $2點（-');
	out = out.replace(/(大盤：[^｜]+｜)下跌\s+([0-9.,]+)點（\+/, '$1上漲 $2點（+');

	// If breadth is explicitly marked incomplete, don't show tiny counts
	if (/還不完整（資料稍晚會補齊）/.test(out)) {
		out = out.replace(/📈 個股：上漲\s+\d+｜下跌\s+\d+｜持平\s+\d+/, '📈 個股：漲跌統計未齊（資料稍晚會補齊）');
	}

	return out;
}

async function buildStatusText(env: Env): Promise<string> {
	await ensureMultiAssetTables(env);
	const lastTick = await env.DB.prepare(
		'SELECT tick_id, triggered_at, lock_status, jobs_done, jobs_failed, duration_ms, summary, error FROM mo_tick_audit ORDER BY triggered_at DESC LIMIT 1',
	).first<any>();
	const lastDaily = await env.DB.prepare(
		'SELECT trade_date, ready_level, fetched_at, pushed_at, note, updated_at FROM mo_daily_mark ORDER BY updated_at DESC LIMIT 1',
	).first<any>();

	const lines: string[] = [];
	lines.push('📌 MO 狀態');
	if (lastTick) {
		lines.push(
			`Tick：${lastTick.tick_id}｜${String(lastTick.lock_status)}｜done ${lastTick.jobs_done}/${Number(lastTick.jobs_done) + Number(lastTick.jobs_failed)}｜${lastTick.duration_ms}ms`,
		);
	} else {
		lines.push('Tick：尚無紀錄');
	}
	if (lastDaily) {
		lines.push(`資料：${lastDaily.trade_date}｜${String(lastDaily.ready_level)}｜push=${lastDaily.pushed_at ? 'Y' : 'N'}`);
		if (lastDaily.note) lines.push(`note：${String(lastDaily.note).slice(0, 120)}`);
	} else {
		lines.push('資料：尚無 daily_mark');
	}
	try {
		const recLog = await getLatestRecommendationLog(env);
		if (recLog) {
			lines.push(`建議：${recLog.trade_date}｜${recLog.signal}｜${recLog.rec_count}/${recLog.candidate_count}｜${recLog.universe_source}`);
			lines.push(`池：${String(recLog.universe_symbols || '').slice(0, 120)}`);
			if (recLog.note) lines.push(`rec note：${String(recLog.note).slice(0, 120)}`);
		}
	} catch (e) {
		console.warn('buildStatusText recLog failed', e);
	}
	return lines.join('\n');
}

async function getLatestRecommendationLog(env: Env): Promise<any | null> {
	const tries = [
		"SELECT trade_date, signal, universe_source, universe_symbols, candidate_count, rec_count, note FROM mo_recommendation_log ORDER BY id DESC LIMIT 1",
		"SELECT signal_date AS trade_date, action AS signal, 'legacy' AS universe_source, '' AS universe_symbols, 0 AS candidate_count, COUNT(*) AS rec_count, 'legacy_schema' AS note FROM mo_recommendation_log WHERE is_latest=1 GROUP BY signal_date, action ORDER BY id DESC LIMIT 1",
		"SELECT signal_date AS trade_date, action AS signal, 'legacy' AS universe_source, '' AS universe_symbols, 0 AS candidate_count, COUNT(*) AS rec_count, 'recommendation_log' AS note FROM recommendation_log GROUP BY signal_date, action ORDER BY id DESC LIMIT 1",
	];
	for (const sql of tries) {
		try {
			const row = await env.DB.prepare(sql).first<any>();
			if (row) return row;
		} catch (e) {
			// ignore schema drift and try next shape
		}
	}
	return null;
}

async function buildYesterdayReport(env: Env): Promise<string> {
	const r = await env.DB.prepare('SELECT date, summary_text FROM twse_daily_summary ORDER BY date DESC LIMIT 1').first<any>();
	if (!r) return '目前尚無昨日報告（twse_daily_summary 空）。';
	const txt = normalizeTwseSummaryText(safeText(r.summary_text));
	return `📄 盤後摘要（${r.date}）\n\n${txt || '（空）'}`;
}

async function buildLatestRecs(env: Env): Promise<string> {
	await ensureMultiAssetTables(env);
	const d = await env.DB.prepare(
		"SELECT signal_date AS d FROM mo_orders WHERE status='PENDING' ORDER BY signal_date DESC LIMIT 1",
	).first<any>();
	if (!d?.d) return '目前沒有可用的明日建議（mo_orders PENDING 空）。';
	const rows = await env.DB.prepare(
		"SELECT side, symbol, name, entry_low, entry_high, qty, reason FROM mo_orders WHERE status='PENDING' AND signal_date=? ORDER BY rowid ASC",
	)
		.bind(d.d)
		.all<any>();
	const recs = rows?.results ?? [];
	if (!recs.length) return `目前沒有可用的明日建議（${d.d}）。`;
	const lines: string[] = [];
	lines.push(`🧠 明日建議（${d.d}）`);
	for (const [i, r] of recs.entries()) {
		lines.push(`${i + 1}. ${r.side} ${r.symbol} ${safeText(r.name)}`.trim());
		lines.push(`   價格：${r.entry_low} – ${r.entry_high}｜數量：${r.qty}`);
		if (r.reason) lines.push(`   原因：${safeText(r.reason)}`);
	}
	return lines.join('\n');
}

type TwseIndexRow = Record<string, unknown>;
type StockDayRow = Record<string, unknown>;

// Global fetch mode (set per request in /admin/run)
let FORCE_NO_STORE = false;

type FetchJsonOpts = {
	label?: string;
	noStore?: boolean;
};

async function fetchJson<T>(url: string, opts?: FetchJsonOpts): Promise<T> {
	const label = opts?.label ? ` ${opts.label}` : '';
	const noStore = opts?.noStore != null ? Boolean(opts.noStore) : FORCE_NO_STORE;

	// ✅ 除錯/force 時避免 CF cache 干擾，並把實際 URL 印出來
	console.log(`[TWSE] fetch${label} url=${url} cache=${noStore ? 'no-store' : 'cf'}`);

	// ✅ Timeout guard：避免 TWSE/OpenAPI 偶發卡住拖垮整個 Worker invocation
	const timeoutMs = 9000;
	const ac = new AbortController();
	const timer = setTimeout(() => ac.abort(`timeout ${timeoutMs}ms`), timeoutMs);

	try {
		const res = await fetch(url, {
			headers: { accept: 'application/json' },
			cache: noStore ? ('no-store' as any) : undefined,
			// NOTE: cache:'no-store' conflicts with cf.cacheTtl; omit cf in noStore mode.
			cf: noStore ? undefined : ({ cacheTtl: 60, cacheEverything: true } as any),
			signal: ac.signal,
		} as any);
		if (!res.ok) {
			const txt = await res.text().catch(() => '');
			throw new Error(`fetch failed ${res.status} ${res.statusText}${txt ? `: ${txt.slice(0, 200)}` : ''}`);
		}
		return (await res.json()) as T;
	} catch (e: any) {
		const isAbort = String(e?.name || '') === 'AbortError' || String(e?.message || '').includes('aborted');
		const msg = isAbort ? `fetch timeout after ${timeoutMs}ms: ${url}` : String(e?.message || e);
		throw new Error(msg);
	} finally {
		clearTimeout(timer);
	}
}

function getStr(r: any, keys: string[]): string {
	for (const k of keys) {
		const v = r?.[k];
		if (v != null) {
			const s = String(v).trim();
			if (s) return s;
		}
	}
	return '';
}

function getNum(r: any, keys: string[]): number {
	const s = getStr(r, keys);
	return toNumber(s);
}

/** 從 TWSE 回傳資料中抽「交易日」(YYYY-MM-DD) */
function pickTradeDateFromRow(r: any): string {
	// TWSE/OpenAPI 欄位名偶爾會改/多語系混用：盡量涵蓋常見變體
	const raw = getStr(r, ['日期', '交易日期', '交易日', '資料日期', '資料日', '年月日', 'TradeDate', 'ReportDate', 'Date', 'date']);
	return normalizeTradeDate(raw);
}

/** 兼容 TWSE 多種日期格式（含 2026/3/5 這種非補零格式） */
function normalizeTradeDate(raw: string): string {
	const s0 = String(raw ?? '').trim();
	if (!s0) return '';
	// 去掉空白與常見括號/文字（例如：2026/3/5(四)、2026年3月5日）
	let s = s0.replaceAll(' ', '').replace(/[（(].*[)）]$/g, '');
	// 先移除結尾的時分秒 / 時區（例如：2026/03/05 00:00:00、2026-03-05T00:00:00+08:00）
	s = s.replace(/(T|\s)\d{1,2}:\d{2}(:\d{2})?(\.\d+)?([Zz]|[\+\-]\d{2}:?\d{2})?$/g, '');
	// 中文年月日
	s = s.replace(/年/g, '/').replace(/月/g, '/').replace(/日/g, '');

	// A) 2026/03/05 或 2026/3/5
	let m = s.match(/^(\d{4})\/(\d{1,2})\/(\d{1,2})$/);
	if (m) {
		const mm = m[2].padStart(2, '0');
		const dd = m[3].padStart(2, '0');
		return `${m[1]}-${mm}-${dd}`;
	}

	// B) 2026-03-05 或 2026-3-5
	m = s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/);
	if (m) {
		const mm = m[2].padStart(2, '0');
		const dd = m[3].padStart(2, '0');
		return `${m[1]}-${mm}-${dd}`;
	}

	// C) 20260305
	if (/^\d{8}$/.test(s)) return `${s.slice(0, 4)}-${s.slice(4, 6)}-${s.slice(6, 8)}`;

	// C2) 民國 1150305
	if (/^\d{6,7}$/.test(s)) {
		// 2~3 位民國年 + 4 位月日
		const yPart = s.length === 6 ? s.slice(0, 2) : s.slice(0, 3);
		const md = s.slice(yPart.length);
		const y = String(Number(yPart) + 1911);
		return `${y}-${md.slice(0, 2)}-${md.slice(2, 4)}`;
	}

	// D) 民國 115/03/05 或 115/3/5
	m = s.match(/^(\d{2,3})\/(\d{1,2})\/(\d{1,2})$/);
	if (m) {
		const y = String(Number(m[1]) + 1911);
		const mm = m[2].padStart(2, '0');
		const dd = m[3].padStart(2, '0');
		return `${y}-${mm}-${dd}`;
	}

	// E) 2026.03.05 / 115.3.5
	m = s.match(/^(\d{2,4})\.(\d{1,2})\.(\d{1,2})$/);
	if (m) {
		const yRaw = Number(m[1]);
		const y = yRaw < 1911 ? String(yRaw + 1911) : String(yRaw);
		const mm = m[2].padStart(2, '0');
		const dd = m[3].padStart(2, '0');
		return `${y}-${mm}-${dd}`;
	}

	return '';
}

/**
 * TWSE openapi 有時會從「陣列」改成「包一層物件」(例如 { date, data } )。
 * 這裡做一次寬鬆解包，避免 schema 變動就整個 D0 崩。
 */
function twseUnwrapRows(payload: any): any[] {
	if (Array.isArray(payload)) return payload;
	if (!payload || typeof payload !== 'object') return [];
	const cand = (payload as any).data ?? (payload as any).aaData ?? (payload as any).rows ?? (payload as any).result;
	return Array.isArray(cand) ? cand : [];
}

function twsePickDateFromPayload(payload: any): string {
	if (!payload || typeof payload !== 'object') return '';
	const raw = getStr(payload, ['date', 'Date', 'tradeDate', 'TradeDate', 'ReportDate', 'reportDate', '交易日期', '日期', '資料日期']);
	return normalizeTradeDate(raw);
}

async function fetchTradeDateFromFmtqik(): Promise<string> {
	// FMTQIK 通常會帶有交易日期（較能判斷「今天資料是否已就緒」）
	const url = 'https://openapi.twse.com.tw/v1/exchangeReport/FMTQIK';
	const payload = await fetchJson<any>(url, { label: 'FMTQIK' });
	// 1) 先嘗試從 payload header 抽日期（若 openapi 改成包一層）
	const headerDate = twsePickDateFromPayload(payload);
	if (headerDate) return headerDate;
	const rows = twseUnwrapRows(payload);
	if (!Array.isArray(rows) || rows.length === 0) return '';
	// 嘗試從任一列抽日期（兼容不同欄位名）
	for (const r of rows) {
		const d = pickTradeDateFromRow(r);
		if (d) return d;
		// 有些可能是 key 直接叫 "Date" 以外的變體，做一次掃描
		for (const v of Object.values(r || {})) {
			const s = String(v ?? '').trim();
			if (!s) continue;
			const d2 = normalizeTradeDate(s);
			if (d2) return d2;
		}
	}
	// 若找不到日期，印出第一列 key 供除錯（避免再猜欄位名）
	try {
		const first = rows[0] || {};
		const keys = Object.keys(first);
		console.warn(`[TWSE] FMTQIK date not found. firstRowKeys=${keys.slice(0, 40).join(',')}`);
	} catch {}
	return '';
}

async function fetchTradeDateFromStocksAll(payload: any, rows: any[]): Promise<string> {
	// STOCK_DAY_ALL 通常每列都會帶日期（但欄位名可能不同）；也可能 payload 本身包一層 header date
	const headerDate = twsePickDateFromPayload(payload);
	if (headerDate) return headerDate;
	if (!Array.isArray(rows) || rows.length === 0) return '';
	// 取前幾列掃描即可（避免大陣列全掃）
	const n = Math.min(20, rows.length);
	for (let i = 0; i < n; i++) {
		const r = rows[i];
		const d = pickTradeDateFromRow(r);
		if (d) return d;
		for (const v of Object.values(r || {})) {
			const s = String(v ?? '').trim();
			if (!s) continue;
			const d2 = normalizeTradeDate(s);
			if (d2) return d2;
		}
	}
	return '';
}

function daysBetween(a: string, b: string): number {
	// a,b: YYYY-MM-DD
	const da = new Date(a + 'T00:00:00Z').getTime();
	const db = new Date(b + 'T00:00:00Z').getTime();
	return Math.round((db - da) / 86400000);
}

async function buildDailySummary(opts?: {
	noStore?: boolean;
}): Promise<{ tradeDate: string; raw: any; summary: string; stocksAll: any[]; isTodayReady: boolean }> {
	const noStore = opts?.noStore != null ? Boolean(opts.noStore) : FORCE_NO_STORE;
	// 1) 大盤
	const indexUrl = 'https://openapi.twse.com.tw/v1/exchangeReport/MI_INDEX';
	const idxPayload = await fetchJson<any>(indexUrl, { label: 'MI_INDEX', noStore });
	const idxRows = twseUnwrapRows(idxPayload) as TwseIndexRow[];

	// 盡量用「發行量加權股價指數」那列
	const taiex = (idxRows as any[]).find((r) => String(r?.['指數'] ?? '').includes('發行量加權股價指數'));

	// 1b) 全市場個股快照（用於成交排行 / 漲跌家數）
	// 注意：TWSE 有時會延遲或暫時回空；此時仍可用指數資料產生摘要，但 breadth/top 會降級。
	const stocksUrl = 'https://openapi.twse.com.tw/v1/exchangeReport/STOCK_DAY_ALL';
	let stocksAll: any[] = [];
	let stocksPayload: any = null;
	try {
		stocksPayload = await fetchJson<any>(stocksUrl, { label: 'STOCK_DAY_ALL', noStore });
		const rows = twseUnwrapRows(stocksPayload);
		stocksAll = Array.isArray(rows) ? rows : [];
	} catch (e: any) {
		// 盤後資料未 ready / 休市 / 端點短暫異常
		stocksAll = [];
		stocksPayload = null;
	}
	const stocks = stocksAll;
	const stocksCount = stocks.length;

	let idxStatus: 'OK' | 'STALE' | 'MISSING' = 'OK';

	let close = toNumber(taiex?.['收盤指數']);
	let chgPtsRaw = toNumber(taiex?.['漲跌點數']);
	let chgPct = toNumber(taiex?.['漲跌百分比']);
	// TWSE 常用欄位：漲跌(+/-)（有時也可能是「漲跌」）
	let sign = String((taiex as any)?.['漲跌(+/-)'] ?? (taiex as any)?.['漲跌'] ?? '').trim();
	// 把方向套到漲跌點數，避免出現「上漲 1494.77（-4.35%）」這種矛盾
	// 1) 優先採用「漲跌(+/-)」方向
	// 2) 若方向欄位缺失，則以百分比正負作為 fallback（TWSE 偶發不回方向）
	const chgPts = Number.isFinite(chgPtsRaw)
		? sign === '-'
			? -Math.abs(chgPtsRaw)
			: sign === '+'
				? Math.abs(chgPtsRaw)
				: Number.isFinite(chgPct)
					? chgPct < 0
						? -Math.abs(chgPtsRaw)
						: chgPct > 0
							? Math.abs(chgPtsRaw)
							: 0
					: chgPtsRaw
		: NaN;

	// ✅ 修正：用 close 與漲跌點數自行回推百分比（避免欄位偶發錯誤）
	const prevClose = Number.isFinite(close) && Number.isFinite(chgPts) ? close - chgPts : NaN;
	const chgPctCalc = Number.isFinite(prevClose) && prevClose !== 0 && Number.isFinite(chgPts) ? (chgPts / prevClose) * 100 : NaN;
	const useChgPct = Number.isFinite(chgPctCalc) ? chgPctCalc : chgPct;

	const chgPtsAbs = Number.isFinite(chgPts) ? Math.abs(chgPts) : NaN;

	const dir = Number.isFinite(chgPts)
		? chgPts < 0
			? '下跌'
			: chgPts > 0
				? '上漲'
				: '持平'
		: Number.isFinite(useChgPct)
			? useChgPct < 0
				? '下跌'
				: useChgPct > 0
					? '上漲'
					: '持平'
			: '持平';

	let tradeDateMissing = false;

	// ----- tradeDate resolver (D0) -----
	// 我們同時觀察多個來源：FMTQIK / MI_INDEX / STOCK_DAY_ALL
	// 原則：
	// 1) 優先選擇「最新且一致」的交易日（至少 2 個來源一致）
	// 2) 若只有 1 個來源有日期，允許採用（但必須在合理範圍內且不能是未來）
	// 3) 若來源之間不一致且無法形成一致結論 -> ABORT（B 模式）
	const today = twTodayString();

	const fmtDate = await fetchTradeDateFromFmtqik();
	if (fmtDate) console.log(`[TWSE] candidate tradeDate=${fmtDate} via FMTQIK`);

	const idxRowDate = pickTradeDateFromRow(taiex);
	if (idxRowDate) console.log(`[TWSE] candidate tradeDate=${idxRowDate} via MI_INDEX(taiex)`);

	const idxPayloadDate = twsePickDateFromPayload(idxPayload);
	if (idxPayloadDate) console.log(`[TWSE] candidate tradeDate=${idxPayloadDate} via MI_INDEX(payload)`);

	const stocksDate = await fetchTradeDateFromStocksAll(stocksPayload, stocksAll);
	if (stocksDate) console.log(`[TWSE] candidate tradeDate=${stocksDate} via STOCK_DAY_ALL`);

	const candidates = [
		{ src: 'FMTQIK', d: fmtDate },
		{ src: 'MI_INDEX_ROW', d: idxRowDate },
		{ src: 'MI_INDEX_PAYLOAD', d: idxPayloadDate },
		{ src: 'STOCK_DAY_ALL', d: stocksDate },
	].filter((x) => x.d);

	let tradeDate = '';
	if (candidates.length > 0) {
		// 取最新日期
		tradeDate = candidates
			.map((x) => x.d)
			.sort()
			.slice(-1)[0] as string;
		// 計算一致性（同日的來源數）
		const same = candidates.filter((x) => x.d === tradeDate);
		const quorum = same.length;

		// 防呆：不接受未來日期（以台灣 today 為上限）
		if (tradeDate > today) {
			console.warn(`[TWSE] tradeDate in future: tradeDate=${tradeDate} today=${today} -> NOT READY`);
			tradeDate = '';
		} else if (quorum >= 2) {
			console.log(`[TWSE] resolved tradeDate=${tradeDate} via quorum(${same.map((x) => x.src).join(',')})`);
		} else {
			// 只有 1 個來源提供最新日期：允許在「合理新鮮度」內採用（例如 API 部分端點延遲）
			// 但若同時存在明顯落後的日期，且無法判斷哪個是對的，就交給 B 模式 ABORT
			const uniqueDates = Array.from(new Set(candidates.map((x) => x.d))).sort();
			const oldest = uniqueDates[0] as string;
			const newest = uniqueDates[uniqueDates.length - 1] as string;
			const spread = daysBetween(oldest, newest);

			// 若 spread 很小（<=1 天），視為 TWSE 同步延遲，可採用最新
			if (spread <= 1) {
				console.warn(`[TWSE] tradeDate minor mismatch (spread=${spread}d): use newest=${tradeDate}`);
				// keep tradeDate
			} else {
				// 如果 STOCK_DAY_ALL 有日期且有資料量，代表「全市場快照」已就緒，優先採用其日期
				if (stocksDate && tradeDate === stocksDate && stocksCount > 0) {
					console.warn(`[TWSE] tradeDate mismatch (spread=${spread}d): prefer STOCK_DAY_ALL=${stocksDate} (FMTQIK may be stale)`);
					// keep tradeDate
				} else {
					console.warn(`[TWSE] tradeDate mismatch (spread=${spread}d) unresolved -> NOT READY. dates=${uniqueDates.join(',')}`);
					tradeDate = '';
				}
			}
		}
	}

	if (!tradeDate) {
		console.warn('[TWSE] trade date unresolved (FMTQIK/MI_INDEX/STOCK_DAY_ALL) -> NOT READY');
		throw new Error('trade date unresolved');
	}
	// Guard: 指數資料可能仍是上一個交易日（openapi MI_INDEX 會晚一步更新）
	const indexTradeDate = pickTradeDateFromRow(taiex);
	if (tradeDate && indexTradeDate && indexTradeDate !== tradeDate) {
		console.warn(`[TWSE] index date mismatch: tradeDate=${tradeDate} indexTradeDate=${indexTradeDate} -> omit index line`);
		idxStatus = 'STALE';

		close = NaN;
		chgPtsRaw = NaN;
		chgPct = NaN;
		sign = '';
	}
	if (!tradeDate && Array.isArray(idxRows)) {
		for (const r of idxRows as any[]) {
			const d = pickTradeDateFromRow(r);
			if (d) {
				tradeDate = d;
				break;
			}
			// 再掃一次 values（兼容欄位名被改）
			for (const v of Object.values(r || {})) {
				const s = String(v ?? '').trim();
				if (!s) continue;
				const d2 = normalizeTradeDate(s);
				if (d2) {
					tradeDate = d2;
					break;
				}
			}
			if (tradeDate) break;
		}
	}

	if (!tradeDate) {
		console.warn('[TWSE] trade date unresolved (FMTQIK/MI_INDEX) -> NOT READY');
		throw new Error('trade date unresolved');
		// 指數資料狀態：OK / STALE（日期不同步）/ MISSING（欄位未更新）
		if (idxStatus === 'OK' && !Number.isFinite(close)) idxStatus = 'MISSING';
	}

	// ⚠️ 若 tradeDate != today，代表「今天盤後資料尚未 ready」。
	// 但我們仍可用『最新交易日』資料產生明日建議 / 進行模擬成交。
	// 是否落地/推播盤後摘要，由 runDailyProcess 決定。
	const isTodayReady = tradeDate === today && !tradeDateMissing;

	const topByValue = (stocks as any[])
		.map((r) => ({
			code: getStr(r, ['證券代號', 'Code', 'code', 'StockCode']),
			name: getStr(r, ['證券名稱', 'Name', 'name', 'StockName']),
			value: getNum(r, ['成交金額', 'TradeValue', 'tradeValue', '成交值', '成交金額(元)', 'TradeValue(元)']),
			close: getNum(r, ['收盤價', 'Close', 'close', '收盤']),
			chg: getNum(r, ['漲跌價差', 'Change', 'chg', '漲跌', '漲跌價差(元)']),
			open: getNum(r, ['開盤價', 'Open', 'open', '開盤']),
			high: getNum(r, ['最高價', 'High', 'high', '最高']),
			low: getNum(r, ['最低價', 'Low', 'low', '最低']),
		}))
		.filter((x) => x.code && x.name && Number.isFinite(x.value))
		.sort((a, b) => b.value - a.value)
		.slice(0, 5);

	const topLines = topByValue.length
		? topByValue.map((x, i) => `${i + 1}. ${x.code} ${x.name}｜${formatYi(x.value)}`).join('\n')
		: '（成交排行暫時無法產生）';

	// ✅ 上漲 / 下跌 / 持平 家數（直接用 STOCK_DAY_ALL 的「漲跌價差」）
	// 兼容多種欄位名
	const getChg = (r: any): number => {
		const s = getStr(r, ['漲跌價差', 'Change', 'chg', '漲跌', '漲跌(+/-)']);
		if (!s) return NaN;

		// 有些回傳會是 "+1.2" / "-0.5" / "X0.00" / "0.00"
		// 把非數字符號清掉（保留負號、小數點）
		const cleaned = s.replace(/[^\d\.\-]/g, '');
		const v = toNumber(cleaned);
		return v;
	};

	let up = 0;
	let down = 0;
	let flat = 0;
	let valid = 0;

	for (const r of stocks as any[]) {
		const v = getChg(r);
		if (!Number.isFinite(v)) continue;
		valid++;
		if (v > 0) up++;
		else if (v < 0) down++;
		else flat++;
	}

	const breadthLine = valid < 200 ? '📈 個股：漲跌統計未齊（資料稍晚會補齊）' : `📈 個股：上漲 ${up}｜下跌 ${down}｜持平 ${flat}`;

	// 3) 白話一句：成交金額集中度（前 5 佔比）
	const totalValue = (stocks as any[]).reduce((acc, r) => {
		const v = getNum(r, ['成交金額', 'TradeValue', 'tradeValue', '成交值', '成交金額(元)', 'TradeValue(元)']);
		return acc + (Number.isFinite(v) ? v : 0);
	}, 0);

	const top5Value = topByValue.reduce((acc, x) => acc + (Number.isFinite(x.value) ? x.value : 0), 0);

	const concentration = totalValue > 0 ? top5Value / totalValue : NaN;

	let breadthHint: string;

	if (valid < 200) {
		breadthHint = '今天個股漲跌統計還不完整（資料稍晚會補齊）。';
	} else if (up > down * 1.2) {
		breadthHint = `今天多數股票上漲（${up} vs ${down}），比較像「大家一起動」。`;
	} else if (down > up * 1.2) {
		breadthHint = `今天多數股票下跌（${down} vs ${up}），市場偏保守。`;
	} else {
		breadthHint = `今天漲跌接近（${up} vs ${down}），盤面分歧、看法不一。`;
	}

	// 原本的集中/分散結論還保留，但把它跟 breadth 合併成更白話
	let moneyHint: string;
	if (!Number.isFinite(concentration)) {
		moneyHint = '資金集中度暫時無法判斷。';
	} else if (concentration >= 0.25) {
		moneyHint = '資金偏集中在少數熱門股。';
	} else {
		moneyHint = '資金分散在較多股票。';
	}

	const plain = `${breadthHint} ${moneyHint}`;

	// 指數資料不同步/未更新時：不要顯示點數/漲跌幅，避免「看起來像真的」
	const showIdx = idxStatus === 'OK';
	const dClose = showIdx && Number.isFinite(close) ? close.toFixed(2) : '—';
	const dDir = showIdx && Number.isFinite(close) ? dir : '—';
	const dPts = showIdx && Number.isFinite(chgPtsAbs) ? chgPtsAbs.toFixed(2) : '—';
	const dPct = showIdx && Number.isFinite(useChgPct) ? useChgPct.toFixed(2) : '—';

	const idxNote =
		idxStatus === 'OK'
			? ''
			: idxStatus === 'STALE'
				? indexTradeDate
					? `（指數資料不同步：MI_INDEX=${indexTradeDate}，已略過）`
					: '（指數資料不同步，已略過）'
				: '（指數資料尚未更新）';

	const summary =
		`📅 台股盤後總結（${tradeDate}）\n` +
		`大盤：${dClose}｜${dDir} ${dPts}點（${dPct}%）${idxNote}\n\n` +
		`💰 成交金額前 5（越前面＝今天越熱）\n` +
		`${topLines}\n\n` +
		`${breadthLine}\n\n` +
		`一句話：${plain}`;

	return {
		tradeDate,
		stocksAll,

		raw: {
			tradeDate,
			isTodayReady,
			idx: { close, chgPts, chgPct: useChgPct, dir, status: idxStatus, indexTradeDate },
			breadth: { up, down, flat, valid },
			stocksCount,
			topByValue,
			totalValue,
			concentration,
		},
		summary,
		isTodayReady,
	};
}

async function runStrategyEngine(
	env: Env,
	input: {
		tradeDate: string;
		dir: string;
		up: number;
		down: number;
		flat: number;
		valid: number;
		concentration: number;
		top5: any[];
	},
): Promise<{ actionText: string; note?: string }> {
	const { tradeDate, dir, up, down, valid, concentration, top5 } = input;

	const st = await env.DB.prepare('SELECT * FROM strategy_state WHERE id=1').first<any>();
	if (!st) throw new Error('strategy_state(id=1) missing');

	const principal = Number(st.pool_principal_twd ?? 300000);
	let cash = Number(st.cash_twd ?? principal);

	let symbol = (st.current_symbol as string | null) ?? null;
	let name = (st.current_name as string | null) ?? null;
	let shares = Number(st.position_shares ?? 0);
	let entryPrice = st.entry_price != null ? Number(st.entry_price) : null;

	let mode = (st.mode as string) || 'NORMAL'; // NORMAL / SLOW
	let conLoss = Number(st.consecutive_losses ?? 0);
	let conWin = Number((st as any).consecutive_wins ?? 0);

	let tradeCount = Number(st.trade_count ?? 0);
	let winCount = Number(st.win_count ?? 0);
	let lossCount = Number(st.loss_count ?? 0);
	const stopLossPct = Number(st.stop_loss_pct ?? -0.12);

	const signal = decideSignalLevel({ dir, up, down, concentration, valid });
	const buyPct = mode === 'SLOW' ? 0.1 : signal === 'AGGRESSIVE' ? 0.3 : signal === 'TRY' ? 0.1 : 0;

	// 取得持倉收盤價（用 top5 找；找不到就當資料不足）
	const heldClose = symbol ? Number(top5.find((x) => x.code === symbol)?.close ?? NaN) : NaN;

	// ===== 1) 停損：只有這個會「清倉」 =====
	if (symbol && shares > 0 && entryPrice && Number.isFinite(heldClose)) {
		const pnlPct = heldClose / entryPrice - 1;
		if (pnlPct <= stopLossPct) {
			const exitPrice = heldClose;
			const exitValue = shares * exitPrice;
			const pnl = exitValue - shares * entryPrice;
			cash += exitValue;

			await env.DB.prepare(
				`INSERT INTO trade_log
				 (symbol, name, entry_date, entry_price, entry_shares, exit_date, exit_price, exit_shares, pnl_twd, return_pct, exit_reason)
				 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
			)
				.bind(symbol, name ?? '', st.entry_date ?? tradeDate, entryPrice, shares, tradeDate, exitPrice, shares, pnl, pnlPct, 'STOPLOSS')
				.run();

			tradeCount += 1;
			if (pnl > 0) {
				winCount += 1;
				conLoss = 0;
			} else {
				lossCount += 1;
				conLoss += 1;
			}

			// 連續 3 次虧損 → 慢速
			if (conLoss >= 3) mode = 'SLOW';

			// 清掉持倉
			symbol = null;
			name = null;
			shares = 0;
			entryPrice = null;

			await env.DB.prepare(
				`UPDATE strategy_state SET
				  cash_twd=?,
				  current_symbol=NULL, current_name=NULL,
				  position_shares=0,
				  entry_price=NULL, entry_date=NULL, hold_days=0,
				  mode=?, consecutive_losses=?, consecutive_wins=?,
				  trade_count=?, win_count=?, loss_count=?,
				  last_action=?, last_reason=?, updated_at=datetime('now')
				 WHERE id=1`,
			)
				.bind(cash, mode, conLoss, tradeCount, winCount, lossCount, 'EXIT', '停損：避免策略池歸零')
				.run();

			return {
				actionText:
					`🧠 明日動作：清倉（100%）\n` + `原因：浮虧觸發停損線（${Math.round(stopLossPct * 100)}%）\n` + `執行價：當日收盤（模擬）`,
				note: 'STOPLOSS_EXIT',
			};
		}
	}

	// ===== 2) 沒有持倉：AGGRESSIVE / TRY 才會買 =====
	if ((!symbol || shares <= 0) && buyPct > 0) {
		const target = pickTargetFromTop5(top5);
		if (!target) {
			await env.DB.prepare(`UPDATE strategy_state SET last_action=?, last_reason=?, updated_at=datetime('now') WHERE id=1`)
				.bind('SKIP', '資料不足：成交前5缺收盤價')
				.run();
			return { actionText: '🧠 明日動作：不動\n原因：資料不足（成交前5缺收盤價）', note: 'NO_TARGET' };
		}

		const invest = cash * buyPct;
		const px = target.close;
		const addShares = invest / px;

		cash -= invest;
		symbol = target.code;
		name = target.name;
		shares = round2(addShares);
		entryPrice = px;

		await env.DB.prepare(
			`UPDATE strategy_state SET
			  cash_twd=?,
			  current_symbol=?, current_name=?,
			  position_shares=?,
			  entry_price=?, entry_date=?, hold_days=0,
			  mode=?, consecutive_losses=?, consecutive_wins=?,
			  last_action=?, last_reason=?, updated_at=datetime('now')
			 WHERE id=1`,
		)
			.bind(
				cash,
				symbol,
				name,
				shares,
				entryPrice,
				tradeDate,
				mode,
				conLoss,
				'BUY',
				buyPct === 0.3 ? '積極布局：用現金 30% 進場' : '小幅試單：用現金 10% 進場',
			)
			.run();

		return {
			actionText:
				`🧠 明日動作：買入\n` +
				`標的：${symbol} ${name}\n` +
				`投入金額：現金 ${(buyPct * 100).toFixed(0)}% = ${Math.round(invest).toLocaleString()} 元\n` +
				`預估股數：約 ${shares} 股（零股）\n` +
				`執行價：當日收盤（模擬）`,
			note: buyPct === 0.3 ? 'BUY_30' : 'BUY_10',
		};
	}

	// ===== 3) 有持倉：只有 AGGRESSIVE 才加碼；TRY/HOLD 維持 =====
	if (symbol && shares > 0) {
		if (signal === 'AGGRESSIVE' && buyPct > 0) {
			const px = Number(top5.find((x) => x.code === symbol)?.close ?? NaN);
			if (!Number.isFinite(px)) {
				await env.DB.prepare(`UPDATE strategy_state SET last_action=?, last_reason=?, updated_at=datetime('now') WHERE id=1`)
					.bind('HOLD', '持倉股收盤價缺失，暫不加碼')
					.run();
				return { actionText: '🧠 明日動作：維持持倉\n原因：持倉股資料不足，先不加碼', note: 'HOLD_NO_PRICE' };
			}

			const invest = cash * buyPct;
			const addShares = invest / px;
			const oldCost = (entryPrice ?? px) * shares;
			const newCost = oldCost + invest;
			const newShares = round2(shares + addShares);
			const newEntry = newCost / newShares;

			cash -= invest;
			shares = newShares;
			entryPrice = newEntry;

			await env.DB.prepare(
				`UPDATE strategy_state SET
				  cash_twd=?,
				  position_shares=?,
				  entry_price=?,
				  mode=?, consecutive_losses=?, consecutive_wins=?,
				  last_action=?, last_reason=?, updated_at=datetime('now')
				 WHERE id=1`,
			)
				.bind(cash, shares, entryPrice, mode, conLoss, 'ADD', mode === 'SLOW' ? '慢速模式：加碼改用現金 10%' : '積極布局：加碼現金 30%')
				.run();

			return {
				actionText:
					`🧠 明日動作：加碼\n` +
					`標的：${symbol} ${name}\n` +
					`投入金額：現金 ${(buyPct * 100).toFixed(0)}% = ${Math.round(invest).toLocaleString()} 元\n` +
					`新增股數：約 ${round2(addShares)} 股（零股）\n` +
					`持倉總股數：約 ${shares} 股\n` +
					`執行價：當日收盤（模擬）`,
				note: buyPct === 0.3 ? 'ADD_30' : 'ADD_10',
			};
		}

		await env.DB.prepare(`UPDATE strategy_state SET last_action=?, last_reason=?, updated_at=datetime('now') WHERE id=1`)
			.bind('HOLD', signal === 'HOLD' ? '不動：不要動' : '試單：已有持倉先維持')
			.run();

		return {
			actionText: `🧠 明日動作：維持持倉\n原因：${signal === 'HOLD' ? '不動（不要動）' : '試單（先觀察，不加碼）'}`,
			note: signal === 'HOLD' ? 'HOLD' : 'TRY_HOLD',
		};
	}

	// 無持倉且 HOLD：不動
	await env.DB.prepare(`UPDATE strategy_state SET last_action=?, last_reason=?, updated_at=datetime('now') WHERE id=1`)
		.bind('HOLD', '不動：不進場')
		.run();

	return { actionText: '🧠 明日動作：不動\n原因：盤勢偏保守，先不進場', note: 'HOLD_NO_POS' };
}

async function writeDailyMark(
	env: Env,
	input: { tradeDate: string; note?: string; top5: any[] },
): Promise<{ equity: number; retPct: number; cash: number; posValue: number; symbol: string | null; shares: number }> {
	const st = await env.DB.prepare('SELECT * FROM strategy_state WHERE id=1').first<any>();
	if (!st) throw new Error('strategy_state(id=1) missing');

	const principal = Number(st.pool_principal_twd ?? 300000);
	const cash = Number(st.cash_twd ?? principal);

	const symbol = (st.current_symbol as string | null) ?? null;
	const shares = Number(st.position_shares ?? 0);

	const close = symbol ? Number(input.top5.find((x) => x.code === symbol)?.close ?? NaN) : NaN;
	const posValue = symbol && shares > 0 && Number.isFinite(close) ? shares * close : 0;
	const equity = cash + posValue;
	const retPct = equity / principal - 1;

	await env.DB.prepare(
		`INSERT OR REPLACE INTO daily_mark
		 (trade_date, symbol, close_price, cash_twd, position_shares, position_value_twd, total_equity_twd, return_pct, note)
		 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
	)
		.bind(input.tradeDate, symbol, Number.isFinite(close) ? close : null, cash, shares, posValue, equity, retPct, input.note ?? null)
		.run();

	return { equity, retPct, cash, posValue, symbol, shares };
}

// ===== Multi-asset strategy (v1.1) =====
type MoOrderSide = 'BUY' | 'SELL';
type MoOrderStatus = 'PENDING' | 'EXECUTED' | 'SKIPPED';

type MoRecommendation = {
	symbol: string;
	name: string;
	side: MoOrderSide;
	entryLow: number;
	entryHigh: number;
	qty: number; // shares (odd-lot)
	weight: number; // 0~1
	score: number;
	reason: string;
};


type StrategyDebugRow = {
	symbol: string;
	name: string;
	stage: string;
	reason: string;
	score?: number | null;
	chgPct?: number | null;
	valueScore?: number | null;
	momScore?: number | null;
};

async function ensureMultiAssetTables(env: Env): Promise<void> {
	const addColumnIfMissing = async (sql: string) => {
		try {
			await env.DB.prepare(sql).run();
		} catch (e: any) {
			const msg = String(e?.message || e).toLowerCase();
			if (!msg.includes('duplicate column')) throw e;
		}
	};

	// 這裡用 IF NOT EXISTS，避免你忘了跑 migration 也能先跑起來
	await env.DB.prepare(
		`CREATE TABLE IF NOT EXISTS mo_portfolio_state (
			id INTEGER PRIMARY KEY CHECK (id=1),
			principal_twd INTEGER NOT NULL DEFAULT 300000,
			cash_twd REAL NOT NULL DEFAULT 300000,
			updated_at TEXT NOT NULL DEFAULT (datetime('now'))
		);`,
	).run();
	await env.DB.prepare(`INSERT OR IGNORE INTO mo_portfolio_state (id) VALUES (1);`).run();

	await env.DB.prepare(
		`CREATE TABLE IF NOT EXISTS mo_positions (
			symbol TEXT PRIMARY KEY,
			name TEXT,
			shares REAL NOT NULL DEFAULT 0,
			avg_cost REAL NOT NULL DEFAULT 0,
			opened_date TEXT,
			updated_at TEXT NOT NULL DEFAULT (datetime('now'))
		);`,
	).run();

	await env.DB.prepare(
		`CREATE TABLE IF NOT EXISTS mo_orders (
			id INTEGER PRIMARY KEY AUTOINCREMENT,
			signal_date TEXT NOT NULL,     -- 產生建議的日期（D1）
			exec_date TEXT,               -- 實際用哪一天的 OHLC 判定（D2 或下一個交易日）
			side TEXT NOT NULL,           -- BUY / SELL
			symbol TEXT NOT NULL,
			name TEXT,
			entry_low REAL NOT NULL,
			entry_high REAL NOT NULL,
			qty REAL NOT NULL,
			status TEXT NOT NULL DEFAULT 'PENDING',
			exec_price REAL,
			reason TEXT,
			created_at TEXT NOT NULL DEFAULT (datetime('now'))
		);`,
	).run();

	await env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_mo_orders_status ON mo_orders(status, signal_date);`).run();
	await env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_mo_orders_symbol ON mo_orders(symbol);`).run();

	await env.DB.prepare(
		`CREATE TABLE IF NOT EXISTS mo_recommendation_log (
			id INTEGER PRIMARY KEY AUTOINCREMENT,
			trade_date TEXT NOT NULL,
			signal TEXT NOT NULL,
			universe_source TEXT NOT NULL,
			universe_symbols TEXT NOT NULL,
			candidate_count INTEGER NOT NULL DEFAULT 0,
			rec_count INTEGER NOT NULL DEFAULT 0,
			snapshot_count INTEGER NOT NULL DEFAULT 0,
			note TEXT,
			created_at TEXT NOT NULL DEFAULT (datetime('now'))
		);`,
	).run();
	await env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_mo_recommendation_log_date ON mo_recommendation_log(trade_date DESC);`).run();
	await addColumnIfMissing(`ALTER TABLE mo_recommendation_log ADD COLUMN trade_date TEXT;`);
	await addColumnIfMissing(`ALTER TABLE mo_recommendation_log ADD COLUMN signal TEXT;`);
	await addColumnIfMissing(`ALTER TABLE mo_recommendation_log ADD COLUMN universe_source TEXT;`);
	await addColumnIfMissing(`ALTER TABLE mo_recommendation_log ADD COLUMN universe_symbols TEXT;`);
	await addColumnIfMissing(`ALTER TABLE mo_recommendation_log ADD COLUMN candidate_count INTEGER NOT NULL DEFAULT 0;`);
	await addColumnIfMissing(`ALTER TABLE mo_recommendation_log ADD COLUMN rec_count INTEGER NOT NULL DEFAULT 0;`);
	await addColumnIfMissing(`ALTER TABLE mo_recommendation_log ADD COLUMN snapshot_count INTEGER NOT NULL DEFAULT 0;`);
	await addColumnIfMissing(`ALTER TABLE mo_recommendation_log ADD COLUMN note TEXT;`);

	await env.DB.prepare(
		`CREATE TABLE IF NOT EXISTS mo_strategy_debug (
			id INTEGER PRIMARY KEY AUTOINCREMENT,
			trade_date TEXT NOT NULL,
			symbol TEXT NOT NULL,
			name TEXT,
			stage TEXT NOT NULL,
			reason TEXT NOT NULL,
			score REAL,
			chg_pct REAL,
			value_score REAL,
			mom_score REAL,
			created_at TEXT NOT NULL DEFAULT (datetime('now'))
		);`,
	).run();
	await env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_mo_strategy_debug_trade_date ON mo_strategy_debug(trade_date DESC, id DESC);`).run();
}

function calcEntryRangeFromClose(close: number): { low: number; high: number } {
	// 避免追高：用「略低於收盤」到「略高於收盤」的區間（可後續調參）
	const low = round2(close * 0.995);
	const high = round2(close * 1.01);
	return { low, high };
}

function calcExitRangeFromClose(close: number): { low: number; high: number } {
	// 先用簡單停利區（未來可改成依波動度）
	const low = round2(close * 0.99);
	const high = round2(close * 1.01);
	return { low, high };
}

function pickTopCandidates(topByValue: any[], maxN: number): any[] {
	// 你原本避免追第一名：優先 2~4，再補 1/5
	const pool = [...topByValue];
	const pref = pool.slice(1, 4);
	const rest = pool.filter((x) => !pref.includes(x));
	return [...pref, ...rest].slice(0, maxN);
}

function clamp(n: number, lo: number, hi: number): number {
	return Math.max(lo, Math.min(hi, n));
}

function alphaScoreCandidate(x: any): { score: number; detail: { chgPct: number; valueScore: number; momScore: number } } {
	// Alpha score（0~100）= 動能(0~70) + 流動性(0~30)
	const close = Number.isFinite(x?.close) ? Number(x.close) : NaN;
	const chg = Number.isFinite(x?.chg) ? Number(x.chg) : NaN;
	const prev = Number.isFinite(close) && Number.isFinite(chg) ? close - chg : NaN;
	const chgPct = Number.isFinite(prev) && prev !== 0 ? (chg / prev) * 100 : NaN;

	// 動能：-5%~+5% 映射到 0~70（超出就封頂）
	const mom = Number.isFinite(chgPct) ? clamp(chgPct, -5, 5) : 0;
	const momScore = round2(((mom + 5) / 10) * 70);

	// 流動性：成交金額 log scale 0~30
	const value = Number.isFinite(x?.value) ? Number(x.value) : 0;
	const valueScore = round2(clamp(Math.log10(Math.max(1, value)) * 5, 0, 30));

	const score = round2(clamp(momScore + valueScore, 0, 100));
	return { score, detail: { chgPct: Number.isFinite(chgPct) ? round2(chgPct) : NaN, valueScore, momScore } };
}

function normalizeWeightsCapped(items: { score: number }[], cap: number): number[] {
	// 先按 score 轉權重，再做單一標的上限 cap，最後重新正規化
	const rawSum = items.reduce((a, x) => a + Math.max(0, x.score), 0);
	let w = rawSum > 0 ? items.map((x) => Math.max(0, x.score) / rawSum) : items.map(() => 1 / items.length);
	w = w.map((x) => Math.min(cap, x));
	const sum2 = w.reduce((a, x) => a + x, 0);
	return sum2 > 0 ? w.map((x) => x / sum2) : items.map(() => 1 / items.length);
}

function allocateBudgets(args: { signal: SignalLevel; cash: number; picks: { code: string; close: number; score: number }[] }): {
	budgets: number[];
	totalBudget: number;
} {
	const { signal, cash, picks } = args;

	// 交易資金池：TRY 少量、AGGRESSIVE 多一點，但保留大部分現金
	const budgetPct = signal === 'AGGRESSIVE' ? 0.35 : 0.2;
	const totalBudget = cash * budgetPct;

	// 單一標的最大 50%，避免 all-in
	const weights = normalizeWeightsCapped(picks, 0.5);

	// 最小下單金額（避免太小被手續費吃掉）
	const minOrderTwd = TRADE_COST_TW_ETF.minNotionalTwd;

	const budgets = weights.map((w) => totalBudget * w);

	// 若某檔預算太小，就把它砍掉，預算再分配給剩下的
	let keep = budgets.map((b) => b >= minOrderTwd);
	if (keep.some((x) => !x) && keep.some((x) => x)) {
		const kept = picks.filter((_, i) => keep[i]);
		const keptWeights = normalizeWeightsCapped(kept, 0.5);
		const keptBudgets = keptWeights.map((w) => totalBudget * w);
		const out = picks.map((_, i) => {
			const k = kept.findIndex((p) => p.code === picks[i].code);
			return k >= 0 ? keptBudgets[k] : 0;
		});
		return { budgets: out, totalBudget };
	}

	return { budgets, totalBudget };
}


function buildStarterRecommendation(args: { signal: SignalLevel; cash: number; ranked: any[] }): MoRecommendation | null {
	const { signal, cash, ranked } = args;
	if (!ranked.length || cash <= 0) return null;
	const first = ranked.find((x) => Number.isFinite(Number(x?.close)) && Number(x.close) > 0);
	if (!first) return null;
	const close = Number(first.close);
	const rg = calcEntryRangeFromClose(close);
	const basePct = signal === 'AGGRESSIVE' ? 0.12 : 0.08;
	const budget = Math.max(10000, Math.min(cash * basePct, cash * 0.2));
	const profile = getTradeCostProfile(String(first.code ?? ''));
	const qty = Math.floor(Math.max(budget, profile.minNotionalTwd) / rg.high / profile.minQty) * profile.minQty;
	if (qty <= 0) return null;
	const guard = buildTradeGuardResult({ symbol: String(first.code ?? ''), side: 'BUY', price: rg.high, qty, signal, score: Number(first.score ?? 0) });
	if (!guard.ok) return null;
	return {
		symbol: first.code,
		name: first.name || '',
		side: 'BUY',
		entryLow: rg.low,
		entryHigh: rg.high,
		qty,
		weight: round2((qty * rg.high) / Math.max(1, cash)),
		score: Number(first.score ?? 0),
		reason: `試單 fallback｜${signal === 'AGGRESSIVE' ? '偏多進攻' : '有候選先建立觀察倉'}｜Alpha ${Number(first.score ?? 0).toFixed(1)}｜${guard.costText}`,
	};
}

function pickExecPriceForBuy(args: { open: number; low: number; high: number; entryLow: number; entryHigh: number }): number | null {
	const { open, low, high, entryLow, entryHigh } = args;
	// 進入區間才成交：區間與當日交易區間有交集
	const touched = low <= entryHigh && high >= entryLow;
	if (!touched) return null;
	// 保守：能在區間內就用 open，否則用 entryHigh（追價上限）
	if (Number.isFinite(open) && open >= entryLow && open <= entryHigh) return open;
	// 若開盤在區間上方，但低點有碰到 → 用 entryHigh
	if (Number.isFinite(low) && low <= entryHigh) return entryHigh;
	return entryHigh;
}

function pickExecPriceForSell(args: { open: number; low: number; high: number; entryLow: number; entryHigh: number }): number | null {
	const { open, low, high, entryLow, entryHigh } = args;
	const touched = low <= entryHigh && high >= entryLow;
	if (!touched) return null;
	// 保守：能在區間內就用 open，否則用 entryLow（賣出下限）
	if (Number.isFinite(open) && open >= entryLow && open <= entryHigh) return open;
	if (Number.isFinite(high) && high >= entryLow) return entryLow;
	return entryLow;
}

async function executePendingOrders(env: Env, tradeDate: string, priceByCode: Map<string, any>): Promise<string[]> {
	const pending = await env.DB.prepare("SELECT * FROM mo_orders WHERE status='PENDING' ORDER BY id ASC").all<any>();

	const events: string[] = [];
	if (!pending?.results?.length) return events;

	const pf = await env.DB.prepare('SELECT * FROM mo_portfolio_state WHERE id=1').first<any>();
	let cash = Number(pf?.cash_twd ?? 300000);

	for (const o of pending.results) {
		const sym = String(o.symbol);
		const row = priceByCode.get(sym);
		if (!row) continue;

		const open = Number(row.open);
		const high = Number(row.high);
		const low = Number(row.low);
		const close = Number(row.close);

		const entryLow = Number(o.entry_low);
		const entryHigh = Number(o.entry_high);
		const qty = Number(o.qty);

		let execPrice: number | null = null;

		if (o.side === 'BUY') {
			execPrice = pickExecPriceForBuy({ open, high, low, entryLow, entryHigh });
			if (execPrice == null) {
				await env.DB.prepare("UPDATE mo_orders SET status='SKIPPED', exec_date=?, reason=? WHERE id=?")
					.bind(tradeDate, '價格未進入買入區間 → 跳過', o.id)
					.run();
				events.push(`⏭️ BUY SKIP ${sym}（未進入區間）`);
				continue;
			}
			const guard = buildTradeGuardResult({ symbol: sym, side: 'BUY', price: execPrice, qty, signal: 'TRY', score: 0 });
			if (!guard.ok) {
				await env.DB.prepare("UPDATE mo_orders SET status='SKIPPED', exec_date=?, reason=? WHERE id=?")
					.bind(tradeDate, `交易門檻未通過 → ${guard.reason}`, o.id)
					.run();
				events.push(`⏭️ BUY SKIP ${sym}（${guard.reason}）`);
				continue;
			}
			const cost = calcTradeCostEstimate({ symbol: sym, side: 'BUY', price: execPrice, qty });
			const grossCashNeed = round2(cost.notionalTwd + cost.totalTwd);
			if (grossCashNeed > cash + 1e-6) {
				await env.DB.prepare("UPDATE mo_orders SET status='SKIPPED', exec_date=?, reason=? WHERE id=?")
					.bind(tradeDate, '現金不足（含成本） → 跳過', o.id)
					.run();
				events.push(`⏭️ BUY SKIP ${sym}（現金不足含成本）`);
				continue;
			}
			cash -= grossCashNeed;

			const pos = await env.DB.prepare('SELECT * FROM mo_positions WHERE symbol=?').bind(sym).first<any>();
			const oldShares = Number(pos?.shares ?? 0);
			const oldAvg = Number(pos?.avg_cost ?? 0);
			const newShares = round2(oldShares + qty);
			const newAvg = newShares > 0 ? (oldShares * oldAvg + qty * execPrice) / newShares : 0;

			if (pos) {
				await env.DB.prepare("UPDATE mo_positions SET shares=?, avg_cost=?, updated_at=datetime('now') WHERE symbol=?")
					.bind(newShares, newAvg, sym)
					.run();
			} else {
				await env.DB.prepare('INSERT INTO mo_positions(symbol,name,shares,avg_cost,opened_date) VALUES (?,?,?,?,?)')
					.bind(sym, o.name ?? '', newShares, newAvg, tradeDate)
					.run();
			}

			await env.DB.prepare("UPDATE mo_orders SET status='EXECUTED', exec_date=?, exec_price=?, reason=? WHERE id=?")
				.bind(tradeDate, execPrice, `成交（模擬） close=${close}｜含成本`, o.id)
				.run();
			events.push(`✅ BUY ${sym} @ ${execPrice} x ${qty}`);
			continue;
		}

		if (o.side === 'SELL') {
			execPrice = pickExecPriceForSell({ open, high, low, entryLow, entryHigh });
			if (execPrice == null) {
				await env.DB.prepare("UPDATE mo_orders SET status='SKIPPED', exec_date=?, reason=? WHERE id=?")
					.bind(tradeDate, '價格未進入賣出區間 → 跳過', o.id)
					.run();
				events.push(`⏭️ SELL SKIP ${sym}（未進入區間）`);
				continue;
			}

			const pos = await env.DB.prepare('SELECT * FROM mo_positions WHERE symbol=?').bind(sym).first<any>();
			const have = Number(pos?.shares ?? 0);
			if (have <= 0) {
				await env.DB.prepare("UPDATE mo_orders SET status='SKIPPED', exec_date=?, reason=? WHERE id=?")
					.bind(tradeDate, '無持倉 → 跳過', o.id)
					.run();
				events.push(`⏭️ SELL SKIP ${sym}（無持倉）`);
				continue;
			}

			const sellQty = Math.min(have, qty);
			const proceeds = calcTradeCostEstimate({ symbol: sym, side: 'SELL', price: execPrice, qty: sellQty });
			cash += round2(proceeds.notionalTwd - proceeds.totalTwd);
			const remain = round2(have - sellQty);

			if (remain <= 0) {
				await env.DB.prepare('DELETE FROM mo_positions WHERE symbol=?').bind(sym).run();
			} else {
				await env.DB.prepare("UPDATE mo_positions SET shares=?, updated_at=datetime('now') WHERE symbol=?").bind(remain, sym).run();
			}

			await env.DB.prepare("UPDATE mo_orders SET status='EXECUTED', exec_date=?, exec_price=?, reason=? WHERE id=?")
				.bind(tradeDate, execPrice, `成交（模擬） close=${close}｜含成本`, o.id)
				.run();
			events.push(`✅ SELL ${sym} @ ${execPrice} x ${sellQty}`);
			continue;
		}
	}

	await env.DB.prepare("UPDATE mo_portfolio_state SET cash_twd=?, updated_at=datetime('now') WHERE id=1").bind(cash).run();
	return events;
}

async function generateRecommendationsMulti(
	env: Env,
	args: {
		tradeDate: string;
		signal: SignalLevel;
		topByValue: any[];
		snapshotCandidates: any[];
		priceByCode: Map<string, any>;
		activeUniverse: { symbols: string[]; source: UniverseSource };
	},
): Promise<{ recs: MoRecommendation[]; debugRows: StrategyDebugRow[] }> {
	const { tradeDate, signal, topByValue, snapshotCandidates, priceByCode, activeUniverse } = args;

	const pf = await env.DB.prepare('SELECT * FROM mo_portfolio_state WHERE id=1').first<any>();
	const principal = Number(pf?.principal_twd ?? 300000);
	let cash = Number(pf?.cash_twd ?? principal);

	const positions = await env.DB.prepare('SELECT * FROM mo_positions').all<any>();
	const posList = positions?.results ?? [];

	const recs: MoRecommendation[] = [];
	const debugRows: StrategyDebugRow[] = [];

	// 1) 先看既有持倉：簡單停損（以收盤對比均價）
	for (const p of posList) {
		const sym = String(p.symbol);
		const row = priceByCode.get(sym);
		if (!row) continue;

		const close = Number(row.close);
		const avg = Number(p.avg_cost ?? 0);
		const sh = Number(p.shares ?? 0);
		if (sh <= 0 || !Number.isFinite(close) || !Number.isFinite(avg) || avg <= 0) continue;

		const pnlPct = close / avg - 1;
		if (pnlPct <= -0.12) {
			const rg = calcExitRangeFromClose(close);
			debugRows.push({ symbol: sym, name: String(p.name ?? ''), stage: 'selected', reason: `stop_loss ${Math.round(pnlPct * 100)}%`, score: 99 });
			recs.push({
				symbol: sym,
				name: String(p.name ?? ''),
				side: 'SELL',
				entryLow: rg.low,
				entryHigh: rg.high,
				qty: sh, // 全出
				weight: 0,
				score: 99,
				reason: `停損（浮虧 ${Math.round(pnlPct * 100)}%）`,
			});
		}
	}

	// 2) 沒有要買就返回（HOLD）
	if (signal === 'HOLD') {
		for (const x of snapshotCandidates.slice(0, 5)) debugRows.push({ symbol: x.code, name: x.name || '', stage: 'rejected', reason: 'signal_hold' });
		return { recs, debugRows };
	}

	// 3) 買入：優先從 universe 挑標的；若 universe 當日完全沒有快照，才回退到成交值排行
	const maxNames = signal === 'AGGRESSIVE' ? 4 : 3;
	const universeRows = snapshotCandidates.length ? snapshotCandidates : filterUniverseCandidates(topByValue, activeUniverse.symbols);
	const basePool = universeRows.length ? universeRows : topByValue;
	const ranked = pickTopCandidates(basePool, 6)
		.map((x) => {
			const a = alphaScoreCandidate(x);
			const px = priceByCode.get(String(x?.code ?? '')) ?? null;
			const resolved = Number.isFinite(Number(x?.close)) && Number(x.close) > 0 ? { close: Number(x.close), source: String(x?.closeSource ?? 'candidate.close') } : resolveCandidateClose({ raw: null, px, top: x });
			return { ...x, score: a.score, alpha: a.detail, close: resolved.close, closeSource: resolved.source };
		})
		.sort((a, b) => b.score - a.score);
	const picks = ranked.slice(0, maxNames);
	for (const x of picks) {
		debugRows.push({
			symbol: x.code,
			name: x.name || '',
			stage: 'candidate',
			reason: `alpha=${x.score} chg=${Number.isFinite(x.alpha?.chgPct) ? x.alpha.chgPct : '—'}% px=${String(x.closeSource ?? 'n/a')}`,
			score: x.score,
			chgPct: x.alpha?.chgPct,
			valueScore: x.alpha?.valueScore,
			momScore: x.alpha?.momScore,
		});
	}
	for (const x of ranked.slice(maxNames)) {
		debugRows.push({ symbol: x.code, name: x.name || '', stage: 'rejected', reason: 'cut_by_rank', score: x.score, chgPct: x.alpha?.chgPct, valueScore: x.alpha?.valueScore, momScore: x.alpha?.momScore });
	}
	for (const x of ranked.filter((x) => !Number.isFinite(Number(x?.close)) || Number(x.close) <= 0)) {
		debugRows.push({ symbol: x.code, name: x.name || '', stage: 'rejected', reason: `missing_close ${String(x.closeSource ?? 'n/a')}`, score: x.score, chgPct: x.alpha?.chgPct, valueScore: x.alpha?.valueScore, momScore: x.alpha?.momScore });
	}

	if (!picks.length) {
		const starter = buildStarterRecommendation({ signal, cash, ranked });
		if (starter) {
			debugRows.push({ symbol: starter.symbol, name: starter.name, stage: 'selected', reason: `starter_fallback qty=${starter.qty}`, score: starter.score });
			recs.push(starter);
		}
		return { recs, debugRows };
	}

	const { budgets, totalBudget } = allocateBudgets({
		signal,
		cash,
		picks: picks.map((x: any) => ({ code: x.code, close: Number(x.close), score: Number(x.score) })),
	});
	for (let i = 0; i < picks.length; i++) {
		const x = picks[i];
		const budget = budgets[i];
		if (budget <= 0) {
			debugRows.push({ symbol: x.code, name: x.name || '', stage: 'rejected', reason: 'budget_zero', score: x.score, chgPct: x.alpha?.chgPct, valueScore: x.alpha?.valueScore, momScore: x.alpha?.momScore });
			continue;
		}
		const w = totalBudget > 0 ? round2(budget / totalBudget) : 0;

		const close = Number(x.close);
		if (!Number.isFinite(close) || close <= 0) {
			debugRows.push({ symbol: x.code, name: x.name || '', stage: 'rejected', reason: `invalid_close ${String(x.closeSource ?? 'n/a')}`, score: x.score, chgPct: x.alpha?.chgPct, valueScore: x.alpha?.valueScore, momScore: x.alpha?.momScore });
			continue;
		}

		const rg = calcEntryRangeFromClose(close);
		const profile = getTradeCostProfile(String(x.code ?? ''));
		const qty = Math.floor(budget / rg.high / profile.minQty) * profile.minQty;

		if (qty <= 0) {
			debugRows.push({ symbol: x.code, name: x.name || '', stage: 'rejected', reason: `qty_zero min=${profile.minQty}`, score: x.score, chgPct: x.alpha?.chgPct, valueScore: x.alpha?.valueScore, momScore: x.alpha?.momScore });
			continue;
		}
		const guard = buildTradeGuardResult({ symbol: String(x.code ?? ''), side: 'BUY', price: rg.high, qty, signal, score: x.score });
		if (!guard.ok) {
			debugRows.push({ symbol: x.code, name: x.name || '', stage: 'rejected', reason: `${guard.reason}｜${guard.costText ?? ''}`.replace(/｜$/, ''), score: x.score, chgPct: x.alpha?.chgPct, valueScore: x.alpha?.valueScore, momScore: x.alpha?.momScore });
			continue;
		}

		debugRows.push({ symbol: x.code, name: x.name || '', stage: 'selected', reason: `budget=${Math.round(budget)} qty=${qty}｜${guard.costText}`, score: x.score, chgPct: x.alpha?.chgPct, valueScore: x.alpha?.valueScore, momScore: x.alpha?.momScore });
		recs.push({
			symbol: x.code,
			name: x.name,
			side: 'BUY',
			entryLow: rg.low,
			entryHigh: rg.high,
			qty,
			weight: round2(w),
			score: x.score,
			reason: (() => {
				const chgPct = Number.isFinite(x.alpha?.chgPct) ? `${x.alpha.chgPct > 0 ? '+' : ''}${x.alpha.chgPct}%` : '—';
				const why = signal === 'AGGRESSIVE' ? '積極：行情偏多，分散布局' : '試單：盤面分歧，小額先試';
				const poolTag = universeRows.length ? 'ETF池' : '成交值回退';
				return `${why}｜${poolTag}｜Alpha ${x.score}｜動能 ${chgPct}`;
			})(),
		});
	}

	if (!recs.length) {
		const starter = buildStarterRecommendation({ signal, cash, ranked: picks });
		if (starter) {
			debugRows.push({ symbol: starter.symbol, name: starter.name, stage: 'selected', reason: `starter_fallback qty=${starter.qty}`, score: starter.score });
			recs.push(starter);
		}
	}

	return { recs, debugRows };
}

async function persistRecommendations(env: Env, tradeDate: string, recs: MoRecommendation[]): Promise<void> {
	// 把舊的 pending 先清掉（避免同一天重複）
	await env.DB.prepare("DELETE FROM mo_orders WHERE signal_date=? AND status='PENDING'").bind(tradeDate).run();

	for (const r of recs) {
		await env.DB.prepare(
			'INSERT INTO mo_orders(signal_date, side, symbol, name, entry_low, entry_high, qty, status, reason) VALUES (?,?,?,?,?,?,?,?,?)',
		)
			.bind(tradeDate, r.side, r.symbol, r.name, r.entryLow, r.entryHigh, r.qty, 'PENDING', r.reason)
			.run();
	}
}


async function persistRecommendationLog(
	env: Env,
	args: {
		tradeDate: string;
		signal: SignalLevel;
		activeUniverse: { symbols: string[]; source: UniverseSource };
		candidateCount: number;
		recCount: number;
		snapshotCount: number;
		note?: string;
	},
): Promise<void> {
	await env.DB.prepare(
		`INSERT INTO mo_recommendation_log (trade_date, signal, universe_source, universe_symbols, candidate_count, rec_count, snapshot_count, note)
		 VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
	)
		.bind(
			args.tradeDate,
			args.signal,
			args.activeUniverse.source,
			args.activeUniverse.symbols.join(','),
			args.candidateCount,
			args.recCount,
			args.snapshotCount,
			args.note ?? null,
		)
		.run();
}

async function replaceStrategyDebugRows(env: Env, tradeDate: string, rows: StrategyDebugRow[]): Promise<void> {
	await env.DB.prepare('DELETE FROM mo_strategy_debug WHERE trade_date=?').bind(tradeDate).run();
	for (const r of rows) {
		await env.DB.prepare(
			`INSERT INTO mo_strategy_debug (trade_date, symbol, name, stage, reason, score, chg_pct, value_score, mom_score)
			 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
		)
			.bind(
				tradeDate,
				r.symbol,
				r.name || null,
				r.stage,
				r.reason,
				r.score ?? null,
				r.chgPct ?? null,
				r.valueScore ?? null,
				r.momScore ?? null,
			)
			.run();
	}
}

async function buildStrategyDebugText(env: Env): Promise<string> {
	await ensureMultiAssetTables(env);
	const recLog = await getLatestRecommendationLog(env);
	if (!recLog) return '目前尚無策略 debug 資料。';
	const tradeDate = String(recLog.trade_date || '');
	const rows = await env.DB.prepare(
		`SELECT symbol, name, stage, reason, score, chg_pct, value_score, mom_score
		 FROM mo_strategy_debug
		 WHERE trade_date=?
		 ORDER BY CASE stage WHEN 'selected' THEN 1 WHEN 'candidate' THEN 2 ELSE 9 END, score DESC, id ASC
		 LIMIT 12`,
	).bind(tradeDate).all<any>();
	const rs = rows?.results ?? [];
	const lines: string[] = [];
	lines.push(`🧪 MO Debug（${tradeDate || 'n/a'}）`);
	lines.push(`source：${recLog.universe_source}｜signal：${recLog.signal}`);
	lines.push(`candidates：${recLog.candidate_count}｜recs：${recLog.rec_count}`);
	if (recLog.note) lines.push(`note：${String(recLog.note).slice(0, 120)}`);
	if (!rs.length) return lines.join('\n');
	const selected = rs.filter((r: any) => String(r.stage) === 'selected');
	const candidates = rs.filter((r: any) => String(r.stage) === 'candidate').slice(0, 3);
	const rejected = rs.filter((r: any) => String(r.stage) !== 'selected' && String(r.stage) !== 'candidate').slice(0, 5);
	if (selected.length) {
		lines.push('');
		lines.push('✅ Selected');
		for (const r of selected.slice(0, 5)) lines.push(`${r.symbol}｜score ${Number(r.score ?? 0).toFixed(1)}｜${r.reason}`);
	}
	if (candidates.length) {
		lines.push('');
		lines.push('📈 Top candidates');
		for (const r of candidates) lines.push(`${r.symbol}｜score ${Number(r.score ?? 0).toFixed(1)}｜${r.reason}`);
	}
	if (rejected.length) {
		lines.push('');
		lines.push('⛔ Rejected');
		for (const r of rejected) lines.push(`${r.symbol}｜${r.reason}`);
	}
	return lines.join('\n');
}

function formatRecsForLine(recs: MoRecommendation[]): string {
	if (!recs.length) return '🧠 明日建議：不動（無明顯機會）';
	const lines: string[] = [];
	lines.push('🧠 明日建議（多標的）');
	for (const [i, r] of recs.entries()) {
		const side = r.side === 'BUY' ? 'BUY' : 'SELL';
		lines.push(`${i + 1}. ${side} ${r.symbol} ${r.name}`.trim());
		lines.push(`   價格區間：${r.entryLow} – ${r.entryHigh}`);
		lines.push(`   數量：${r.qty} 股｜權重：${Math.round(r.weight * 100)}%｜Score：${r.score}`);
		lines.push(`   原因：${r.reason}`);
	}
	return lines.join('\n');
}

async function buildPriceByCode(stocksAll: any[]): Promise<Map<string, any>> {
	const m = new Map<string, any>();
	for (const r of stocksAll) {
		const code = getStr(r, ['證券代號', 'Code', 'code', 'StockCode']);
		if (!code) continue;
		m.set(code, {
			code,
			open: getNum(r, ['開盤價', 'Open', 'open', '開盤']),
			high: getNum(r, ['最高價', 'High', 'high', '最高']),
			low: getNum(r, ['最低價', 'Low', 'low', '最低']),
			close: getNum(r, ['收盤價', 'Close', 'close', '收盤']),
			chg: getNum(r, ['漲跌價差', 'Change', 'chg', '漲跌', '漲跌價差(元)']),
		});
	}
	return m;
}

async function adminPushOnly(env: Env, tradeDate: string): Promise<string> {
	const summary = await env.DB.prepare('SELECT summary_text FROM twse_daily_summary WHERE date=? LIMIT 1').bind(tradeDate).first<any>();

	const mark = await env.DB.prepare(
		'SELECT trade_date, symbol, close_price, cash_twd, position_shares, position_value_twd, total_equity_twd, return_pct, note FROM daily_mark WHERE trade_date=? LIMIT 1',
	)
		.bind(tradeDate)
		.first<any>();

	const st = await env.DB.prepare(
		'SELECT mode, consecutive_losses, COALESCE(consecutive_wins,0) AS consecutive_wins FROM strategy_state WHERE id=1',
	).first<any>();

	const lines: string[] = [];
	lines.push('📊 Market Observer');
	lines.push(`日期：${tradeDate}`);
	lines.push('');

	// 盤後摘要（純文字）
	if (summary?.summary_text) {
		lines.push(summary.summary_text);
	} else {
		lines.push('（今日尚無盤後摘要 summary_text）');
	}

	lines.push('');
	lines.push('📌 策略池狀態（30萬）');

	if (mark) {
		lines.push(`總資產：${Math.round(Number(mark.total_equity_twd)).toLocaleString()} 元`);
		lines.push(`現金：${Math.round(Number(mark.cash_twd)).toLocaleString()} 元`);
		lines.push(`持倉市值：${Math.round(Number(mark.position_value_twd)).toLocaleString()} 元`);
		lines.push(`累積報酬：${(Number(mark.return_pct) * 100).toFixed(2)}%`);

		if (mark.symbol) {
			const px = Number(mark.close_price);
			const sh = Number(mark.position_shares);
			lines.push(`持倉：${mark.symbol}｜${sh}${Number.isFinite(px) ? ` 股｜收盤 ${px}` : ' 股'}`);
		} else {
			lines.push('持倉：無');
		}

		if (mark.note) lines.push(`備註：${mark.note}`);
	} else {
		lines.push('（今日尚無 daily_mark）');
	}

	// 模式/連勝連敗
	if (st) {
		const mode = st.mode || 'NORMAL';
		const conLoss = Number(st.consecutive_losses ?? 0);
		const conWin = Number(st.consecutive_wins ?? 0);
		lines.push(`模式：${mode}（連跌 ${conLoss} / 連漲 ${conWin}）`);
	}

	// Multi-asset pool（若啟用）
	if (envFlag(env, 'FEATURE_MULTI_ASSET', false)) {
		await ensureMultiAssetTables(env);
		const pf = await env.DB.prepare('SELECT principal_twd, cash_twd FROM mo_portfolio_state WHERE id=1').first<any>();
		const positions = await env.DB.prepare('SELECT symbol, name, shares, avg_cost FROM mo_positions').all<any>();
		lines.push('');
		lines.push('📌 多標的策略池（30萬）');
		if (pf) {
			lines.push(`現金：${Math.round(Number(pf.cash_twd)).toLocaleString()} 元`);
		}
		const ps = positions?.results ?? [];
		if (!ps.length) lines.push('持倉：無');
		else {
			for (const p of ps) {
				lines.push(`持倉：${p.symbol} ${p.name}｜${p.shares} 股｜均價 ${round2(Number(p.avg_cost))}`);
			}
		}
	}
	const msg = lines.join('\n');

	// ✅ 用你專案既有的推播函式（你剛剛已經修好 pushLine 問題）
	await linePush(env, msg);

	return `OK push-only. tradeDate=${tradeDate} pushed=true reason=push_only`;
}

async function runDailyProcess(env: Env, opts?: { force?: boolean }): Promise<{ tradeDate: string; pushed: boolean; reason?: string }> {
	const force = Boolean(opts?.force);
	FORCE_NO_STORE = force;

	// 先拿到「交易日」，後面 DB key / 防重複都用這個
	let tradeDate: string;
	let raw: any;
	let summary: string;
	let stocksAll: any[];
	let isTodayReady = false;
	try {
		({ tradeDate, raw, summary, stocksAll, isTodayReady } = await buildDailySummary({ noStore: force }));
		await upsertDailyMark(env, tradeDate, isTodayReady ? 'FULL' : 'PARTIAL', isTodayReady ? undefined : `latest_trade_date=${tradeDate}`);
	} catch (e: any) {
		const today = twTodayString();
		const msg = String(e?.message || e);
		// 盤後資料未就緒 / TWSE 格式變動時，不視為錯誤：記錄後直接跳過，等下一次 tick
		const fatal = msg.includes('trade date unresolved') || msg.includes('fetch timeout') || msg.includes('fetch failed');
		if (fatal) {
			console.warn('[TWSE] ABORT:', msg);
			await upsertDailyMark(env, today, 'NONE', `ABORT: ${msg}`);
			return { tradeDate: today, pushed: false, reason: `ABORT: ${msg}` };
		}

		console.warn('[TWSE] not ready:', msg);
		const readyLevel: 'NONE' | 'PARTIAL' = msg.includes('stocksCount=') ? 'NONE' : 'PARTIAL';
		await upsertDailyMark(env, today, readyLevel, msg);
		tradeDate = today;
		raw = null;
		summary = '';
		stocksAll = [];
		isTodayReady = false;
		// 不 return：讓後續策略/明日建議仍可嘗試（例如已有人手動 seed / 或使用其他市場）
	}

	// ✅ 盤後摘要落地：只有在「今天盤後資料 ready」時才落地/推播
	// 但策略引擎/明日建議可以用「最新交易日」資料運作（例如隔天早上）。
	let summaryInserted = false;
	if (isTodayReady || force) {
		if (!force) {
			const exists = await env.DB.prepare('SELECT 1 FROM twse_daily_summary WHERE date = ? LIMIT 1').bind(tradeDate).first();
			if (!exists) {
				await env.DB.prepare('INSERT INTO twse_daily_raw (date, payload_json) VALUES (?, ?)').bind(tradeDate, JSON.stringify(raw)).run();
				await env.DB.prepare('INSERT INTO twse_daily_summary (date, summary_text) VALUES (?, ?)').bind(tradeDate, summary).run();
				summaryInserted = true;
			}
		} else {
			// force: overwrite
			await env.DB.prepare('INSERT OR REPLACE INTO twse_daily_raw (date, payload_json) VALUES (?, ?)')
				.bind(tradeDate, JSON.stringify(raw))
				.run();
			await env.DB.prepare('INSERT OR REPLACE INTO twse_daily_summary (date, summary_text) VALUES (?, ?)').bind(tradeDate, summary).run();
			summaryInserted = true;
		}
	}

	// --- 策略引擎 + 每日快照（策略池 30 萬） ---
	const top5 = raw?.topByValue ?? [];
	const dir = raw?.idx?.dir ?? '持平';
	const concentration = Number(raw?.concentration ?? NaN);
	const up = Number(raw?.breadth?.up ?? 0);
	const down = Number(raw?.breadth?.down ?? 0);
	const flat = Number(raw?.breadth?.flat ?? 0);
	const valid = Number(raw?.breadth?.valid ?? 0);

	// === 多標的推薦 / 模擬成交（FEATURE_MULTI_ASSET） ===
	if (envFlag(env, 'FEATURE_MULTI_ASSET', true)) {
		await ensureMultiAssetTables(env);
		const priceByCode = await buildPriceByCode(stocksAll);
		const activeUniverse = await getActiveUniverse(env);
		let recs: MoRecommendation[] = [];

		const hasSnapshot = Array.isArray(stocksAll) && stocksAll.length > 0;
		if (!hasSnapshot) {
			console.warn('[MO] skip recommendations: no TWSE stock snapshot (orders will not be regenerated).');
		}

		// 先把「前一天的 pending 訂單」用今天 OHLC 嘗試成交（FEATURE_SIM 才做）
		const simOn = envFlag(env, 'FEATURE_SIM', true);
		const execEvents = simOn ? await executePendingOrders(env, tradeDate, priceByCode) : [];

		// 今日產生明日建議（多標的）
		if (hasSnapshot) {
			const signal = decideSignalLevel({ dir, up, down, concentration, valid });
			const universeRows = buildUniverseSnapshotCandidates(stocksAll, activeUniverse.symbols, priceByCode, top5);
			const { recs: nextRecs, debugRows } = await generateRecommendationsMulti(env, {
				tradeDate,
				signal,
				topByValue: top5,
				snapshotCandidates: universeRows,
				priceByCode,
				activeUniverse,
			});
			recs = nextRecs;
			// 只有在有 snapshot 時才會覆寫 PENDING（避免 not-ready 時把既有 seed 清空）
			await persistRecommendations(env, tradeDate, recs);
			await replaceStrategyDebugRows(env, tradeDate, debugRows);
			await persistRecommendationLog(env, {
				tradeDate,
				signal,
				activeUniverse,
				candidateCount: universeRows.length || top5.length,
				recCount: recs.length,
				snapshotCount: stocksAll.length,
				note: universeRows.length ? `use_universe ${activeUniverse.source}` : 'fallback_top_by_value',
			});
		}

		// 計算今日資產快照（用收盤）
		const pf = await env.DB.prepare('SELECT * FROM mo_portfolio_state WHERE id=1').first<any>();
		const principal = Number(pf?.principal_twd ?? 300000);
		const cash = Number(pf?.cash_twd ?? principal);

		const positions = await env.DB.prepare('SELECT * FROM mo_positions').all<any>();
		let posValue = 0;
		for (const p of positions?.results ?? []) {
			const row = priceByCode.get(String(p.symbol));
			const close = Number(row?.close);
			if (Number.isFinite(close)) posValue += Number(p.shares) * close;
		}

		const equity = cash + posValue;
		const retPct = principal > 0 ? equity / principal - 1 : 0;

		// 同步寫入你既有 daily_mark（用 symbol 留空，避免破壞既有表）
		await env.DB.prepare(
			`INSERT OR REPLACE INTO daily_mark
			 (trade_date, symbol, close_price, cash_twd, position_shares, position_value_twd, total_equity_twd, return_pct, note)
			 VALUES (?, NULL, NULL, ?, 0, ?, ?, ?, ?)`,
		)
			.bind(
				tradeDate,
				cash,
				posValue,
				equity,
				retPct,
				`${recs.length ? 'multi_asset' : 'multi_asset_no_rec'}|universe=${activeUniverse.symbols.join(',')}|recs=${recs.length}`
			)
			.run();

		// streak/mode（沿用你原本的 strategy_state 來記 streak，方便既有 UI；不影響交易）
		const streak = await updateStreaksAndMode(env, tradeDate, equity);

		const execBlock = execEvents.length
			? `\n\n📌 今日模擬成交\n${execEvents.join('\n')}`
			: simOn
				? `\n\n📌 今日模擬成交\n（無成交 / 無待成交訂單）`
				: `\n\n📌 模擬成交\n（FEATURE_SIM=0，僅產出建議）`;

		const poolBlock =
			`\n\n📊 策略池狀態（30萬｜多標的）\n` +
			`總資產：${Math.round(equity).toLocaleString()} 元\n` +
			`現金：${Math.round(cash).toLocaleString()} 元\n` +
			`持倉市值：${Math.round(posValue).toLocaleString()} 元\n` +
			`累積報酬：${(retPct * 100).toFixed(2)}%\n` +
			`模式：${streak.mode}（連跌 ${streak.conLoss} / 連漲 ${streak.conWin}）`;

		const recText = formatRecsForLine(recs);
		if (isTodayReady || force) {
			await linePush(env, `${summary}${execBlock}\n\n${recText}${poolBlock}`);
			return { tradeDate, pushed: true };
		}
		// 不是盤後 ready（例如隔天早上）：不推播，但仍已產生/更新明日建議
		return { tradeDate, pushed: false, reason: 'latest_only' };
	}

	// === 單一標的（舊 v1） ===
	const { actionText, note } = await runStrategyEngine(env, {
		tradeDate,
		dir,
		up,
		down,
		flat,
		valid,
		concentration,
		top5,
	});

	const mark = await writeDailyMark(env, { tradeDate, note, top5 });

	// ✅ streak/mode 更新（避免 streak is not defined）
	const streak = await updateStreaksAndMode(env, tradeDate, mark.equity);

	const poolBlock =
		`\n\n📊 策略池狀態（只看 30 萬）\n` +
		`總資產：${Math.round(mark.equity).toLocaleString()} 元\n` +
		`現金：${Math.round(mark.cash).toLocaleString()} 元\n` +
		`持倉市值：${Math.round(mark.posValue).toLocaleString()} 元\n` +
		`累積報酬：${(mark.retPct * 100).toFixed(2)}%\n` +
		`模式：${streak.mode}（連跌 ${streak.conLoss} / 連漲 ${streak.conWin}）\n` +
		(mark.symbol ? `目前持倉：${mark.symbol}｜約 ${mark.shares} 股（零股）` : `目前持倉：無`);

	if (isTodayReady || force) {
		await linePush(env, `${summary}\n\n${actionText}${poolBlock}`);
		return { tradeDate, pushed: true };
	}
	return { tradeDate, pushed: false, reason: 'latest_only' };
}

async function updateStreaksAndMode(
	env: Env,
	tradeDate: string,
	equity: number,
): Promise<{ mode: string; conLoss: number; conWin: number }> {
	const prev = await env.DB.prepare(
		'SELECT trade_date, total_equity_twd FROM daily_mark WHERE trade_date < ? ORDER BY trade_date DESC LIMIT 1',
	)
		.bind(tradeDate)
		.first<any>();

	const st = await env.DB.prepare(
		'SELECT mode, consecutive_losses, COALESCE(consecutive_wins,0) AS consecutive_wins FROM strategy_state WHERE id=1',
	).first<any>();

	let mode = st?.mode || 'NORMAL';
	let conLoss = Number(st?.consecutive_losses ?? 0);
	let conWin = Number(st?.consecutive_wins ?? 0);

	if (prev && Number.isFinite(Number(prev.total_equity_twd))) {
		const prevEq = Number(prev.total_equity_twd);

		if (equity > prevEq) {
			conWin += 1;
			conLoss = 0;
		} else if (equity < prevEq) {
			conLoss += 1;
			conWin = 0;
		}
	}

	if (conLoss >= 3) mode = 'SLOW';
	if (mode === 'SLOW' && conWin >= 2) mode = 'NORMAL';

	await env.DB.prepare("UPDATE strategy_state SET mode=?, consecutive_losses=?, consecutive_wins=?, updated_at=datetime('now') WHERE id=1")
		.bind(mode, conLoss, conWin)
		.run();

	return { mode, conLoss, conWin };
}
type DailyPipelineResult = {
	tradeDate: string;
	pushed: boolean;
	reason: 'normal_pipeline' | 'already_exists' | 'latest_only' | 'push_only' | 'error';
	message?: string;
};

// ============================
// Tick dispatcher (15-min cron)
// - 讓 cron 變成「事件分派器」，避免重複推播/重複跑重任務
// - 不靠 migration：用 CREATE TABLE IF NOT EXISTS 確保可直接上線
// ============================

type TickMarkRow = {
	trade_date: string;
	post_close_done: number;
	push_only_done: number;
	updated_at: string;
} | null;

type TickAuditRow = {
	tick_id: string;
	triggered_at: string;
	finished_at: string | null;
	duration_ms: number | null;
	lock_status: string;
	jobs_planned: number;
	jobs_done: number;
	jobs_failed: number;
	summary: string | null;
	error: string | null;
} | null;

async function ensureTickMarksTable(env: Env): Promise<void> {
	await env.DB.prepare(
		"CREATE TABLE IF NOT EXISTS mo_tick_marks (trade_date TEXT PRIMARY KEY, post_close_done INTEGER NOT NULL DEFAULT 0, push_only_done INTEGER NOT NULL DEFAULT 0, updated_at TEXT NOT NULL DEFAULT (datetime('now')))",
	).run();
}

async function ensureTickAuditTable(env: Env): Promise<void> {
	await env.DB.prepare(
		"CREATE TABLE IF NOT EXISTS mo_tick_audit (tick_id TEXT PRIMARY KEY, triggered_at TEXT NOT NULL DEFAULT (datetime('now')), finished_at TEXT, duration_ms INTEGER, lock_status TEXT NOT NULL DEFAULT 'unknown', jobs_planned INTEGER NOT NULL DEFAULT 0, jobs_done INTEGER NOT NULL DEFAULT 0, jobs_failed INTEGER NOT NULL DEFAULT 0, summary TEXT, error TEXT)",
	).run();
	await env.DB.prepare('CREATE INDEX IF NOT EXISTS idx_mo_tick_audit_triggered_at ON mo_tick_audit(triggered_at)').run();
}

function tickId15m(tradeDate: string, hh: number, mm: number): string {
	const m15 = Math.floor(mm / 15) * 15;
	return `${tradeDate.replace(/-/g, '')}-${String(hh).padStart(2, '0')}${String(m15).padStart(2, '0')}`;
}

async function tryAcquireTickLock(env: Env, tickId: string, jobsPlanned: number, summary: string): Promise<boolean> {
	try {
		await env.DB.prepare("INSERT INTO mo_tick_audit (tick_id, lock_status, jobs_planned, summary) VALUES (?, 'acquired', ?, ?)")
			.bind(tickId, jobsPlanned, summary)
			.run();
		return true;
	} catch (e: any) {
		const msg = String(e?.message || e).toLowerCase();
		if (msg.includes('unique') || msg.includes('constraint')) {
			// Duplicate tick: mark once and exit fast.
			await env.DB.prepare("UPDATE mo_tick_audit SET lock_status='skipped_duplicate', summary=COALESCE(summary,'') WHERE tick_id=?")
				.bind(tickId)
				.run();
			return false;
		}
		throw e;
	}
}

async function finishTickAudit(
	env: Env,
	tickId: string,
	patch: { durationMs: number; jobsDone: number; jobsFailed: number; summary: string; error?: string | null },
): Promise<void> {
	await env.DB.prepare(
		"UPDATE mo_tick_audit SET finished_at=datetime('now'), duration_ms=?, jobs_done=?, jobs_failed=?, summary=?, error=?, lock_status=CASE WHEN lock_status='acquired' THEN 'finished' ELSE lock_status END WHERE tick_id=?",
	)
		.bind(patch.durationMs, patch.jobsDone, patch.jobsFailed, patch.summary, patch.error || null, tickId)
		.run();
}

async function getTickMark(env: Env, tradeDate: string): Promise<TickMarkRow> {
	const row = await env.DB.prepare(
		'SELECT trade_date, post_close_done, push_only_done, updated_at FROM mo_tick_marks WHERE trade_date=? LIMIT 1',
	)
		.bind(tradeDate)
		.first<any>();
	if (!row) return null;
	return {
		trade_date: String(row.trade_date),
		post_close_done: Number(row.post_close_done || 0),
		push_only_done: Number(row.push_only_done || 0),
		updated_at: String(row.updated_at || ''),
	};
}

async function upsertTickMark(env: Env, tradeDate: string, patch: { postCloseDone?: boolean; pushOnlyDone?: boolean }): Promise<void> {
	const existing = await getTickMark(env, tradeDate);
	const postCloseDone = patch.postCloseDone != null ? (patch.postCloseDone ? 1 : 0) : (existing?.post_close_done ?? 0);
	const pushOnlyDone = patch.pushOnlyDone != null ? (patch.pushOnlyDone ? 1 : 0) : (existing?.push_only_done ?? 0);
	await env.DB.prepare(
		"INSERT INTO mo_tick_marks (trade_date, post_close_done, push_only_done, updated_at) VALUES (?, ?, ?, datetime('now')) ON CONFLICT(trade_date) DO UPDATE SET post_close_done=excluded.post_close_done, push_only_done=excluded.push_only_done, updated_at=datetime('now')",
	)
		.bind(tradeDate, postCloseDone, pushOnlyDone)
		.run();
	async function hasDailySummary(env: Env, tradeDate: string): Promise<boolean> {
		try {
			const row = await env.DB.prepare('SELECT summary_text FROM twse_daily_summary WHERE date=? LIMIT 1').bind(tradeDate).first<any>();
			const txt = row?.summary_text;
			return typeof txt === 'string' && txt.trim().length > 0;
		} catch (e) {
			console.warn('hasDailySummary failed', e);
			return false;
		}
	}
}

/**
 * Tick (每 15 分鐘) 的唯一入口：判斷「現在該做什麼」，只做一次。
 * - 盤後報告：14:30–18:30（資料未就緒就跳過，等下一個 tick）
 * - Push-only：16:00–23:30（一天只重推播一次，避免 spam）
 */
async function dispatchTick(env: Env): Promise<void> {
	const tradeDate = twTodayString();
	const { hh, mm } = twNowHM();
	const startedAt = Date.now();
	await ensureTickMarksTable(env);
	await ensureTickAuditTable(env);
	const mark = await getTickMark(env, tradeDate);

	const inPostClose = inWindow(hh, mm, 14, 30, 18, 30);
	const inPushOnly = inWindow(hh, mm, 16, 0, 23, 30);
	const jobsPlanned = (inPostClose ? 1 : 0) + (inPushOnly ? 1 : 0);
	const tickId = tickId15m(tradeDate, hh, mm);
	const lockSummary = `tick=${tickId} t=${String(hh).padStart(2, '0')}:${String(mm).padStart(2, '0')} postClose=${inPostClose ? 'Y' : 'N'} pushOnly=${inPushOnly ? 'Y' : 'N'}`;
	const acquired = await tryAcquireTickLock(env, tickId, jobsPlanned, lockSummary);
	if (!acquired) {
		console.log(`tick: skipped duplicate tickId=${tickId}`);
		return;
	}

	let jobsDone = 0;
	let jobsFailed = 0;
	let finalSummary = lockSummary;
	let finalError: string | null = null;

	// 1) 盤後主流程（重任務）
	//    ✅ 只有在「summary 真的寫入成功」時，才把 post_close_done 設為 1
	if (inPostClose && !(mark?.post_close_done === 1)) {
		try {
			const result = await runDailyPipeline(env, tradeDate);

			if (result.reason === 'error') {
				jobsFailed += 1;
				finalError = `post_close_err: ${result.message || 'unknown'}`;
				finalSummary += ` | post_close=error`;
				console.log(`tick: post_close error. tradeDate=${tradeDate} err=${result.message || ''}`);
			} else if (result.reason === 'latest_only') {
				// 資料尚未 ready：不要算失敗，也不要設 done，留給下一個 tick 繼續重試
				finalSummary += ` | post_close=not_ready`;
				console.log(`tick: post_close not_ready. tradeDate=${tradeDate}`);
			} else {
				// normal_pipeline / already_exists：再用 DB 事實確認 summary 已存在且非空
				const ok = await hasDailySummary(env, result.tradeDate);
				if (ok) {
					await upsertTickMark(env, tradeDate, { postCloseDone: true });
					jobsDone += 1;
					console.log(`tick: post_close done. tradeDate=${tradeDate} pushed=${result.pushed} reason=${result.reason}`);
					finalSummary += ` | post_close=done(pushed=${result.pushed ? 'Y' : 'N'},reason=${result.reason})`;
				} else {
					finalSummary += ` | post_close=not_ready`;
					console.log(`tick: post_close not_ready(summary_empty). tradeDate=${tradeDate}`);
				}
			}
		} catch (e: any) {
			jobsFailed += 1;
			finalError = `post_close_err: ${String(e?.message || e)}`;
			finalSummary += ` | post_close=error`;
			console.log(`tick: post_close error. tradeDate=${tradeDate} err=${String(e?.message || e)}`);
		}
	}

	// 2) Push-only（輕任務，一天一次）
	if (inPushOnly && !(mark?.push_only_done === 1)) {
		try {
			await adminPushOnly(env, tradeDate);
			await upsertTickMark(env, tradeDate, { pushOnlyDone: true });
			jobsDone += 1;
			finalSummary += ` | push_only=done`;
			console.log(`tick: push_only done. tradeDate=${tradeDate}`);
		} catch (e: any) {
			jobsFailed += 1;
			finalError = finalError || `push_only_err: ${String(e?.message || e)}`;
			finalSummary += ` | push_only=error`;
			console.log(`tick: push_only error. tradeDate=${tradeDate} err=${String(e?.message || e)}`);
		}
	}

	// 3) Heartbeat（永遠可做）
	console.log(`tick: heartbeat tradeDate=${tradeDate} time=${String(hh).padStart(2, '0')}:${String(mm).padStart(2, '0')}`);

	await finishTickAudit(env, tickId, {
		durationMs: Date.now() - startedAt,
		jobsDone,
		jobsFailed,
		summary: finalSummary,
		error: finalError,
	});
}

/**
 * 這個函式要做的事很單純：
 * - 直接「呼叫你現有的正常流程」跑一次
 * - 回傳 pushed / reason
 *
 * ✅ 你只要把 TODO 那行換成你現有的正常流程函式名稱即可
 */
async function runDailyPipeline(env: Env, tradeDate: string): Promise<DailyPipelineResult> {
	try {
		const out = await runDailyProcess(env, { force: false });

		// runDailyProcess 會在「資料尚未 ready」時回 reason='latest_only'
		if (out.reason === 'latest_only') {
			return { tradeDate: out.tradeDate, pushed: false, reason: 'latest_only' };
		}

		const reason = out.reason === 'already_exists' ? 'already_exists' : 'normal_pipeline';
		return { tradeDate: out.tradeDate, pushed: out.pushed, reason };
	} catch (e: any) {
		return { tradeDate, pushed: false, reason: 'error', message: String(e?.message || e) };
	}
}

async function hasDailySummary(env: Env, tradeDate: string): Promise<boolean> {
	const r = await env.DB.prepare(
		`
    SELECT summary_text
    FROM twse_daily_summary
    WHERE date = ?
    LIMIT 1
  `,
	)
		.bind(tradeDate)
		.first<any>();

	if (!r) return false;

	const txt = String(r.summary_text || '').trim();
	return txt.length > 0;
}

export default {
	async fetch(req: Request, env: Env) {
		const url = new URL(req.url);

		// LINE webhook
		if (url.pathname === '/webhook') {
			let body: any;
			try {
				body = await req.json();
			} catch (e) {
				console.warn('[LINE] invalid json');
				return new Response('OK');
			}

			const events: any[] = Array.isArray(body?.events) ? body.events : [];
			console.log(`[LINE] webhook events=${events.length}`);

			// 只做「快速 reply」：避免 replyToken 超時
			for (const ev of events) {
				const replyToken = String(ev?.replyToken || '');
				const type = String(ev?.type || '');
				const msgType = String(ev?.message?.type || '');
				const text = safeText(ev?.message?.text);
				console.log(`[LINE] event type=${type} msgType=${msgType} hasReplyToken=${Boolean(replyToken)}`);

				if (!replyToken || type !== 'message' || msgType !== 'text') continue;

				try {
					const t = text.toLowerCase();
					let out = '';
					if (t === 'status' || t === 'mo status' || t === '狀態' || t === 'mo狀態' || t === 'mo 狀態') {
						out = await buildStatusText(env);
					} else if (t.includes('昨日') || t.includes('yesterday') || t.includes('report') || t.includes('盤後')) {
						out = await buildYesterdayReport(env);
					} else if (t.includes('建議') || t.includes('推薦') || t.includes('明日') || t.includes('recs') || t.includes('recommend')) {
						out = await buildLatestRecs(env);
					} else if (t === 'debug' || t === 'mo debug' || t.includes('除錯')) {
						out = await buildStrategyDebugText(env);
					} else if (t.includes('universe') || t.includes('標的池') || t.includes('池')) {
						const activeUniverse = await getActiveUniverse(env);
						out = `🎯 目前標的池（${activeUniverse.source}）\n${activeUniverse.symbols.join('、')}`;
					} else if (t === 'help' || t === 'mo help' || t === '幫助' || t === 'mo 幫助') {
						out = ['MO 指令（LINE）', '1) 狀態 / mo status', '2) 昨日報告 / report', '3) 建議 / 推薦', '4) universe / 標的池（看目前 ETF 池）', '5) debug / 除錯（看候選與被擋原因）'].join('\n');
					} else {
						out = '收到！你可以輸入：狀態 / 昨日報告 / 建議（或輸入 help）';
					}

					await lineReply(env, replyToken, out.slice(0, 4900));
					console.log('[LINE] reply ok');
				} catch (e: any) {
					console.error('[LINE] reply failed:', e?.message || e);
				}
			}

			return new Response('OK');
		}

		// 手動觸發：/admin/run?token=XXX&force=1
		if (url.pathname === '/admin/run') {
			const token = url.searchParams.get('token') || '';
			if (!env.ADMIN_TOKEN) return new Response('ADMIN_TOKEN not set', { status: 500 });
			if (token !== env.ADMIN_TOKEN) return new Response('Forbidden', { status: 403 });
			const tradeDate = url.searchParams.get('date') || twTodayString();
			const pushOnly = url.searchParams.get('push') === '1';
			if (pushOnly) {
				return new Response(await adminPushOnly(env, tradeDate), { status: 200 });
			}
			const force = url.searchParams.get('force') === '1' || url.searchParams.get('force') === 'true';
			try {
				const r = await runDailyProcess(env, { force });
				return new Response(`OK admin run. tradeDate=${r.tradeDate} pushed=${r.pushed}${r.reason ? ' reason=' + r.reason : ''}`);
			} catch (e) {
				return new Response('ERR: ' + String(e), { status: 500 });
			}
		}

		if (url.pathname === '/health') return new Response('ok');

		return new Response('market-observer running');
	},

	async scheduled(event: ScheduledEvent, env: Env): Promise<void> {
		try {
			await dispatchTick(env);
		} catch (e: any) {
			console.error('scheduled error:', e?.stack || e);
		}
	},
};
