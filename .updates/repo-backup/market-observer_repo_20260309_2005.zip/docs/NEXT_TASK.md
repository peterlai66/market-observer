## 0.14.3
- Operator execution checklist
- `mo recommendation-scoreboard` now prints `operator_execution_checklist_summary`, `operator_execution_checklist_items`, and `operator_execution_checklist_actions`.
- Verify with `npm run mo -- doctor` then `npm run mo -- recommendation-scoreboard`.

Next target: 0.14.4 operator publish audit envelope

## 0.14.2
- Added weekly operator message layer for report payload shaping and publish-ready messaging.

## 0.13.9
- Operator final decision summary
- `mo recommendation-scoreboard` now prints `operator_final_decision_summary`, `operator_final_decision_findings`, and `operator_final_decision_actions`.
- Verify with `npm run mo -- doctor` then `npm run mo -- recommendation-scoreboard`.

Next target: 0.14.0 operator execution checklist
## 0.13.7
- Full Pipeline Readiness Summary
- `mo recommendation-scoreboard` now prints `pipeline_readiness_summary`, `pipeline_readiness_findings`, and `pipeline_readiness_actions`.
- Verify with `npm run mo -- doctor` then `npm run mo -- recommendation-scoreboard`.

Next target: 0.13.7 execution validation unlock checks


- 0.14.2: added weekly_delivery_formatting_summary / weekly_delivery_formatting_blocks / weekly_delivery_formatting_actions for LINE/email/log payload shaping.
