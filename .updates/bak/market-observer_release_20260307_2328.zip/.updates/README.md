# .updates directory contract

- inbox/: incoming patch / release package waiting for mo patch / mo update
- work/: temporary extraction and staging area
- bak/: archive of consumed patch / release packages
- repo-backup/: repository snapshot before patch / update
- outbox/: generated dev / patch / release / handoff artifacts (single root, file-name based)
- outbox/bak/: archived previous *_latest.zip artifacts
- history/: update history and operation records

Deprecated directories that must not exist anymore:
- outbox/dev/
- outbox/patch/
- outbox/release/
- outbox/handoff/
- .updates/backup/


## artifact validation
- 正式 release 產出後，先執行 `npm run mo -- validate-artifacts`。
- release 正式入口檔名固定為 `market-observer_release_latest.zip`。
- 不可在 `.updates/outbox/` 留下 `market-observer_release_<version>.zip` 之類版本號式 release 檔名。
