# SCRIPTS GUIDE

## Core commands
- `npm run mo -- doctor`
- `npm run mo -- smoke`
- `npm run mo -- smoke-worker`
- `npm run mo -- pack`
- `npm run mo -- patch`
- `npm run mo -- release`
- `npm run mo -- update`
- `npm run mo -- deploy`
- `npm run mo -- logs`

## When to run what
### 工具鏈 / 文件變更
1. `npm run mo -- smoke`
2. `npm run mo -- update`

### Worker / src / wrangler / migrations 變更
1. `npm run mo -- smoke`
2. `npm run mo -- smoke-worker`
3. `npm run mo -- update`
4. `npm run mo -- deploy`

## Important rule
- `update` 只更新 local repo。
- `deploy` 才會把 Worker 發佈到 Cloudflare。
- 若 release 包內含 `src/`、`wrangler.jsonc`、`migrations/`、`worker-configuration.d.ts`，update 後必須 deploy。
- 所有 release 必須同步更新 `VERSION`、`CHANGELOG.md`、`RELEASE_NOTES.md`，以及受影響文件。

## pack family
- `pack` → `.updates/outbox/market-observer_dev_latest.zip`
- `pack:patch` → `.updates/outbox/market-observer_patch_latest.zip`
- `pack:release` → `.updates/outbox/market-observer_release_latest.zip`
- `outbox/bak/` → previous `_latest.zip` 歸檔

## outbox contract
- 單一根目錄：`.updates/outbox/`
- 廢棄子目錄：`outbox/dev`、`outbox/patch`、`outbox/release`、`outbox/handoff`
- `sync-structure`、`patch`、`update` 都必須自動清理廢棄子目錄

## handoff rule
- `mo pack` 只產生 local 最新快照，不是 handoff 包。
- 聊天中輸入 `handoff` 時，AI 必須先比對 repo / 文件 / 規則 / 未修 bug，再產生新的 `mo_handoff_YYYYMMDD_HHMM.zip`。
- AI 不可把使用者上傳的 dev pack 直接改名交付。


## validate-artifacts
- `node scripts/validate-artifacts.mjs`
- 專責檢查 `.updates/outbox/` 結構與 artifact 命名契約。
- 若發現 `.updates/outbox/dev|patch|release|handoff` 或任何 `market-observer_release_<version>.zip`，必須直接失敗。
