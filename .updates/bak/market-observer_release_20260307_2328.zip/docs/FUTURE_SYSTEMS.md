# FUTURE_SYSTEMS

## MO_GUARD
目標：把專案規則機械化，避免 AI 再犯流程錯誤。

至少涵蓋：
- release 檔名固定 `market-observer_release_latest.zip`
- handoff 只能在使用者輸入 `handoff` 時打包 `mo_handoff*.zip`
- `mo pack` 不得產生 handoff 檔名
- `.updates/outbox` 不得再出現 dev / patch / release / handoff 子目錄
- release 必檢文件同步：VERSION / CHANGELOG / RELEASE_NOTES / MO_START / docs / developer
- migrations 變更需提醒遠端 apply
- doctor / smoke / validate-artifacts 能攔截違規
- `docs/BUGS.md` 必須追蹤 bug

## MO_SANITY
目標：在 `mo pack` 或開發前先檢查 repo 健康度。

建議檢查：
- scripts 是否齊全
- docs 是否齊全
- worker 是否可編譯
- D1 schema 是否合理
- toolchain 是否完整

## MO_AUTOPILOT
目標：把 MO 升級成 AI 投資研究平台。

規劃方向：
- AI 自動研究 ETF 策略
- AI 自動回測
- AI 自動調整參數
- AI 自動評估與淘汰差策略

目前狀態：planned / not implemented
