## Current focus after 0.10.1
- Verify AI explanation commands work with `AI_ENABLED=1` and still reply safely when OpenAI is slow or unavailable.
- Keep trading logic isolated from AI; AI only explains existing structured outputs.

## Current focus after 0.10.0
- Verify that cost-aware guards do not block all valid TW ETF trades, while still filtering out low-notional / fee-inefficient orders.
- Observe next execution cycle to confirm cash, positions and pending→executed/skipped transitions include costs correctly.
- Next phase: extend cost-aware rules into full portfolio closed loop and realized/unrealized PnL visibility.

## Current focus after 0.9.1
- Verify that TW ETF candidates now convert into at least one recommendation/order when `signal=TRY` and candidates exist.
- If `recs` is still 0, use `debug` and `mo_strategy_debug` to inspect the new `px=<source>` lines before adjusting thresholds.

# NEXT TASK

## Current baseline
- Stable base: 0.9.0
- CLI / toolchain baseline remains stable after 0.8.5
- Universe is consumed by engine
- Strategy debug is available through LINE and D1
- Recommendation engine now includes conservative starter fallback

## Immediate next task
1. 觀察 0.9.0 在真實交易日是否開始產生 observation-style BUY/SELL 建議。
2. 若 fallback 太常出現，進一步調整 ranking / signal / budget gate，而不是永久依賴 fallback。
3. 讓 LINE `debug` 顯示更多 rejected reason 細節（例如 invalid_close / qty_zero / cut_by_rank）。
4. 將 D1 migrations apply 納入正式 release 驗證文件。

## 0.10.2
- Fix AI explain commands to hard-timeout quickly and fall back to original text so LINE webhook will still reply.

