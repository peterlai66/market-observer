# MO_START v2 — Market Observer AI Development Contract

## 0. 必讀順序
任何 AI 接手本專案時，必須先讀：
1. MO_START.md
2. docs/PROJECT.md
3. docs/AI_MEMORY.md
4. docs/NEXT_TASK.md
5. docs/BUGS.md
6. developer/SCRIPTS_GUIDE.md

在完成上述閱讀前，不可開始任何開發。

## 1. 核心原則
- 使用者只負責提需求、定框架、做線上驗收；不手動改程式。
- AI 負責實作、同步文件、產出 release / patch / handoff。
- 一般交付一律提供可透過 `mo update` 套用的 release zip。
- 只有使用者明確輸入 `handoff` 時，才進入交接流程並產出 handoff 包。
- 所有已定案流程與規格都要同步寫入文件，不可只留在聊天室。
- 每次 release 必須同步更新相關文件，不可只改程式不改文件。
- 所有新發現 bug 必須寫入 `docs/BUGS.md`。

## 2. Artifact Contract
- Release 正式交付檔名必須固定為 `market-observer_release_latest.zip`；任何版本號式 release 檔名都視為交付失敗。
- 每次產出 release 後都必須先通過 `mo validate-artifacts`，再視為可交付。
- 所有後續開發都必須建立在最近一次成功通過 `mo update`、`mo smoke`、`mo deploy` 的版本上。
- `scripts/`、`package.json`、`MO_START.md`、`docs/commands.md`、`developer/SCRIPTS_GUIDE.md` 視為 toolchain 必檢區。
- 已存在的正式 CLI 指令不可無故消失，尤其是：`mo doctor`、`mo smoke`、`mo smoke-worker`、`mo deploy`、`mo logs`、`mo update`、`mo pack`。
- 交付判定以使用者 update 後實際拿到的內容為準，不以聊天室描述為準。

## 3. Update / Deploy 分流
- `update`：把 release / patch 套用到 local repo。
- `deploy`：把 Worker 發佈到 Cloudflare。
- 若 release 包含 `src/`、`wrangler.jsonc`、`migrations/`、`worker-configuration.d.ts`，update 後必須 deploy。
- 若 release 包含 `migrations/` 變更，AI 必須明確提醒使用者執行 `npx wrangler d1 migrations apply ... --remote`。

## 4. 測試流程
### 工具鏈 / 文件修改
- `npm run mo -- smoke`
- `npm run mo -- update`

### Worker 程式修改
- `npm run mo -- smoke`
- `npm run mo -- smoke-worker`
- `npm run mo -- update`
- `npm run mo -- deploy`

## 5. outbox 結構契約
- 所有最新 zip 一律放在 `.updates/outbox/` 根目錄。
- 只靠檔名區分用途：`market-observer_dev_latest.zip`、`market-observer_patch_latest.zip`、`market-observer_release_latest.zip`、`mo_handoff_*.zip`。
- AI 交付 release 時，不可改用 `market-observer_release_<version>.zip` 之類名稱。
- `.updates/outbox/dev`、`.updates/outbox/patch`、`.updates/outbox/release`、`.updates/outbox/handoff` 都是廢棄結構，update / patch / sync-structure 必須自動刪除。
- `.updates/outbox/bak/` 保留作為舊 `_latest.zip` 的歸檔位置。

## 6. mo pack 與 handoff 契約
- `mo pack` 的用途是：使用者打包 local 最新 repo 給 AI，輸出應為 `market-observer_dev_latest.zip`。
- `mo pack` 不是 handoff，不得產出 `mo_handoff*.zip`。
- 只有使用者明確輸入 `handoff` 時，AI 才可以產出 handoff 包。
- handoff 流程：
  1. 使用者 local 執行 `npm run mo -- pack`
  2. 使用者上傳 `market-observer_dev_latest.zip`
  3. 使用者輸入 `handoff`
  4. AI 必須先比對 repo、文件、規則、已知 bug、未完成功能
  5. AI 補齊可補項，並列出未完成事項
  6. AI 產出新的 handoff 包：`mo_handoff_YYYYMMDD_HHMM.zip`
  7. 新視窗輸入：`讀取檔案中的 MO_START.md 並繼續開發專案`

## 7. D0~D19 的正式定義
- D0~D19 代表 20 個交易日的模擬週期。
- D0 = 模擬第 1 個交易日，D1 = 模擬第 2 個交易日，依此類推。
- 不要把 D0 / D1 理解成市場慣例的當日 / 次日術語。

## 8. 主循環
1. 取得最新可用交易日市場資料。
2. 生成該交易日盤後報告。
3. 根據盤後報告產生買進 / 賣出建議。
4. 下一個交易日用最高 / 最低價模擬是否成交。
5. 更新模擬持倉與績效，持續滾動。

## 9. 非交易日規則
- 週末 / 國定假日不生成新的盤後報告。
- 查詢盤後報告時，顯示最近交易日的報告。
- 若最近交易日摘要尚未生成，系統應補寫該交易日摘要，而不是直接回空。

## 10. Strategy Universe
- Universe 來源優先順序：`MO_UNIVERSE` → D1 `etf_universe(enabled=1)` → 預設 ETF universe `0050`、`006208`、`0056`、`00878`、`00919`。
- 推薦流程必須優先使用 universe，而且要從當日 `stocksAll` 全量快照建立候選；只有當日無快照時才可 fallback 到成交值排行。
- universe / fallback 狀態要同步寫入 log 與文件。

## 11. Runtime Trading Rules
- Recommendation 與 execution 必須拒絕無法覆蓋成本的交易。
- 最小交易數量 / 最小名目金額 / 交易成本檢查是策略層強制規則，不是 UI 提示。
- 任何未來 sizing 調整都必須保留 cost-aware guard，並同步更新 `docs/BUGS.md` / `CHANGELOG.md` / `RELEASE_NOTES.md`。

## 12. Debug 與驗證
- Strategy debug 必須寫入 `mo_strategy_debug`。
- 若 release 改動 LINE 或策略邏輯，release notes 必須包含 LINE 驗證指令、預期結果、必要的 D1 / log 驗證方式。
- 功能版至少要提供：`狀態`、`建議`、`debug`、`universe` 的驗證說明。

## 13. Bug Tracking
- 所有新發現 bug 必須寫入 `docs/BUGS.md`。
- 修 bug 時必須標註 bug ID 與 fixed version。

## 14. mo guard / mo sanity / mo autopilot
- `mo guard` 是高優先未來任務：負責攔截 release 命名、artifact 結構、文件同步、migration 提示、strategy cost guard、CLI 完整性等違規。
- `mo sanity` 是高優先未來任務：負責在 `mo pack` / 開發前檢查 repo 健康度、scripts/docs 是否齊全、worker 可編譯、D1 schema 合理性。
- `MO_AUTOPILOT` 是規劃中未來系統：目標是把 MO 升級成 AI 投資研究平台，包含策略研究、回測、優化與自動化評估，但目前尚未實作。

## 15. 當前基線與下一階段
- 已驗證基線：v0.10.0 / v0.10.1 前後的 0.9.x~0.10.x 系列，以最近一次成功通過 `mo update`、`mo smoke`、`mo deploy` 為準。
- 目前系統已能：選股、算分數、成本過濾、產生 PENDING、模擬成交判斷、寫入 debug / recommendation log。
- 下一階段重點：
  1. 成交閉環強化（PENDING → FILLED → 更新 `mo_positions` / `mo_portfolio_state`）
  2. LINE 狀態升級（今日 PENDING / FILLED / SKIPPED、持倉數、現金）
  3. 進場區間策略優化
  4. 實作 `mo guard`
  5. 建立 `mo sanity`
  6. 設計 `MO_AUTOPILOT` 架構
