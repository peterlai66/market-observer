# Release Notes

## 0.7.1
- restore LINE command: 監控 / watchlist
- help text adds watchlist entry
- 昨日報告優先讀取最新非空 summary，避免週末只看到（空）
