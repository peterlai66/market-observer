# .updates directory contract

Do not delete folders unless documentation explicitly says it is safe.

## folders
- `inbox/`：等待套用的 patch / release 包；接受 `market-observer_release*.zip` 與 `market-observer_patch*.zip`，不需要 rename。
- `work/`：patch / update 解壓工作區
- `bak/`：已套用的 patch / release 歷史
- `repo-backup/`：patch / update 前的備份快照
- `outbox/dev/`：local 開發快照（`mo pack`）
- `outbox/patch/`：本地 patch 輸出（固定入口檔名 `market-observer_patch_latest.zip`，舊檔自動進 `outbox/patch/bak/`）
- `outbox/release/`：本地 release 輸出（固定入口檔名 `market-observer_release_latest.zip`，舊檔自動進 `outbox/release/bak/`）
- `outbox/handoff/`：handoff 包輸出
- `outbox/bak/`：legacy root artifact archive
- `history/`：patch / update / handoff 執行紀錄

## note
- `backup/` 已 deprecated，不可再新增回來
- 修工具鏈時應優先走 `patch`
- `mo pack` 的預期輸出位置是 `.updates/outbox/dev/mo_local_latest.zip`
- `mo update` 會自動選取 `inbox/` 中最新的 `market-observer_release*.zip`
- `mo patch` 會自動選取 `inbox/` 中最新的 `market-observer_patch*.zip`
- `mo_handoff*.zip` 與 `mo_local*.zip` 只作為聊天 / 開發交接用途，本地 patch / update 會忽略
