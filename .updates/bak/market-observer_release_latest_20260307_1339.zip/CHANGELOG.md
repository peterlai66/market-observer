# Changelog

## 0.7.1
- Added LINE command aliases for 監控 / watchlist / 持倉 / 標的
- Added watchlist response using latest recommendation pool + current positions
- Yesterday report now falls back to latest non-empty summary text
