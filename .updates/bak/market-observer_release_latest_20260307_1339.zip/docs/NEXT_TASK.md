# NEXT TASK

1. 在使用者 local（Windows 11）實測 `npm run smoke:tools`，確認 Windows + PowerShell 解壓流程也通過。
2. 視需要把 `smoke:tools` 納入 `mo doctor` 後續延伸檢查，或拆成更細的 patch / update 單元測試。
3. 評估 handoff 包是否也要建立對應的本地驗證腳本或 manifest 規則。
4. 開始下一階段功能開發前，先確認 toolchain 版本已同步到 local 並完成一次 `mo pack` / `mo update` 驗證。
