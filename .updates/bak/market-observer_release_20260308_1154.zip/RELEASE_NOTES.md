# Release Notes

## 0.10.4
- 新增 `mo validate`：固定串 `guard -> sanity -> validate-artifacts`；若 outbox 尚未有 release，會以 skip 方式保留可先行巡檢。
- 新增 `mo preflight`：固定串 `doctor -> smoke -> validate`。
- 新增 `mo preflight-worker`：固定串 `doctor -> smoke -> smoke-worker -> validate`。
- `mo autopilot` / `mo autopilot-worker` 現在改為相容別名，內部轉呼叫 preflight，避免之後巡檢定義分叉。

## 驗證重點
1. `npm run mo -- validate` 應成功；若 outbox 已有 release，輸出需依序出現 `guard / sanity / validate-artifacts`，若尚未打 release 則 `validate-artifacts` 會顯示 skip。
2. `npm run mo -- preflight` 應成功，輸出需依序出現 `doctor / smoke / validate`。
3. `npm run mo -- preflight-worker` 應成功，輸出需依序出現 `doctor / smoke / smoke-worker / validate`。
4. `npm run mo -- autopilot` 與 `npm run mo -- autopilot-worker` 仍應成功，且行為與 preflight 同步。
5. `npm run mo -- release` 應仍成功，並維持產出 `.updates/outbox/market-observer_release_latest.zip`。

## 0.10.3
- 新增 `mo autopilot`：自動跑 `doctor -> smoke -> guard -> sanity`，適合每輪 release 驗證前先做一次工具鏈巡檢。
- 新增 `mo autopilot-worker`：自動跑 `doctor -> smoke -> smoke-worker -> guard -> sanity`，適合 Worker / wrangler / migrations 有變更時在 deploy 前做總巡檢。
- 同步更新 `MO_START.md`、`docs/commands.md`、`developer/SCRIPTS_GUIDE.md`、`docs/PROJECT.md`、`docs/AI_MEMORY.md`、`docs/NEXT_TASK.md`、`docs/BUGS.md`、`docs/FUTURE_SYSTEMS.md`。

## 驗證重點
1. `npm run mo -- autopilot` 應成功，輸出需依序出現 `doctor / smoke / guard / sanity`。
2. `npm run mo -- autopilot-worker` 應成功，輸出需依序出現 `doctor / smoke / smoke-worker / guard / sanity`。
3. `npm run mo -- release` 應仍成功，並維持產出 `.updates/outbox/market-observer_release_latest.zip`。

## 0.10.2
- 新增 `mo guard`：檢查關鍵文件、CLI 契約、release 命名規則、MO_START / docs 是否同步，專門攔截 AI 偏離流程的交付。
- 新增 `mo sanity`：檢查 `VERSION` / `package.json` / `CHANGELOG.md` / `RELEASE_NOTES.md` 是否同步，做為 release 前最後一道 sanity check。
- `pack:release` 現在會自動先跑 `sync-structure` → `doctor` → `guard` → `sanity`，打包後再跑 `validate-artifacts`。
- 正式開發循環文件化：release 驗證 / 討論後，下一輪必須先由使用者提供 `market-observer_dev_latest.zip`，AI 才能開發並交付 `market-observer_release_latest.zip`。

## 驗證重點
1. `npm run mo -- guard` 應成功。
2. `npm run mo -- sanity` 應成功。
3. `npm run mo -- release` 應成功，並只產生 `.updates/outbox/market-observer_release_latest.zip`。
4. 若人工放入版本號式 release 檔名或刪掉必要文件，`guard` / `sanity` / `validate-artifacts` 應失敗。

## 0.10.1
- 修正 MO 重複建單：同 `signal_date + symbol + side` 不再因重跑 `/admin/run` 一直新增 `PENDING`。
- `mo_recommendation_log.note` 新增 `inserted` / `deduped` 統計，驗證去重更直觀。
- `executePendingOrders()` 會把 `SKIPPED / EXECUTED` 寫入 `mo_execution_mark`，方便追蹤 pending 單後續處理結果。

## 驗證重點
1. 連跑兩次 `/admin/run?token=...&force=1`。
2. `mo_orders` 不應再出現同日重複新單。
3. `mo_recommendation_log.note` 應出現 `inserted=0|deduped=3` 類似字樣。
4. `mo_execution_mark` 應可看到 `filled=0/1` 的執行結果。