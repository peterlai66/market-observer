# Commands

## 推薦用法
- `npm run mo -- doctor`
- `npm run mo -- smoke`
- `npm run mo -- smoke-worker`
- `npm run mo -- logs`
- `npm run mo -- deploy`
- `npm run mo -- pack`
- `npm run mo -- patch`
- `npm run mo -- release`
- `npm run mo -- update`
- `npm run mo -- upgrade`（`update` 別名）

## 說明
- `doctor`：檢查 repo 結構與必要目錄
- `smoke`：在暫存 repo 驗證 sync-structure / doctor / pack / patch / release / update 流程
- `smoke-worker`：驗證 typecheck 與 Worker dry-run
- `logs`：追 Cloudflare Workers logs
- `deploy`：部署 Worker
- `pack`：把 local 最新專案打包成 `.updates/outbox/market-observer_dev_latest.zip`
- `patch`：吃 `.updates/inbox/market-observer_patch_latest.zip`，只更新工具鏈與文件
- `release`：產出 `.updates/outbox/market-observer_release_latest.zip`
- `update`：吃 `.updates/inbox/market-observer_release_latest.zip`，建立 backup、套用到 repo root、歸檔到 `.updates/bak/`
- `upgrade`：相容別名，行為同 `update`


## LINE
- `狀態` / `mo status`
- `昨日報告` / `report`
- `建議` / `推薦`
- `universe` / `標的池`


## PowerShell 驗證
- 查 universe：`npx wrangler d1 execute line_etf_monitor_v36 --remote --command "SELECT symbol, market, tier, enabled, created_at FROM etf_universe ORDER BY market, tier, symbol;"`
- 查最新建議：`npx wrangler d1 execute line_etf_monitor_v36 --remote --command "SELECT * FROM mo_orders ORDER BY id DESC LIMIT 10;"`
- 查 recommendation log：`npx wrangler d1 execute line_etf_monitor_v36 --remote --command "SELECT * FROM mo_recommendation_log ORDER BY id DESC LIMIT 10;"`
