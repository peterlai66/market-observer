# NEXT TASK

## Priority 1 — Recommendation Validation
1. 驗證 `mo_recommendation_log` 在既有 remote D1 上已成功補欄位並寫入。
2. `狀態` 補上最新 recommendation 來源（db / env / default）與候選數摘要。
3. 補一條 PowerShell 驗證腳本到文件，讓使用者能直接查 `mo_orders` / `mo_recommendation_log`。

## Priority 2 — Strategy / Orders
1. 以 ETF universe 為基礎，補上更明確的倉位規則（單檔上限、現金保留、分批進場）。
2. `mo_orders (PENDING)` 補上更完整的原因摘要：市場方向、alpha score、是否為 fallback。
3. 將 recommendation log 與 order execution 串起來，能追蹤 D0~D19 每日結果。

## Priority 3 — Simulation / Review
1. 補充模擬成交回顧查詢（例如最近 5 筆 EXECUTED / SKIPPED）。
2. 盤後推播增加「今天用了哪個 universe、是否 fallback」的摘要。
