## 2026-03-07 — 0.11.0
- User explicitly requires direct code delivery instead of architecture-only discussion.
- GPT integration must stay in explanation layer and use `gpt-4o-mini` by default.

## 2026-03-07 — 0.10.0
- User explicitly requires minimum trade size / cost-aware filtering so that fees and tax do not consume the trade's potential value.
- This rule is now treated as a hard runtime rule, not a later optimization.

# AI MEMORY

- 0.8.1 established the stable CLI/toolchain baseline.
- 0.8.3 connected D1 `etf_universe` to the strategy engine.
- 0.8.4 added `mo_strategy_debug` and LINE `debug / 除錯`.
- 0.8.5 added artifact validation to prevent release naming regressions.
- 0.9.0 adds snapshot backfill + starter fallback so candidate-rich days no longer stall at `recs=0` without visibility.

- 0.9.1 learned issue: universe candidates were valid but final recommendation close lookup failed; strategy now records explicit price-source fallback in debug output.
