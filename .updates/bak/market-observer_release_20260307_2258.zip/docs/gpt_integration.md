# GPT Integration

## Current status
Implemented in 0.11.0.

## Purpose
- GPT only explains MO outputs.
- GPT does not generate trade decisions.

## Model
- Default: `gpt-4o-mini`

## Worker vars
- `AI_ENABLED=0|1`
- `OPENAI_MODEL=gpt-4o-mini`

## Worker secret
- `OPENAI_API_KEY`
- set by: `npx wrangler secret put OPENAI_API_KEY`

## LINE commands
- `解釋狀態`
- `解釋報告`
- `解釋建議`

## Fallback
- If AI is not enabled, MO replies: `AI 解釋層目前未啟用`
- If OpenAI request fails, MO replies with a short temporary error message and keeps the original non-AI commands unaffected.
