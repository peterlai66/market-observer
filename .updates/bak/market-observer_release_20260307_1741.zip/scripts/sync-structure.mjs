#!/usr/bin/env node
import { mkdirSync, existsSync, writeFileSync } from 'node:fs';
import { join, resolve } from 'node:path';

const root = resolve('.');
const dirs = [
  '.updates/inbox',
  '.updates/outbox',
  '.updates/outbox/bak',
  '.updates/bak',
  '.updates/work',
  '.updates/history',
  '.updates/repo-backup',
  'docs/architecture',
  'developer',
];
for (const dir of dirs) {
  const p = join(root, dir);
  mkdirSync(p, { recursive: true });
  const keep = join(p, '.gitkeep');
  if (!existsSync(keep)) writeFileSync(keep, '');
}
const updatesReadme = join(root, '.updates', 'README.md');
writeFileSync(updatesReadme, `# .updates directory contract

- inbox/: incoming patch / release package waiting for mo patch / mo update
- work/: temporary extraction and staging area
- bak/: archive of consumed patch / release packages
- repo-backup/: repository snapshot before patch / update
- outbox/: generated zip artifacts (single output directory)
- outbox/bak/: archived latest artifacts rotated by filename
- history/: update history and operation records

## Artifact filenames
- mo_local_latest.zip: local dev pack uploaded to AI before handoff
- market-observer_patch_latest.zip: toolchain patch package
- market-observer_release_latest.zip: release package for mo update
- mo_handoff_YYYYMMDD_HHMM.zip: AI-generated handoff package
`);
console.log('Structure synced.');
