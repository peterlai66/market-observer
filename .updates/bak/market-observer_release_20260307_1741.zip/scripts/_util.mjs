import { spawnSync } from "node:child_process";
import { resolve } from "node:path";

export function bin(cmd) {
  if (process.platform === "win32") {
    if (cmd === "npm") return "npm.cmd";
    if (cmd === "npx") return "npx.cmd";
  }
  return cmd;
}

export function runSoft(cmd, args = [], opts = {}) {
  const b = bin(cmd);
  const res = spawnSync(b, args, { stdio: "inherit", shell: true, ...opts });
  return {
    status: res.status ?? (res.error ? 1 : 0),
    error: res.error,
  };
}

export function run(cmd, args = [], opts = {}) {
  const r = runSoft(cmd, args, opts);
  if (r.error) {
    throw r.error;
  }
  if (r.status !== 0) {
    throw new Error(`${cmd} failed with exit code ${r.status}`);
  }
}

export function runShell(commandLine) {
  if (process.platform === "win32") {
    return runSoft("powershell", ["-NoProfile", "-Command", commandLine], { shell: false });
  }
  return runSoft("sh", ["-lc", commandLine], { shell: false });
}

export function nowTag() {
  const d = new Date();
  const pad = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}_${pad(d.getHours())}${pad(d.getMinutes())}`;
}

export function safeGitSha() {
  try {
    const r = spawnSync("git", ["rev-parse", "--short", "HEAD"], { encoding: "utf8", shell: true });
    if (r.status === 0) return String(r.stdout).trim() || "nogit";
  } catch {}
  return "nogit";
}

export function openExplorer(targetPath) {
  const p = resolve(String(targetPath));
  if (process.platform !== "win32") return;

  const isZip = /\.zip$/i.test(p);
  const args = isZip ? ["/select,", p] : [p];

  const r = runSoft("explorer.exe", args, { shell: false });
  if (r.status !== 0) {
    console.log(`Explorer opened (exit=${r.status} ignored)`);
  }
}
