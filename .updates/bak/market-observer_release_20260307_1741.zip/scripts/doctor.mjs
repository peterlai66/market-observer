#!/usr/bin/env node
import { existsSync, mkdirSync } from 'node:fs';
import { resolve } from 'node:path';

const requiredFiles = [
  'MO_START.md',
  'package.json',
  'wrangler.jsonc',
  'tsconfig.json',
  'manifest.json',
  'VERSION',
  'RELEASE_NOTES.md',
  'src',
  'scripts',
  'docs/PROJECT.md',
  'docs/AI_MEMORY.md',
  'docs/NEXT_TASK.md',
  'developer/SCRIPTS_GUIDE.md',
  '.updates/README.md'
];
const requiredDirs = [
  '.updates/inbox',
  '.updates/outbox',
  '.updates/outbox/bak',
  '.updates/bak',
  '.updates/work',
  '.updates/history',
  '.updates/repo-backup'
];

let bad = 0;
for (const item of requiredFiles) {
  const ok = existsSync(resolve(item));
  console.log(`${ok ? '✅' : '❌'} ${item}`);
  if (!ok) bad++;
}
for (const dir of requiredDirs) {
  const p = resolve(dir);
  if (!existsSync(p)) mkdirSync(p, { recursive: true });
  const ok = existsSync(p);
  console.log(`${ok ? '✅' : '❌'} ${dir}`);
  if (!ok) bad++;
}
if (existsSync(resolve('.updates/backup'))) {
  console.log('⚠️  .updates/backup is deprecated and should be removed by update cleanup once no local dependency remains.');
}
for (const legacyDir of [
  '.updates/outbox/dev',
  '.updates/outbox/patch',
  '.updates/outbox/release',
  '.updates/outbox/handoff'
]) {
  if (existsSync(resolve(legacyDir))) {
    console.log(`⚠️  legacy directory still exists: ${legacyDir}`);
  }
}
if (bad) process.exit(1);
console.log('Doctor OK');
