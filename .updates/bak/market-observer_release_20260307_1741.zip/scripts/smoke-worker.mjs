#!/usr/bin/env node
import { run } from './_util.mjs';

try {
  console.log('[0] npm run typecheck');
  run('npm', ['run', 'typecheck']);

  console.log('[1] npx wrangler deploy --dry-run');
  run('npx', ['wrangler', 'deploy', '--dry-run']);

  console.log('[OK] Worker smoke passed');
} catch (error) {
  console.error(error instanceof Error ? error.message : error);
  process.exit(1);
}
