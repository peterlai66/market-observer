# PROJECT

## 專案定位
Market Observer (MO) 是以 Cloudflare Workers + D1 + TWSE OpenAPI + LINE 為核心的盤後市場觀察、建議與模擬交易系統。

## 使用者 / AI 分工
- 使用者：提需求、定框架、update / deploy、線上驗收。
- AI：實作、修 bug、同步文件、產出 release / patch / handoff。

## 主循環
1. 取得最新可用交易日市場資料。
2. 生成該交易日的盤後報告。
3. 根據盤後報告產生買進 / 賣出建議。
4. 下一個交易日用真實最高 / 最低價模擬是否成交。
5. 更新模擬持倉與績效，持續進入下一輪。

## D0~D19 定義
- D0~D19 表示 20 個交易日的模擬週期。
- D0 = 週期第 1 個交易日；D1 = 週期第 2 個交易日；依此類推。
- 不要把 D0 / D1 解讀成市場慣例的當日 / 次日術語。

## 非交易日規則
- 週末 / 國定假日不生成新的盤後報告。
- 盤後報告查詢應顯示最近交易日報告。
- 若最近交易日摘要尚未生成，系統應補寫該交易日摘要，而不是直接回空。

## 當前狀態
- 已正常：Worker、cron、LINE router、watchlist、latest_trade_date、toolchain update/release。
- 未完成：`twse_daily_summary` 自動生成、策略引擎、`mo_orders`、D0~D19 模擬成交與持倉更新。
