# HANDOFF NOTES

## 本次 handoff 已補齊
- 修正 `scripts/_util.mjs`：Windows 下 `spawnSync npm.cmd EINVAL` 由 `shell:true` 與統一 runner 解掉。
- 修正 `mo deploy` / `mo logs`：改走 `npx wrangler ...`，不再經過 `npm.cmd` wrapper。
- 統一 `pack / patch / release` 輸出位置為 `.updates/outbox/`，只靠檔名區分用途。
- 新增 `scripts/smoke-worker.mjs` 與 `npm run smoke:worker`。
- 同步文件：`MO_START.md`、`docs/PROJECT.md`、`docs/AI_MEMORY.md`、`docs/NEXT_TASK.md`、`developer/SCRIPTS_GUIDE.md`、`docs/update_process.md`、`docs/commands.md`。
- 把 `update / deploy` 分流、D0~D19 定義、非交易日規則、scripts 一致性規則寫入文件。

## 目前已知狀態
- local toolchain：`update` / `smoke:tools` 已可用。
- Worker：可 deploy、cron 有跑、watchlist 與 latest_trade_date 可查。
- 線上功能缺口：daily summary、strategy、orders、simulator 尚未完成。

## 仍未完成 / 待下一個 AI 接續
1. `twse_daily_summary` 自動生成：需要對齊 `latest_trade_date`，而不是直接以今天是否開盤判斷。
2. 預設 ETF universe 真正進入策略引擎，解決 `done 0/0`。
3. `mo_orders (PENDING)` 生成與 D0~D19 模擬成交。
4. 視需要再補一個 `mo fix` 指令，自動檢查 / 修復 scripts 工具鏈。

## 新視窗接續指令
請上傳本 handoff 包，並輸入：

`讀取檔案中的 MO_START.md 並繼續開發專案`
