## 0.7.6
- 修正 `scripts/_util.mjs`：統一 child process runner，Windows 下加入 `shell:true`，解掉 `spawnSync npm.cmd EINVAL`。
- 修正 `mo deploy` / `mo logs`：改成直接走 `npx wrangler ...`，避免 `npm.cmd` wrapper 相容性問題。
- 統一 `mo pack` / `mo patch` / `mo release` 輸出到 `.updates/outbox/`，不再使用 `outbox/dev`、`outbox/patch`、`outbox/release`、`outbox/handoff` 子目錄。
- 修正 `scripts/sync-structure.mjs`、`scripts/doctor.mjs`、`scripts/smoke-tools.mjs`，讓目錄契約、檢查項目、smoke 驗證一致。
- 同步更新 `MO_START.md`、`.updates/README.md`、`docs/update_process.md`、`docs/commands.md`、`docs/HANDOFF_NOTES.md`。

## 0.7.5-handoff
- 修正 `scripts/_util.mjs`：child process 啟動失敗不再被誤判成成功。
- 修正 `mo deploy`：保留 `npm run deploy` 路徑，但因 `_util.run()` 正確拋錯，Windows 下不再假成功。
- 新增 `npm run smoke:worker`，供 Worker 變更前做 typecheck 與 `wrangler deploy --dry-run` 驗證。
- 同步更新 handoff 文件，納入 update/deploy 分流、D0~D19 為 20 交易日模擬週期、目前未完成項與已知問題。
