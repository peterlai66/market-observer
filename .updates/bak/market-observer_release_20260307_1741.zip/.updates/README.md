# .updates directory contract

- inbox/: incoming patch / release package waiting for mo patch / mo update
- work/: temporary extraction and staging area
- bak/: archive of consumed patch / release packages
- repo-backup/: repository snapshot before patch / update
- outbox/: generated zip artifacts (single output directory)
- outbox/bak/: archived latest artifacts rotated by filename
- history/: update history and operation records

## Artifact filenames
- mo_local_latest.zip: local dev pack uploaded to AI before handoff
- market-observer_patch_latest.zip: toolchain patch package
- market-observer_release_latest.zip: release package for mo update
- mo_handoff_YYYYMMDD_HHMM.zip: AI-generated handoff package
