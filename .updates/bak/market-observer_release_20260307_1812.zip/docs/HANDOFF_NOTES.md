# HANDOFF NOTES

## 本次 handoff 已補齊
- 修正 `scripts/_util.mjs`：spawn 失敗時不再被誤判成成功。
- `mo deploy` 仍維持走 `npm run deploy`，但因 `_util.run()` 已正確拋錯，Windows 下不再假成功。
- 新增 `scripts/smoke-worker.mjs` 與 `npm run smoke:worker`。
- 同步文件：`MO_START.md`、`docs/PROJECT.md`、`docs/AI_MEMORY.md`、`docs/NEXT_TASK.md`、`developer/SCRIPTS_GUIDE.md`。
- 把 `update / deploy` 分流、D0~D19 定義、非交易日規則寫入文件。

## 目前已知狀態
- local toolchain：`update` / `smoke:tools` 已可用。
- Worker：可 deploy、cron 有跑、watchlist 與 latest_trade_date 可查。
- 線上功能缺口：daily summary、strategy、orders、simulator 尚未完成。

## 仍未完成 / 待下一個 AI 接續
1. `twse_daily_summary` 自動生成：需要對齊 `latest_trade_date`，而不是直接以今天是否開盤判斷。
2. 已完成：預設 ETF universe（目前為台股 ETF universe）已接入策略引擎，並新增 `mo_recommendation_log`。
3. 待驗證：`mo_orders (PENDING)`、模擬成交與 D0~D19 滾動流程在線上是否完全對齊。
4. 若要再修 `mo deploy` UX，可再補上「update 完若需 deploy 的明確提示」。

## 新視窗接續指令
請上傳本 handoff 包，並輸入：

`讀取檔案中的 MO_START.md 並繼續開發專案`
