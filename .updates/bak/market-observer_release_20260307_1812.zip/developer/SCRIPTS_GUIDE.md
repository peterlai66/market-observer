# SCRIPTS GUIDE

## Core commands
- `npm run mo -- doctor`
- `npm run mo -- pack`
- `npm run mo -- patch`
- `npm run mo -- release`
- `npm run mo -- update`
- `npm run mo -- deploy`
- `npm run smoke:tools`
- `npm run smoke:worker`

## When to run what
### 工具鏈 / 文件變更
1. `npm run smoke:tools`
2. `npm run mo -- update`

### Worker / src / wrangler / migrations 變更
1. `npm run smoke:tools`
2. `npm run smoke:worker`
3. `npm run mo -- update`
4. `npm run mo -- deploy`

## Important rule
- `update` 只更新 local repo。
- `deploy` 才會把 Worker 發佈到 Cloudflare。
- 若 release 包內含 `src/`、`wrangler.jsonc`、`migrations/`、`worker-configuration.d.ts`，update 後必須 deploy。

## pack family
- `pack:dev` → `.updates/outbox/dev/mo_local_latest.zip`
- `pack:patch` → `.updates/outbox/patch/market-observer_patch_latest.zip`
- `pack:release` → `.updates/outbox/release/market-observer_release_latest.zip`

## handoff rule
- `mo pack` 只產生 local 最新快照，不是 handoff 包。
- 聊天中輸入 `handoff` 時，AI 必須先比對 repo / 文件 / 規則 / 未修 bug，再產生新的 `mo_handoff_YYYYMMDD_HHMM.zip`。
- AI 不可把使用者上傳的 `mo_local_latest.zip` 直接改名交付。
