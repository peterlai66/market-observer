#!/usr/bin/env node
import { fmtPct, runQuery } from './_recommendation_review_lib.mjs';

const mode = (process.argv[2] || 'remote').trim().toLowerCase();
const remote = mode !== 'local';

console.log(`MO Recommendation Scoreboard (${remote ? 'remote' : 'local'})`);

const batchRows = runQuery(`
SELECT trade_date, review_universe, available_trade_dates, max_review_horizon, review_generated_at
FROM mo_recommendation_review_batches
ORDER BY review_generated_at DESC, trade_date DESC
` , remote);

const itemRows = runQuery(`
SELECT trade_date, symbol, order_status, d0_return, d5_return, d10_return, d20_return
FROM mo_recommendation_review_items
ORDER BY reviewed_at DESC, trade_date DESC, symbol ASC
`, remote);

const totalBatches = batchRows.length;
const totalSymbols = itemRows.length;
const filledOrders = itemRows.filter((r) => String(r.order_status || '').toUpperCase() === 'EXECUTED').length;
const skippedOrders = itemRows.filter((r) => String(r.order_status || '').toUpperCase() === 'SKIPPED').length;
const pendingOrders = itemRows.filter((r) => String(r.order_status || '').toUpperCase() === 'PENDING').length;
const skipRatio = totalSymbols > 0 ? (skippedOrders / totalSymbols) * 100 : 0;
const filledRatio = totalSymbols > 0 ? (filledOrders / totalSymbols) * 100 : 0;

console.log('');
console.log(`total_batches=${totalBatches}`);
console.log(`total_symbols=${totalSymbols}`);
console.log(`filled_orders=${filledOrders}`);
console.log(`skipped_orders=${skippedOrders}`);
console.log(`pending_orders=${pendingOrders}`);
console.log('');
console.log(`skip_ratio=${skipRatio.toFixed(2)}%`);
console.log(`filled_ratio=${filledRatio.toFixed(2)}%`);

if (totalBatches > 0) {
  const latest = batchRows[0];
  console.log('');
  console.log(`latest_batch=${latest.trade_date}`);
  console.log(`latest_universe=${latest.review_universe}`);
  console.log(`latest_horizon=D${latest.max_review_horizon}`);
  console.log(`latest_available_trade_dates=${latest.available_trade_dates}`);
}

const checkpoints = [
  { label: 'D0', key: 'd0_return' },
  { label: 'D5', key: 'd5_return' },
  { label: 'D10', key: 'd10_return' },
  { label: 'D20', key: 'd20_return' },
];

const statuses = ['EXECUTED', 'SKIPPED', 'PENDING'];
const normalizedItems = itemRows.map((row) => ({
  ...row,
  order_status: String(row?.order_status || '').trim().toUpperCase() || 'UNKNOWN',
}));

const avg = (values) => values.length ? values.reduce((sum, value) => sum + value, 0) / values.length : NaN;
const fmtMaybePct = (values) => values.length ? fmtPct(avg(values)) : '—';
const ratio = (num, den) => den > 0 ? `${((num / den) * 100).toFixed(2)}%` : '0.00%';
const windows = [1, 3, 5];
const latestTradeDates = [...new Set(batchRows.map((row) => String(row.trade_date || '')))].filter(Boolean);
const diagnosisRecords = [];

function buildStatusSummary(rows, key, totalEvaluable) {
  const values = rows.map((row) => Number(row?.[key])).filter((value) => Number.isFinite(value));
  const win = values.filter((value) => value > 0).length;
  const loss = values.filter((value) => value < 0).length;
  const flat = values.filter((value) => value === 0).length;
  const decisive = win + loss;
  return {
    evaluable: values.length,
    shareOfEvaluable: ratio(values.length, totalEvaluable),
    averageReturn: fmtMaybePct(values),
    positiveRate: ratio(win, values.length),
    winRate: ratio(win, values.length),
    lossRate: ratio(loss, values.length),
    flatRate: ratio(flat, values.length),
    expectancy: fmtMaybePct(values),
    decisiveRate: ratio(decisive, values.length),
  };
}


function buildDiagnosis(checkpointLabel, evaluableRows, key, totalEvaluable) {
  const values = evaluableRows.map((row) => Number(row?.[key])).filter((value) => Number.isFinite(value));
  const averageValue = values.length ? avg(values) : NaN;
  const positive = values.filter((value) => value > 0).length;
  const win = positive;
  const loss = values.filter((value) => value < 0).length;
  const flat = values.filter((value) => value === 0).length;
  const decisive = win + loss;
  const statusCounts = {
    executed: evaluableRows.filter((row) => row.order_status === 'EXECUTED').length,
    skipped: evaluableRows.filter((row) => row.order_status === 'SKIPPED').length,
    pending: evaluableRows.filter((row) => row.order_status === 'PENDING').length,
  };
  const dominantEntry = Object.entries(statusCounts).sort((a, b) => b[1] - a[1])[0] || ['none', 0];
  const [dominantStatus, dominantCount] = dominantEntry;
  const dominantShare = evaluableRows.length > 0 ? (dominantCount / evaluableRows.length) * 100 : 0;

  let gatePressure = 'LOW';
  if (statusCounts.skipped >= Math.max(1, evaluableRows.length * 0.6)) gatePressure = 'HIGH';
  else if (statusCounts.skipped >= Math.max(1, evaluableRows.length * 0.3)) gatePressure = 'MEDIUM';

  let edgeState = 'NO_DATA';
  if (values.length > 0) {
    if (decisive === 0) edgeState = 'FLAT_SAMPLE';
    else if (averageValue > 0 && positive >= loss) edgeState = 'POSITIVE_EDGE';
    else if (averageValue < 0 && loss > positive) edgeState = 'NEGATIVE_EDGE';
    else edgeState = 'MIXED_EDGE';
  }

  let horizonSignalStrength = 'NONE';
  if (values.length > 0) {
    const decisiveShare = decisive / values.length;
    if (decisiveShare === 0) horizonSignalStrength = 'INERT';
    else if (decisiveShare < 0.34) horizonSignalStrength = 'WEAK';
    else if (decisiveShare < 0.67) horizonSignalStrength = 'MODERATE';
    else horizonSignalStrength = 'STRONG';
  }

  const interpretationParts = [];
  if (gatePressure === 'HIGH') interpretationParts.push('execution-gate-dominant');
  else if (gatePressure === 'MEDIUM') interpretationParts.push('mixed-gate-influence');
  else interpretationParts.push('execution-gate-light');

  if (edgeState === 'FLAT_SAMPLE') interpretationParts.push('flat-sample');
  else if (edgeState === 'POSITIVE_EDGE') interpretationParts.push('positive-edge');
  else if (edgeState === 'NEGATIVE_EDGE') interpretationParts.push('negative-edge');
  else if (edgeState === 'MIXED_EDGE') interpretationParts.push('mixed-edge');
  else interpretationParts.push('no-data');

  interpretationParts.push(`${checkpointLabel.toLowerCase()}-${horizonSignalStrength.toLowerCase()}`);

  return {
    dominantStatus,
    dominantStatusShare: `${dominantShare.toFixed(2)}%`,
    gatePressure,
    edgeState,
    horizonSignalStrength,
    executionCoverageGap: ratio(totalEvaluable - statusCounts.executed, totalEvaluable),
    interpretation: interpretationParts.join('-'),
  };
}

console.log('');
console.log('checkpoint_outcomes:');
for (const checkpoint of checkpoints) {
  const evaluableRows = normalizedItems.filter((row) => Number.isFinite(Number(row?.[checkpoint.key])));
  const values = evaluableRows.map((row) => Number(row?.[checkpoint.key]));
  const evaluable = values.length;
  const coverage = totalSymbols > 0 ? (evaluable / totalSymbols) * 100 : 0;
  const positive = values.filter((value) => value > 0).length;
  const positiveRate = evaluable > 0 ? (positive / evaluable) * 100 : 0;
  const average = evaluable > 0 ? avg(values) : NaN;

  console.log(`${checkpoint.label}_evaluable=${evaluable}`);
  console.log(`${checkpoint.label}_coverage=${coverage.toFixed(2)}%`);
  console.log(`${checkpoint.label}_positive=${positive}`);
  console.log(`${checkpoint.label}_positive_rate=${positiveRate.toFixed(2)}%`);
  console.log(`${checkpoint.label}_average_return=${fmtPct(average)}`);
  console.log('');

  const winRows = evaluableRows.filter((row) => Number(row?.[checkpoint.key]) > 0);
  const lossRows = evaluableRows.filter((row) => Number(row?.[checkpoint.key]) < 0);
  const flatRows = evaluableRows.filter((row) => Number(row?.[checkpoint.key]) === 0);
  const win = winRows.length;
  const loss = lossRows.length;
  const flat = flatRows.length;
  const avgOfRows = (rows) => rows.length
    ? fmtPct(rows.reduce((sum, row) => sum + Number(row?.[checkpoint.key]), 0) / rows.length)
    : '—';

  console.log(`${checkpoint.label}_classification:`);
  console.log(`win=${win}`);
  console.log(`loss=${loss}`);
  console.log(`flat=${flat}`);
  console.log(`win_rate=${ratio(win, evaluable)}`);
  console.log(`loss_rate=${ratio(loss, evaluable)}`);
  console.log(`flat_rate=${ratio(flat, evaluable)}`);

  for (const status of statuses) {
    const rows = evaluableRows.filter((row) => row.order_status === status);
    const key = status.toLowerCase();
    console.log(`${key}_evaluable=${rows.length}`);
    console.log(`${key}_average_return=${avgOfRows(rows)}`);
  }
  console.log('');

  const decisive = win + loss;
  const avgWin = avg(winRows.map((row) => Number(row?.[checkpoint.key])));
  const avgLoss = avg(lossRows.map((row) => Number(row?.[checkpoint.key])));
  const edgeRatio = Number.isFinite(avgWin) && Number.isFinite(avgLoss) && avgLoss !== 0
    ? `${Math.abs(avgWin / avgLoss).toFixed(2)}x`
    : '—';

  console.log(`${checkpoint.label}_performance:`);
  console.log(`expectancy=${fmtPct(average)}`);
  console.log(`avg_win_return=${fmtPct(avgWin)}`);
  console.log(`avg_loss_return=${fmtPct(avgLoss)}`);
  console.log(`edge_ratio=${edgeRatio}`);
  console.log(`nonflat_evaluable=${decisive}`);
  console.log(`decisive_rate=${ratio(decisive, evaluable)}`);
  console.log('');

  console.log(`${checkpoint.label}_rolling:`);
  for (const window of windows) {
    const chosenDates = latestTradeDates.slice(0, window);
    const rows = evaluableRows.filter((row) => chosenDates.includes(String(row.trade_date || '')));
    const rowValues = rows.map((row) => Number(row?.[checkpoint.key])).filter((value) => Number.isFinite(value));
    const label = `last_${window}_batch`;
    console.log(`${label}_count=${Math.min(window, latestTradeDates.length)}`);
    console.log(`${label}_evaluable=${rows.length}`);
    console.log(`${label}_average_return=${fmtMaybePct(rowValues)}`);
    console.log(`${label}_positive_rate=${ratio(rowValues.filter((value) => value > 0).length, rowValues.length)}`);
  }
  console.log('');

  const statusGroups = {
    overall: evaluableRows,
    executed: evaluableRows.filter((row) => row.order_status === 'EXECUTED'),
    skipped: evaluableRows.filter((row) => row.order_status === 'SKIPPED'),
    pending: evaluableRows.filter((row) => row.order_status === 'PENDING'),
  };

  console.log(`${checkpoint.label}_execution_summary:`);
  for (const [name, rows] of Object.entries(statusGroups)) {
    const summary = buildStatusSummary(rows, checkpoint.key, evaluable);
    console.log(`${name}_evaluable=${summary.evaluable}`);
    console.log(`${name}_share_of_evaluable=${summary.shareOfEvaluable}`);
    console.log(`${name}_average_return=${summary.averageReturn}`);
    console.log(`${name}_positive_rate=${summary.positiveRate}`);
    console.log(`${name}_win_rate=${summary.winRate}`);
    console.log(`${name}_loss_rate=${summary.lossRate}`);
    console.log(`${name}_flat_rate=${summary.flatRate}`);
    console.log(`${name}_expectancy=${summary.expectancy}`);
    console.log(`${name}_decisive_rate=${summary.decisiveRate}`);
  }
  console.log('');

  const diagnosis = buildDiagnosis(checkpoint.label, evaluableRows, checkpoint.key, evaluable);
  console.log(`${checkpoint.label}_diagnosis:`);
  console.log(`dominant_status=${diagnosis.dominantStatus}`);
  console.log(`dominant_status_share=${diagnosis.dominantStatusShare}`);
  console.log(`gate_pressure=${diagnosis.gatePressure}`);
  console.log(`edge_state=${diagnosis.edgeState}`);
  console.log(`horizon_signal_strength=${diagnosis.horizonSignalStrength}`);
  console.log(`execution_coverage_gap=${diagnosis.executionCoverageGap}`);
  console.log(`interpretation=${diagnosis.interpretation}`);
  console.log('');

  diagnosisRecords.push({
    checkpoint: checkpoint.label,
    evaluable,
    executedEvaluable: statusGroups.executed.length,
    skippedEvaluable: statusGroups.skipped.length,
    pendingEvaluable: statusGroups.pending.length,
    positive,
    positiveRate,
    average,
    decisiveRate: evaluable > 0 ? (decisive / evaluable) * 100 : 0,
    diagnosis,
  });
}

function mostCommon(records, getter, fallback = '—') {
  const counts = new Map();
  for (const record of records) {
    const value = getter(record);
    counts.set(value, (counts.get(value) || 0) + 1);
  }
  const sorted = [...counts.entries()].sort((a, b) => b[1] - a[1] || String(a[0]).localeCompare(String(b[0])));
  return sorted[0]?.[0] ?? fallback;
}

function uniqueFindings(items) {
  return [...new Set(items.filter(Boolean))];
}

if (diagnosisRecords.length > 0) {
  const dominantStatusConsensus = mostCommon(diagnosisRecords, (record) => record.diagnosis.dominantStatus);
  const gatePressureConsensus = mostCommon(diagnosisRecords, (record) => record.diagnosis.gatePressure);
  const edgeStateConsensus = mostCommon(diagnosisRecords, (record) => record.diagnosis.edgeState);
  const horizonSignalConsensus = mostCommon(diagnosisRecords, (record) => record.diagnosis.horizonSignalStrength);

  const strongestSignalOrder = { STRONG: 4, MODERATE: 3, WEAK: 2, INERT: 1, NONE: 0 };
  const strongestSignalRecord = [...diagnosisRecords].sort((a, b) => {
    const scoreDiff = (strongestSignalOrder[b.diagnosis.horizonSignalStrength] ?? -1) - (strongestSignalOrder[a.diagnosis.horizonSignalStrength] ?? -1);
    if (scoreDiff !== 0) return scoreDiff;
    const decisiveDiff = b.decisiveRate - a.decisiveRate;
    if (decisiveDiff !== 0) return decisiveDiff;
    return a.checkpoint.localeCompare(b.checkpoint);
  })[0];

  const maxGapRecord = [...diagnosisRecords].sort((a, b) => {
    const aGap = Number.parseFloat(String(a.diagnosis.executionCoverageGap).replace('%', '')) || 0;
    const bGap = Number.parseFloat(String(b.diagnosis.executionCoverageGap).replace('%', '')) || 0;
    return bGap - aGap || a.checkpoint.localeCompare(b.checkpoint);
  })[0];

  const avgPositiveRate = diagnosisRecords.length
    ? diagnosisRecords.reduce((sum, record) => sum + record.positiveRate, 0) / diagnosisRecords.length
    : NaN;
  const avgExecutedShare = diagnosisRecords.length
    ? diagnosisRecords.reduce((sum, record) => sum + (record.evaluable > 0 ? (record.executedEvaluable / record.evaluable) * 100 : 0), 0) / diagnosisRecords.length
    : NaN;

  console.log('batch_level_summary:');
  console.log(`evaluated_checkpoints=${diagnosisRecords.length}`);
  console.log(`dominant_status_consensus=${dominantStatusConsensus}`);
  console.log(`gate_pressure_consensus=${gatePressureConsensus}`);
  console.log(`edge_state_consensus=${edgeStateConsensus}`);
  console.log(`horizon_signal_consensus=${horizonSignalConsensus}`);
  console.log(`strongest_horizon_checkpoint=${strongestSignalRecord?.checkpoint ?? '—'}`);
  console.log(`strongest_horizon_signal=${strongestSignalRecord?.diagnosis.horizonSignalStrength ?? '—'}`);
  console.log(`max_execution_coverage_gap=${maxGapRecord?.diagnosis.executionCoverageGap ?? '0.00%'}`);
  console.log(`max_execution_coverage_gap_checkpoint=${maxGapRecord?.checkpoint ?? '—'}`);
  console.log(`average_positive_rate=${Number.isFinite(avgPositiveRate) ? `${avgPositiveRate.toFixed(2)}%` : '—'}`);
  console.log(`average_executed_share=${Number.isFinite(avgExecutedShare) ? `${avgExecutedShare.toFixed(2)}%` : '—'}`);
  console.log('');

  const findings = uniqueFindings([
    diagnosisRecords.every((record) => record.diagnosis.dominantStatus === 'skipped') ? 'skipped-dominates-all-checkpoints' : '',
    diagnosisRecords.every((record) => record.executedEvaluable === 0) ? 'no-executed-samples-observed' : '',
    diagnosisRecords.every((record) => record.diagnosis.gatePressure === 'HIGH') ? 'execution-gate-pressure-high-across-checkpoints' : '',
    diagnosisRecords.every((record) => record.diagnosis.edgeState === 'FLAT_SAMPLE') ? 'all-checkpoints-flat-sample' : '',
    diagnosisRecords.every((record) => record.diagnosis.horizonSignalStrength === 'INERT') ? 'horizon-signal-inert-across-checkpoints' : '',
    diagnosisRecords.some((record) => (Number.parseFloat(String(record.diagnosis.executionCoverageGap).replace('%', '')) || 0) >= 50) ? 'execution-coverage-gap-material' : '',
    strongestSignalRecord ? `strongest-horizon-${strongestSignalRecord.checkpoint.toLowerCase()}-${String(strongestSignalRecord.diagnosis.horizonSignalStrength || '').toLowerCase()}` : '',
  ]);

  console.log('top_findings:');
  findings.forEach((finding, index) => {
    console.log(`${index + 1}=${finding}`);
  });
  if (findings.length === 0) console.log('1=no-material-findings');
  console.log('');
}

console.log('Recommendation scoreboard OK');
