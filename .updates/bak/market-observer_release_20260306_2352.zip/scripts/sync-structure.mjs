#!/usr/bin/env node
import { mkdirSync, existsSync, writeFileSync } from 'node:fs';
import { join, resolve } from 'node:path';

const root = resolve('.');
const dirs = [
  '.updates/inbox',
  '.updates/outbox',
  '.updates/outbox/bak',
  '.updates/outbox/release',
  '.updates/outbox/release/bak',
  '.updates/bak',
  '.updates/work',
  '.updates/history',
  '.updates/repo-backup',
  'docs/architecture',
  'developer',
];
for (const dir of dirs) {
  const p = join(root, dir);
  mkdirSync(p, { recursive: true });
  const keep = join(p, '.gitkeep');
  if (!existsSync(keep)) writeFileSync(keep, '');
}
const updatesReadme = join(root, '.updates', 'README.md');
if (!existsSync(updatesReadme)) {
  writeFileSync(updatesReadme, `# .updates directory contract\n\n- inbox/: incoming release package waiting for mo update\n- work/: temporary extraction and staging area\n- bak/: archive of consumed release packages\n- repo-backup/: repository snapshot before update\n- outbox/: generated artifacts\n- history/: update history and operation records\n`);
}
console.log('Structure synced.');
