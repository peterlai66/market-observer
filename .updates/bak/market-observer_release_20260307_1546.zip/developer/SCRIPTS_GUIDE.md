# SCRIPTS GUIDE

## core commands
- `npm run mo -- doctor`
- `npm run mo -- pack`
- `npm run mo -- patch`
- `npm run mo -- release`
- `npm run mo -- update`
- `npm run smoke:tools`

## pack family
- `pack:dev` → `.updates/outbox/dev/mo_local_latest.zip`
- `pack:patch` → `.updates/outbox/patch/market-observer_patch_latest.zip`
- `pack:release` → `.updates/outbox/release/market-observer_release_latest.zip`

## handoff rule
- `mo pack` 只產生 local 最新快照，不是 handoff 包。
- 聊天中輸入 `handoff` 時，AI 必須先比對 repo / 文件 / 規則 / 未修 bug，再產生新的 `mo_handoff_latest.zip`。
- AI 不可把使用者上傳的 `mo_local_latest.zip` 直接改名交付。

## patch / update responsibilities
### patch
用途：修工具鏈與文件。

只更新：
- `scripts/`
- `docs/`
- `developer/`
- `MO_START.md`
- `VERSION`
- `RELEASE_NOTES.md`
- `.updates/README.md`
- 必要時 `package.json`

### update
用途：完整專案更新。

更新 release 包內所有正式項目，並套用到 repo root。

## update pipeline contract
1. validate inbox package exists
2. create backup zip
3. verify backup non-empty
4. clear and extract package to `.updates/work/`
5. verify work non-empty
6. copy staged files to repo root
7. archive used package to `.updates/bak/`
8. write history json
9. cleanup deprecated directories if defined

## failure rule
- 任何步驟失敗都必須中止
- 失敗時 `inbox` 內原始 zip 必須保留
- 不可出現只印成功但 backup 為空的假成功

## smoke:tools
- 建立暫存 repo 並跑 `sync-structure`、`doctor`、`pack-dev`、`pack-patch`、`apply-patch`、`pack-release`、`apply-update`。
- 會驗證 `.updates/backup` 在 patch / update 後確實被清理。
- 用途：工具鏈交付前的端到端 smoke test。


- smoke-worker：部署前驗證 Worker / Wrangler / D1 migration。
