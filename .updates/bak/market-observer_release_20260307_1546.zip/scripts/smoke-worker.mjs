#!/usr/bin/env node
import { run } from './_util.mjs';

console.log('[0] wrangler version');
run('npx', ['wrangler', '--version']);

console.log('[1] typecheck');
run('npm', ['run', 'typecheck']);

console.log('[2] wrangler deploy --dry-run');
run('npx', ['wrangler', 'deploy', '--dry-run']);

console.log('[3] wrangler d1 migrations list');
run('npx', ['wrangler', 'd1', 'migrations', 'list', 'line_etf_monitor_v36']);

console.log('[OK] Worker smoke passed');
