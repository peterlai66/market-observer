#!/usr/bin/env node
import { mkdirSync, existsSync, writeFileSync } from 'node:fs';
import { join, resolve } from 'node:path';

const root = resolve('.');
const dirs = [
  '.updates/inbox',
  '.updates/outbox',
  '.updates/outbox/bak',
  '.updates/outbox/dev',
  '.updates/outbox/dev/bak',
  '.updates/outbox/patch',
  '.updates/outbox/patch/bak',
  '.updates/outbox/release',
  '.updates/outbox/release/bak',
  '.updates/outbox/handoff',
  '.updates/outbox/handoff/bak',
  '.updates/bak',
  '.updates/work',
  '.updates/history',
  '.updates/repo-backup',
  'docs/architecture',
  'developer',
];
for (const dir of dirs) {
  const p = join(root, dir);
  mkdirSync(p, { recursive: true });
  const keep = join(p, '.gitkeep');
  if (!existsSync(keep)) writeFileSync(keep, '');
}
const updatesReadme = join(root, '.updates', 'README.md');
if (!existsSync(updatesReadme)) {
  writeFileSync(updatesReadme, `# .updates directory contract

- inbox/: incoming patch / release package waiting for mo patch / mo update
- work/: temporary extraction and staging area
- bak/: archive of consumed patch / release packages
- repo-backup/: repository snapshot before patch / update
- outbox/dev/: local development packs
- outbox/patch/: generated patch artifacts
- outbox/release/: generated release artifacts
- outbox/handoff/: generated handoff artifacts
- outbox/bak/: legacy root artifact archive
- history/: update history and operation records
`);
}
console.log('Structure synced.');
