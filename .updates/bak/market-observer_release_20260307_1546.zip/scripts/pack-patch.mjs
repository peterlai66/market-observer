#!/usr/bin/env node
import { join, resolve } from 'node:path';
import { createZip, rotateLatest } from './_pack_common.mjs';

const root = resolve('.');
const outDir = join(root, '.updates', 'outbox', 'patch');
const latestName = 'market-observer_patch_latest.zip';
const zipPath = join(outDir, latestName);
const items = [
  'MO_START.md',
  'package.json',
  'VERSION',
  'RELEASE_NOTES.md',
  'scripts',
  'docs',
  'developer',
  '.updates/README.md'
];

rotateLatest(outDir, latestName);
await createZip(root, zipPath, items);
console.log(`Packed => ${zipPath}`);
