#!/usr/bin/env node
import { readFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { run } from './_util.mjs';

const __dirname = dirname(fileURLToPath(import.meta.url));
const root = resolve(__dirname, '..');
const pkg = JSON.parse(readFileSync(resolve(root, 'package.json'), 'utf-8'));

function help() {
  console.log(`Market Observer CLI (mo) v${pkg.version}`);
  console.log('');
  console.log('Usage:');
  console.log('  mo doctor');
  console.log('  mo logs');
  console.log('  mo deploy');
  console.log('  mo pack');
  console.log('  mo release');
  console.log('  mo pack-patch');
  console.log('  mo patch');
  console.log('  mo update');
  console.log('  mo upgrade   # alias of mo update');
  console.log('  mo smoke-worker');
  console.log('');
  console.log('Recommended local usage:');
  console.log('  npm run mo -- doctor');
  console.log('  npm run mo -- pack');
  console.log('  npm run mo -- release');
  console.log('  npm run mo -- pack-patch');
  console.log('  npm run mo -- patch');
  console.log('  npm run mo -- update');
  console.log('  npm run mo -- smoke-worker');
  console.log('');
  console.log('Notes:');
  console.log('  - mo pack = 打包目前 local 最新檔案給 AI 使用。');
  console.log('  - mo patch = 修工具鏈（scripts/docs/developer/MO_START）。');
  console.log('  - handoff 是聊天指令，不是本地 CLI 指令。');
  console.log('  - mo release = 產生正式 release 包。');
}

const cmd = (process.argv[2] || '').trim();
if (!cmd || ['-h', '--help', 'help'].includes(cmd)) {
  help();
  process.exit(0);
}

switch (cmd) {
  case 'doctor':
    run('node', ['scripts/doctor.mjs']);
    break;
  case 'deploy':
    run('npx', ['wrangler', 'deploy']);
    break;
  case 'pack':
  case 'pack-dev':
    run('node', ['scripts/pack-dev.mjs']);
    break;
  case 'patch':
  case 'toolchain':
    run('node', ['scripts/apply-patch.mjs']);
    break;
  case 'pack-patch':
    run('node', ['scripts/pack-patch.mjs']);
    break;
  case 'release':
  case 'pack-release':
    run('node', ['scripts/pack-release.mjs']);
    break;
  case 'update':
  case 'upgrade':
    run('node', ['scripts/apply-update.mjs']);
    break;
  case 'smoke-worker':
    run('node', ['scripts/smoke-worker.mjs']);
    break;
  case 'logs':
    run('npx', ['wrangler', 'tail', '--format', 'pretty']);
    break;
  default:
    help();
    process.exit(1);
}
