import type { Env } from '../index';
import { buildAiSystemPrompt, buildAiUserPrompt, type AiExplainKind } from './prompt';

const OPENAI_RESPONSES_URL = 'https://api.openai.com/v1/responses';

function pickModel(env: Env): string {
	const raw = String(env.OPENAI_MODEL ?? '').trim();
	return raw || 'gpt-5-mini';
}

function extractOutputText(data: any): string {
	if (typeof data?.output_text === 'string' && data.output_text.trim()) return data.output_text.trim();
	const output = Array.isArray(data?.output) ? data.output : [];
	const texts: string[] = [];
	for (const item of output) {
		const content = Array.isArray(item?.content) ? item.content : [];
		for (const part of content) {
			if (typeof part?.text === 'string' && part.text.trim()) texts.push(part.text.trim());
			if (typeof part?.output_text === 'string' && part.output_text.trim()) texts.push(part.output_text.trim());
		}
	}
	return texts.join('\n').trim();
}

export async function generateAiExplanation(
	env: Env,
	kind: AiExplainKind,
	payload: Record<string, unknown>,
): Promise<string> {
	if (!env.OPENAI_API_KEY) throw new Error('OPENAI_API_KEY not set');

	const timeoutMs = 8000;
	const ac = new AbortController();
	const timer = setTimeout(() => ac.abort(`timeout ${timeoutMs}ms`), timeoutMs);

	try {
		const res = await fetch(OPENAI_RESPONSES_URL, {
			method: 'POST',
			headers: {
				'content-type': 'application/json',
				authorization: `Bearer ${env.OPENAI_API_KEY}`,
			},
			body: JSON.stringify({
				model: pickModel(env),
				input: [
					{
						role: 'system',
						content: [{ type: 'input_text', text: buildAiSystemPrompt() }],
					},
					{
						role: 'user',
						content: [{ type: 'input_text', text: buildAiUserPrompt(kind, payload) }],
					},
				],
				text: {
					format: { type: 'text' },
				},
			}),
			signal: ac.signal,
		});

		if (!res.ok) {
			const body = await res.text();
			throw new Error(`OpenAI responses failed: ${res.status} ${body.slice(0, 240)}`);
		}

		const data = (await res.json()) as any;
		const text = extractOutputText(data);
		if (!text) throw new Error('OpenAI responses returned empty text');
		return text;
	} catch (e: any) {
		const isAbort = String(e?.name || '') === 'AbortError' || String(e?.message || '').includes('timeout');
		if (isAbort) throw new Error(`OpenAI responses timeout after ${timeoutMs}ms`);
		throw e;
	} finally {
		clearTimeout(timer);
	}
}
