# AI MEMORY

- 使用者角色：只負責提需求、定框架、做線上驗收；不手動改程式。
- AI 角色：直接實作、更新文件、打包交付；除 1~2 行指令外，不在聊天室貼大量程式碼。
- `update` = 更新 local repo；`deploy` = 發布 Worker 到 Cloudflare。Worker 程式變更後，update 完仍需 deploy。
- `smoke` 用於驗證 patch / update / release 工具鏈與 outbox migration cleanup。
- `smoke-worker` 用於驗證 Worker typecheck 與 deploy dry-run。
- D0~D19 是 20 個交易日的模擬週期命名，不是金融術語的當日 / 次日簡寫。
- CLI 基礎穩定優先於新功能擴張；若 toolchain 不穩，先修 CLI 再做 MO 本體。
- 所有新 bug 必須記錄到 `docs/BUGS.md`，並在相關 release 文件同步。
