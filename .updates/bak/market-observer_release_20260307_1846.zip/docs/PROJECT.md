# PROJECT

## 專案定位
Market Observer (MO) 是以 Cloudflare Workers + D1 + TWSE OpenAPI + LINE 為核心的盤後市場觀察、建議與模擬交易系統。

## 使用者 / AI 分工
- 使用者：提需求、定框架、update / deploy、線上驗收。
- AI：實作、修 bug、同步文件、產出 release / patch / handoff。

## 目前階段
- Phase 1：基礎 Worker / cron / D1 架構已完成。
- Phase 2：市場資料抓取與儲存已完成。
- Phase 3：returns / volatility / sharpe / trend / scoring 等策略元件已具備。
- 當前優先：CLI / toolchain 基礎整備與回歸防護。

## 主循環
1. 取得最新可用交易日市場資料。
2. 生成該交易日的盤後報告。
3. 根據盤後報告產生買進 / 賣出建議。
4. 下一個交易日用真實最高 / 最低價模擬是否成交。
5. 更新模擬持倉與績效，持續進入下一輪。

## D0~D19 定義
- D0~D19 表示 20 個交易日的模擬週期。
- D0 = 週期第 1 個交易日；D1 = 週期第 2 個交易日；依此類推。
- 不要把 D0 / D1 解讀成市場慣例的當日 / 次日術語。

## 非交易日規則
- 週末 / 國定假日不生成新的盤後報告。
- 盤後報告查詢應顯示最近交易日報告。
- 若最近交易日摘要尚未生成，系統應補寫該交易日摘要，而不是直接回空。

## Toolchain Contract
- 正式 CLI 指令：`doctor`、`smoke`、`smoke-worker`、`logs`、`deploy`、`pack`、`pack-patch`、`patch`、`release`、`update`。
- `.updates/outbox/` 為唯一 artifact 根目錄。
- 舊子目錄 `outbox/dev`、`outbox/patch`、`outbox/release`、`outbox/handoff` 為 deprecated，必須由 migration 自動刪除。
