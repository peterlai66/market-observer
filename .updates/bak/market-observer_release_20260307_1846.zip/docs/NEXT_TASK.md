# NEXT TASK

## Priority 1 — CLI Foundation 完整收斂
1. 確保 `mo doctor`、`mo smoke`、`mo smoke-worker`、`mo deploy`、`mo logs`、`mo pack`、`mo patch`、`mo release`、`mo update` 維持穩定存在。
2. 將 release / patch / dev artifacts 統一到 `.updates/outbox/` 根目錄，避免舊子目錄回退。
3. `sync-structure`、`doctor`、`patch`、`update`、`smoke` 全部以單一 outbox 契約為準。
4. `docs/BUGS.md` 納入固定流程，避免重複回歸錯誤。

## Priority 2 — Daily Summary Engine
1. 補上 `twse_daily_summary` 生成流程：以 `latest_trade_date` 為準，而不是以「今天是否開盤」直接決定是否跳過。
2. 非交易日（週末 / 國定假日）應顯示最近交易日的盤後報告；若摘要不存在，需自動補生成最近交易日摘要。
3. 盤後報告生成後，才允許進入建議產生流程。

## Priority 3 — Strategy / Orders
1. 讓預設 ETF universe 真正進入策略引擎，不再只有 `watchlist` 顯示，tick 卻仍是 `done 0/0`。
2. 寫入 `mo_orders (PENDING)`，作為下一個模擬交易日的建議基礎。
3. 建議需包含：標的、方向、價格區間、金額 / 數量建議、原因摘要。
