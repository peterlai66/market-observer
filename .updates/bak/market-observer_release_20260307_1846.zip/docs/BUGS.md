# BUG TRACKER

## Open Bugs

### BUG-20260307-01
- Title: Deprecated outbox subdirectories not fully removed from local repo
- Status: Open
- Description: `.updates/outbox/dev`, `.updates/outbox/release`, `.updates/outbox/handoff`, `.updates/outbox/patch` were deprecated, but local repo cleanup did not reliably remove them after update / smoke.
- Expected: update / patch / sync-structure must remove deprecated directories from the actual local repo, not only from smoke temp repo.
- Regression guard: doctor and smoke must verify the new single-root outbox contract.

## Fixed Bugs
- None yet.

## Regression Guards
- All newly discovered bugs must be recorded here.
- Bug fixes must update status and mention the bug ID in CHANGELOG / RELEASE_NOTES when relevant.
- Release validation is based on the real package after `mo update`, not on chat claims.
