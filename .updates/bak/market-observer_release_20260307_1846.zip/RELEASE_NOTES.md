# Market Observer Release Notes

## 0.8.1
- 補齊並固定正式 CLI：`mo doctor`、`mo smoke`、`mo smoke-worker`、`mo logs`、`mo deploy`、`mo pack`、`mo patch`、`mo release`、`mo update`。
- `mo deploy` / `mo logs` 改為直接走 `npx wrangler ...`，避免 Windows `npm.cmd` 路徑不穩定。
- dev / patch / release 最新 zip 一律輸出到 `.updates/outbox/` 根目錄，用檔名區分用途。
- `sync-structure`、`patch`、`update` 會自動清理 `.updates/backup` 與廢棄的 outbox 子目錄。
- 新增 `docs/BUGS.md`，先登記 BUG-20260307-01，之後 bug 修正需同步追蹤。
- 同步更新 `MO_START.md`、`docs/commands.md`、`docs/update_process.md`、`docs/PROJECT.md`、`docs/AI_MEMORY.md`、`docs/NEXT_TASK.md`、`developer/SCRIPTS_GUIDE.md`、`.updates/README.md`。
