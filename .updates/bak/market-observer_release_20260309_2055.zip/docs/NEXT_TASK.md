## 0.14.7 next target
- P1 TW price backfill repair: backfill missing `00757.TW` / `00919.TW` history into `prices_daily` and extend `00878.TW` beyond 2026-03-02.
- Add a dedicated CLI diagnostic to print `prices_daily` coverage gaps by symbol/date before weekly simulation runs.
- Keep review items canonical-only (`.TW`) and add one-shot cleanup for historical bare-symbol duplicates still remaining in remote D1.

## 0.14.4
- Daily cycle engine foundation is in place.
- `src/index.ts` now tracks `mo_cycle_state`, extends retry window to next-day open, and allows recommendation/simulation bootstrap before report push finishes.
- LINE now supports `ai 狀態` / `ai 報告` / `ai 建議` for GPT explanation.
- Verify with `npm run mo -- doctor`, `npm run typecheck`, deploy, then LINE `狀態`, `建議`, `ai 狀態`.

Next target: 0.14.5 cycle scoreboard + actionable / report_only tracking in CLI status and review outputs.

## 0.14.2
- Added weekly operator message layer for report payload shaping and publish-ready messaging.

## 0.13.9
- Operator final decision summary
- `mo recommendation-scoreboard` now prints `operator_final_decision_summary`, `operator_final_decision_findings`, and `operator_final_decision_actions`.
- Verify with `npm run mo -- doctor` then `npm run mo -- recommendation-scoreboard`.

Next target: 0.14.0 operator execution checklist
## 0.13.7
- Full Pipeline Readiness Summary
- `mo recommendation-scoreboard` now prints `pipeline_readiness_summary`, `pipeline_readiness_findings`, and `pipeline_readiness_actions`.
- Verify with `npm run mo -- doctor` then `npm run mo -- recommendation-scoreboard`.

Next target: 0.13.7 execution validation unlock checks


- 0.14.2: added weekly_delivery_formatting_summary / weekly_delivery_formatting_blocks / weekly_delivery_formatting_actions for LINE/email/log payload shaping.
