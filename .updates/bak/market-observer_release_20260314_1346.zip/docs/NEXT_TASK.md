## 0.19.2 next
- Add remote verification flow for report gate after deploy, including explicit `/admin/run?force=1` success markers and expected log signatures.
- Add a targeted refresh path so recommendation review snapshots for the latest trade date can be regenerated automatically instead of relying only on older saved batches.
- Ensure LINE `最新報告` / AI report payload use the same live review-progress source to avoid display drift.
- Add regression checks for weekend / non-trading-day report validation and stale review-snapshot fallback.
