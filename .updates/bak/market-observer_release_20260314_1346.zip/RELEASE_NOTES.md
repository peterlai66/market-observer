## 0.19.1
- 修正 REPORT_GATE：當 `tradeDate` 已是最新已完成交易日，且 summary / snapshot / index 已對齊時，`reportStatus` 應為 `VALID`，不再誤報 `SOURCE_DELAY`。
- 修正 `最新報告` 標頭日期：現在會以最新市場資料日顯示，並補上 `資料截至 YYYY-MM-DD`。
- 修正 review horizon 顯示：若舊 review snapshot 尚未刷新，operator report 會先依最新市場資料即時推進 D0 / D5 / D10 / D20 horizon，不再卡在舊批次。

驗證重點
1. `npm run mo -- doctor`
2. `type VERSION`，應為 `0.19.1`
3. deploy 後執行 `/admin/run?force=1`
4. 預期 admin 回傳 `reportStatus=VALID`，且不再出現 `reason=latest_trade_date=...`
5. LINE `最新報告` 第一行與 `資料截至` 應對齊到最新已完成交易日；若舊 review snapshot 未更新，驗證進度區塊應顯示已依最新市場資料推進。

## 0.19.0
- Added REPORT_GATE / PUSH_GATE / RECOMMENDATION_GATE so incomplete reports no longer push LINE or emit actionable recommendations.
- Removed the fixed one-line market commentary from the generated summary.
- `/admin/run` now reports `reportStatus`, `recStatus`, and `execDate` based on final gate outcomes.

## 0.18.0

- FinMind trade-date backstop 改為使用 `TaiwanStockTradingDate`，不再用免費等級會 400 的 `TaiwanStockPrice` 全市場查詢。
- TWSE legacy probe 改為優先探測 `anchor+1, anchor, anchor-1, anchor-2`，補上最重要的次一交易日（例如 3/10），不再直接先查 today。
- 若 legacy / FinMind 候選日期超過 anchor + 1 天，會直接忽略，不再讓單一來源把 tradeDate 拉到 +2 天造成 ABORT。

## 0.17.9

- 新增 FinMind trade-date backstop（需先設定 FINMIND_TOKEN）。
- TWSE legacy probe 改成含 today / today-1 / anchor，讓 3/11 凌晨可補抓 3/10。
- 修正 最新報告 日期選擇，避免舊 review batch 壓過最新 cycle。

## 0.17.8
- 修正 TWSE legacy MI_INDEX 補查不再直接從今天往回亂探；改為以主來源最新日期為 anchor，只允許接受最多 +1 天的補強結果。
- `/admin/run?force=1` log 會額外顯示 legacy probe anchor / probes / delta，方便判讀為何採用或忽略舊版查詢結果。

驗證重點
1. deploy 後執行 `/admin/run?force=1`，應看到 `legacy probe anchor=`。
2. 若 OpenAPI/FMTQIK/STOCK_DAY_ALL 共識為 2026-03-09，legacy 不應再直接跳到 2026-03-11。
3. 若 legacy 取得 2026-03-10，log 應顯示 `tradeDate advanced by legacy backstop`。

## 0.17.7
- TWSE trade-date resolver now reads the latest date span from FMTQIK and STOCK_DAY_ALL, and also probes legacy MI_INDEX date-query endpoints when OpenAPI freshness lags.
- `mo pack` / `mo release` / `mo pack-patch` now auto-include root repo files, so newly added files such as baseline/config/docs are less likely to be missed from artifacts.
- Verify after deploy with `/admin/run?force=1` and confirm logs show `FMTQIK date span first=... last=...` plus `candidate tradeDate=... via MI_INDEX_LEGACY(...)` when needed.

## 0.17.6

- 預設 AI 模型固定為 `gpt-4o-mini`，避免未設定時落到 `gpt-5-mini`。
- `wrangler.jsonc` 新增 `AI_ENABLED=1`、`OPENAI_MODEL=gpt-4o-mini` 預設 vars。
- 新增 `mo_ai_audit`：會記錄最近一次 AI 呼叫的 kind / model / enabled / ok / status_code / duration_ms / response_chars / error / request_id。
- Cloudflare log 現在可看到 `[AI] call start`、`[AI] call ok`、`[AI] call fail`，方便確認 GPT API 是否真的有被調用且有無回應。

### 驗證
1. `npm run mo -- doctor`
2. `npm run mo -- guard`
3. `npm run mo -- sanity`
4. deploy 後在 LINE 輸入 `ai 狀態` / `ai 報告`
5. Cloudflare Logs 應看到 `model=gpt-4o-mini` 與 `call ok` 或 `call fail`

## 0.17.3

- `report / 最新報告 / 本週報告` 現在優先回傳可直接閱讀的 operator narration：會先講結論、目前狀態、驗證進度、系統判讀、重點標的、下一步。
- `ai 報告 / ai 狀態 / ai 建議` 現在有雙層 timeout guard：webhook reply 最晚 2.5 秒內一定 fallback；OpenAI 呼叫 2.2 秒內若未完成會中止並改回內建摘要。
- 支援 `AI報告 / AI狀態 / AI建議`、`GPT報告 / GPT狀態 / GPT建議` 這類無空白輸入。

### 驗證順序
1. `npm run mo -- doctor`
2. `type VERSION`（應為 `0.17.3`）
3. `npm run mo -- deploy`

### LINE 驗證
- `最新報告`：第一行應為 `🧭 Market Operator Report｜<tradeDate>`，且主體不再出現 `summary=Y/N`、`rec=Y/N` 這類工程欄位。
- `AI 報告` 或 `AI報告`：即使 OpenAI 慢回，也應在數秒內至少收到 fallback 內建摘要。
- `AI 狀態` / `AI 建議`：同樣不可再出現 webhook 無回覆。

## 0.17.2

- 修正 LINE「AI 報告 / AI 狀態 / AI 建議」在 OpenAI 慢回或逾時時無回覆的問題。
- 新增 OpenAI 回應 8 秒 timeout guard。
- AI 逾時或失敗時，自動 fallback 為內建摘要並照常回 LINE。

## 0.17.1
- 修正 LINE `report / 最新報告 / 本週報告` 指向最新 MO operator report，而非僅顯示舊的台股盤後摘要。
- `ai 報告` payload 補入最新 cycle / review / recommendation context，支援 GPT 解釋層讀取最新 batch。

## 0.17.0
- LINE `report / 最新報告 / 本週報告` 現在回傳最新 cycle + review operator report，不再只讀舊的 `twse_daily_summary`。
- `ai 報告` payload 新增 cycle / review batch / review items / recommendation context，讓 GPT narration 能解釋最新狀態而不是停留在上週摘要。

## 0.16.1
- recommendation-review-save now respects review-side fill fallback when SIM_FILL_POLICY=RANGE_OR_CLOSE, promoting eligible D0 range misses into executed review samples for scoreboard accumulation.

## 0.16.0
- 新增 `SIM_FILL_POLICY`，支援 `STRICT_RANGE`、`RANGE_OR_CLOSE`、`NEXT_OPEN`。
- 預設改為 `RANGE_OR_CLOSE`：若買賣區間未觸發，模擬成交可回退到當日 close，開始累積第一批 executed samples。
- `src/index.ts` 的 pending order execution 會在 fallback fill 時把 `fallback=` 模式寫入 `mo_orders.reason`。

## 0.15.1

- 新增 execution gate 診斷摘要與 top reasons。
- review_note 新增 execution:* 細分原因，支援 scoreboard 追蹤成交阻塞。

## 0.14.9
- Add `coverage_accumulation_summary` to `mo recommendation-scoreboard` so the CLI shows whether MO is waiting for future trade dates or still repairing broken data.
- Pure `not-enough-trade-days` states now map to `coverage_wait / COVERAGE_ACCUMULATION` instead of being treated like missing-close repair failures.
- Verification: `npm run mo -- doctor` -> `npm run mo -- guard` -> `npm run mo -- sanity` -> `npm run mo -- recommendation-review-save` -> `npm run mo -- recommendation-scoreboard`.

## 0.14.8
- Hotfix for 0.14.6: `npm run mo -- recommendation-review-save` no longer crashes on missing helper definitions.
- After update, rerun `npm run mo -- recommendation-review-save` once to rewrite the latest review rows in canonical `.TW` form and clear same-date bare-symbol duplicates.
- Verification: `npm run mo -- doctor` -> `npm run mo -- guard` -> `npm run mo -- sanity` -> `npm run mo -- recommendation-review-save` -> `npm run mo -- recommendation-scoreboard`.

## 0.14.6
- Fix TW canonical symbol persistence across `mo_orders` and review-save so new review rows are saved as `XXXX.TW`.
- `runDailyProcess()` now upserts TW close snapshots into `prices_daily` for the active universe, reducing future `missing-close` gaps.
- `recommendation-review-save` now deduplicates raw dates, prefers `prices_daily` closes, and deletes legacy bare-symbol review rows before saving canonical rows.
- Verification: `npm run mo -- doctor` -> `npm run mo -- guard` -> `npm run mo -- sanity` -> `npm run mo -- recommendation-review-save` -> `npm run mo -- recommendation-scoreboard`.

## 0.14.4
- Add Daily Cycle Engine foundation: `mo_cycle_state` tracks `waiting_data / report_ready / core_ready / actionable_ready / report_only / expired`.
- Tick retry window extends to next-day open (09:00 Asia/Taipei) so MO keeps checking for late data instead of stopping at evening report time.
- Recommendation/simulation seeding no longer depends on report push success; 20-trading-day validation can start as soon as structured recommendation data exists.
- LINE adds `ai 狀態` / `ai 報告` / `ai 建議` for GPT explanation layer based on structured MO payloads.
- Verify order: `npm run mo -- doctor` -> `npm run typecheck` -> deploy -> LINE `狀態` / `ai 狀態` / `建議`.

## 0.14.2
- Added weekly operator message layer for report payload shaping and publish-ready messaging.

# 0.14.0

- Added weekly_run_gating_summary / findings / actions to recommendation-scoreboard.
- Added weekly report vs simulation gating based on operator decision.

## 0.13.9
- Add `operator_final_decision_summary`, `operator_final_decision_findings`, and `operator_final_decision_actions` to `mo recommendation-scoreboard`.
- Collapse the full repair->unlock pipeline into a final operator decision view for immediate next action.

# Release Notes

## 0.13.8
- Added pipeline advancement criteria layer to recommendation-scoreboard.
- Added pipeline_advancement_summary and pipeline_advancement_actions.


## 0.13.7
- add pipeline_readiness_summary / pipeline_readiness_findings / pipeline_readiness_actions
- summarize repair, warning, recheck, promotion, and unlock state into one top-level pipeline view

## 0.13.6
- add strategy evaluation unlock layer to recommendation-scoreboard
- add symbol_strategy_evaluation_unlock / strategy_evaluation_unlock_summary / strategy_evaluation_unlock_actions

## 0.13.5
- add post-repair recheck outcome layer to recommendation-scoreboard
- add symbol_post_repair_recheck_outcomes / post_repair_recheck_summary / post_repair_recheck_actions

0.13.5
0.13.2
- Added symbol_repair_status_transitions, repair_transition_summary, and repair_transition_actions.

## 0.13.0
- Repair Progress / Blocker Clearance
- `mo recommendation-scoreboard` 新增 `repair_readiness_summary`、`repair_progress_findings`、`repair_progress_actions`。
- 會在 `data_coverage_map` / `repair_targets` 之後，直接判斷 blocker 是否仍未解除，以及修復後是否已可進入 `STRATEGY_EVALUATION`。
- 驗證順序：先 `npm run mo -- doctor`，再 `npm run mo -- recommendation-scoreboard`，最後確認已出現 `repair_readiness_summary:`、`repair_progress_findings:`、`repair_progress_actions:`。

0.12.9

## 0.12.9
- Data Coverage Map / Repair Targets
- `mo recommendation-scoreboard` 新增 `data_coverage_map` 與 `repair_targets`。
- 會依 symbol 彙總 skip reason、data-related share、主要 issue、主要 checkpoint 與 blocker severity，直接指出優先修資料的標的。
- 驗證順序：先 `npm run mo -- doctor`，再 `npm run mo -- recommendation-scoreboard`，最後確認已出現 `data_coverage_map:` 與 `repair_targets:`。

0.12.8

## 0.12.7
- Data Quality Action Layer
- `mo recommendation-scoreboard` 在 `skip_reason_breakdown / gate_attribution / top_skip_reasons / gate_actionables` 之後，新增 `data_quality_summary`、`data_quality_findings`、`data_quality_actionables`。
- 會直接判讀資料缺口是否主導 skip，例如 `missing-close`、`not-enough-trade-days` 是否比 execution gate 更需要優先修復。
- 驗證順序：先 `npm run mo -- doctor`，再 `npm run mo -- recommendation-scoreboard`，最後確認已出現 data quality 三個新區塊。

## 0.12.6
- Structured Skip Reason Normalization
- `mo recommendation-scoreboard` 修正會一併查詢 `review_note`，不再把 skipped rows 全部誤歸為 `unknown`。
- 新增 structured normalization：把 `D20:not-enough-trade-days`、`D5:missing-close`、`signal-generated-but-not-filled` 等標記正規化成穩定 skip reason。
- `skip_reason_breakdown` / `gate_attribution` / `top_skip_reasons` 會優先輸出 normalization 後的 reason 與 gate family，例如 `data_coverage`、`data_gap`、`execution_gate`。
- 驗證順序：先 `npm run mo -- doctor`，再 `npm run mo -- recommendation-scoreboard`，最後確認不再只看到 `unknown / other`。

## 0.12.5
- Actionable Recommendations Layer
- `mo recommendation-scoreboard` 在 `batch_level_summary` / `top_findings` 之後，新增 `actionable_recommendations` 區塊。
- 依據 gate pressure、executed share、edge state、horizon signal，自動輸出下一步建議，例如先補 executed samples、先查 skip gate、暫緩 horizon 最適化。
- 驗證順序：先 `npm run mo -- doctor`，再 `npm run mo -- recommendation-scoreboard`，最後檢查 `actionable_recommendations:` 是否有正常輸出。

## 0.12.3
- Batch-Level Summary / Top Findings
- `mo recommendation-scoreboard` 在各 checkpoint diagnosis 之後，新增 `batch_level_summary` 與 `top_findings` 區塊。
- `batch_level_summary` 會輸出 `dominant_status_consensus`、`gate_pressure_consensus`、`edge_state_consensus`、`horizon_signal_consensus`、`strongest_horizon_checkpoint`、`max_execution_coverage_gap`、`average_positive_rate`、`average_executed_share`。
- `top_findings` 會直接列出本批次最重要的觀察，讓 scoreboard 從可讀提升到可快速判讀。

## 0.12.2
- Recommendation Diagnosis Layer
- `mo recommendation-scoreboard` 在既有 outcome / classification / performance / rolling / execution_summary 之外，新增 `D0 / D5 / D10 / D20` 的 `diagnosis` 區塊。
- 每個 checkpoint 會額外輸出 `dominant_status`、`dominant_status_share`、`gate_pressure`、`edge_state`、`horizon_signal_strength`、`execution_coverage_gap`、`interpretation`。
- 驗證順序：先 `npm run mo -- doctor`，再 `npm run mo -- recommendation-scoreboard`，最後檢查各 checkpoint 的 `*_diagnosis`。

## 0.12.1
- Execution-Aware Performance Summary
- `mo recommendation-scoreboard` 在既有 outcome / classification / performance / rolling 之外，新增 `D0 / D5 / D10 / D20` 的 `execution_summary` 區塊。
- 每個 checkpoint 會額外輸出 `overall / executed / skipped / pending` 的：`evaluable`、`share_of_evaluable`、`average_return`、`positive_rate`、`win_rate`、`loss_rate`、`flat_rate`、`expectancy`、`decisive_rate`。
- 驗證順序：先 `npm run mo -- doctor`，再 `npm run mo -- recommendation-scoreboard`，最後檢查各 checkpoint 的 `*_execution_summary`。

## 0.12.0
- Recommendation Performance Engine
- `mo recommendation-scoreboard` 新增 checkpoint performance 指標：`expectancy`、`avg_win_return`、`avg_loss_return`、`edge_ratio`、`nonflat_evaluable`、`decisive_rate`。
- 新增 rolling 視角：`last_1_batch` / `last_3_batch` / `last_5_batch` 的 evaluable、average_return、positive_rate。
- 新增 `BASELINE.json` 與 `mo baseline`；release 會自動寫入 locked baseline manifest。
- 驗證順序：先 `npm run mo -- doctor`，再 `npm run mo -- recommendation-scoreboard`，最後 `npm run mo -- baseline`。

Recommendation Outcome Classification

## 0.11.9

本版擴充 `mo recommendation-scoreboard`，在既有 D0 / D5 / D10 / D20 outcome metrics 之外，新增 outcome classification 區塊：
- `win / loss / flat`
- `win_rate / loss_rate / flat_rate`
- `executed / skipped / pending` 的 `evaluable` 與 `average_return`

用途：讓 scoreboard 在目前樣本多為 skipped 或回報為 `+0.00%` 時，能更清楚區分是「真的 flat」還是「不同 execution status 的混合結果」。

建議驗證：
1. `npm run mo -- doctor`
2. `npm run mo -- recommendation-scoreboard`

預期：
- 舊的 summary 欄位與 D0 / D5 / D10 / D20 outcome metrics 仍存在
- 每個 checkpoint 下面新增 classification 區塊
- 會顯示 `win / loss / flat` 與 `executed / skipped / pending` 切片

## 0.11.8
- Extend `mo recommendation-scoreboard` with checkpoint outcome summary for D0 / D5 / D10 / D20.
- New outcome metrics: `evaluable`, `coverage`, `positive`, `positive_rate`, `average_return`.
- Existing scoreboard summary fields remain unchanged for backward compatibility.

# 0.11.7

- Fix `mo recommendation-scoreboard` so remote D1 queries normalize SQL before passing to Wrangler on Windows.
- Add empty-SQL guard in recommendation review query helper.

# 0.11.6
- Added `mo recommendation-scoreboard` to summarize saved recommendation review snapshots.
- Updated CLI/help/doctor/docs for the new verification command.

## 0.11.5
- 修正 `recommendation-review-save` 在 Windows / cmd 環境下以 `--command` 傳多行 SQL 造成 Wrangler 判定缺少 `--command` 的問題。
- `execSql()` 現在會先將 SQL 正規化為單行再送給 `wrangler d1 execute`。

## 0.11.3
- 新增 `mo recommendation-review-save`，把最新推薦批次 review 結果落表到 D1。
- 自動建立 `mo_recommendation_review_batches`、`mo_recommendation_review_items`。
- 為後續 scoreboard / 命中率統計建立正式 snapshot 基線。

## 0.11.3
- `mo recommendation-review` 輸出強化：新增 `max_review_horizon`、`available_checkpoints`、`pending_checkpoints`，並明確區分 `not-enough-trade-days`、`missing-close`、`signal-generated-but-not-filled`。

# Release Notes

## 0.11.1
- 新增 `mo recommendation-review`，用最新推薦批次回看 D0 / D5 / D10 / D20 的模擬表現。
- 明確校正 MO 定位：MO 是推薦驗證系統，不是實盤交易系統；portfolio / orders / execution marks 屬於推薦驗證用模擬資料層。
- 同步更新 `MO_START.md`、`docs/PROJECT.md`、`docs/AI_MEMORY.md`、`docs/NEXT_TASK.md`、`docs/BUGS.md`、`docs/FUTURE_SYSTEMS.md`、`docs/commands.md`、`developer/SCRIPTS_GUIDE.md`。

## 驗證重點
1. `npm run mo -- doctor` 後，版本應顯示為 `market-observer@0.11.1`。
2. `npm run mo -- recommendation-review` 應成功，輸出最新推薦批次的 D0 / D5 / D10 / D20 表現。
3. 若目前尚不足 20 個交易日資料，腳本應顯示 partial review / D20 summary skip，而不是失敗。



- 0.14.2: added weekly_delivery_formatting_summary / weekly_delivery_formatting_blocks / weekly_delivery_formatting_actions for LINE/email/log payload shaping.


## 0.14.8
- `mo recommendation-review` / `save` 會先嘗試補抓 active TW symbols 的月收盤資料，再計算 D0/D5/D10/D20
- 修正 review 流程為 async，避免 backfill 邏輯無法執行
- 目標：優先解除 `D0:missing-close`，讓後續缺口收斂到 `not-enough-trade-days`
