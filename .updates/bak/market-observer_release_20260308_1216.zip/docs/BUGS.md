## Open Bugs

### BUG-20260307-09
Title: Trade sizing must account for minimum quantity and transaction costs to avoid fee-inefficient orders
Status: Fixed in 0.10.0

## Open Bugs

### BUG-20260307-08
Title: Universe candidates rejected by missing_close / invalid_close in final recommendation gate
Status: Fixed in 0.9.1

# BUG TRACKER

## Open Bugs

### BUG-20260307-04
- Title: Universe candidates are generated, but final recommendation selection returns zero recommendations.
- Status: Fixed in 0.9.0
- Evidence: `mo_recommendation_log` showed `candidate_count > 0` with `rec_count = 0`; LINE 顯示「明日建議：不動（無明顯機會）」。
- Resolution: strengthen universe snapshot backfill (`close / chg / value`) and add conservative `starter_fallback` selection when normal ranking produces 0 recommendations under `TRY/AGGRESSIVE`.
- Verification: deploy 後以 LINE `狀態 / 建議 / debug` 驗證，預期可看到至少一筆 observation-style recommendation，或在 debug 中看到更完整的 rejected/selected 記錄。

## Fixed Bugs

### BUG-20260307-05
- Title: Release artifact delivered with a versioned filename instead of `market-observer_release_latest.zip`, causing `mo update` to fail.
- Status: Fixed in 0.8.5
- Resolution: 新增 `scripts/validate-artifacts.mjs`、`mo validate-artifacts`，並讓 smoke 在 release 後強制驗證 artifact 命名與 outbox 結構。
- Verification: `npm run mo -- release` 後執行 `npm run mo -- validate-artifacts`；若出現非 `market-observer_release_latest.zip` 的 release 檔或 deprecated outbox 子目錄，流程會失敗。

### BUG-20260307-03
- Title: `etf_universe` exists in D1, but strategy engine only filtered `topByValue`, causing `done 0/0` and no new recommendations.
- Status: Fixed in 0.8.3
- Resolution: universe 來源改為優先讀 D1 `etf_universe(enabled=1)`，並從 `stocksAll` 全量快照建立 universe 候選，不再只在 `topByValue` 內找。
- Verification: deploy 後可用 LINE `universe` / `狀態` / `建議` 與 D1 `mo_orders`、`mo_recommendation_log` 驗證。

### BUG-20260307-02
- Title: `mo_recommendation_log` runtime schema drift with existing migration / legacy logs.
- Status: Fixed in 0.8.3
- Resolution: `ensureMultiAssetTables` 會補齊 recommendation log 缺欄位；`狀態` 查詢可兼容 legacy schema 與 `recommendation_log`。
- Verification: `狀態` 不再因 log schema 差異失敗；新 tick 後可查到最新 recommendation log。

### BUG-20260307-01
- Title: Deprecated outbox subdirectories not fully removed from local repo
- Status: Fixed in 0.8.1
- Resolution: `apply-update` / `apply-patch` / `sync-structure` 現在會清理 `.updates/outbox/dev`、`.updates/outbox/release`、`.updates/outbox/handoff`、`.updates/outbox/patch`，並以單一 `.updates/outbox/` 結構為準。
- Verification: 使用者在 0.8.1 實測 `mo update` 後，本機 repo 已顯示 cleanup removed 並成功 `mo smoke` / `mo deploy`。

## Regression Guards
- All newly discovered bugs must be recorded here.
- Bug fixes must update status and mention the bug ID in CHANGELOG / RELEASE_NOTES when relevant.
- Release validation is based on the real package after `mo update`, not on chat claims.

- [fixed 0.10.1] 重跑 `/admin/run` 會為同 `signal_date + symbol + side` 重複建立 `PENDING` 單，現已改為 idempotent insert；舊重複單需一次性 SQL 清理。


## 0.10.2 guardrail response
- Problem: AI 在 release 交付時多次未遵守 `market-observer_release_latest.zip`、未完全依 dev 包開發、對話中過度說明而未直接產出正確 artifact。
- Mitigation: 新增 `scripts/guard.mjs`、`scripts/sanity.mjs`、`mo guard`、`mo sanity`，並將 `pack:release` 改為自動先跑 guardrail 流程。
- Verification: `npm run mo -- guard`、`npm run mo -- sanity`、`npm run mo -- release` 均需成功；若 release 名稱、文件、版本不同步，流程應直接失敗。


## 0.10.3 guardrail follow-up
- Problem: release 前需要人工記住 doctor / smoke / guard / sanity 的順序，容易在多輪驗證中漏跑。
- Mitigation: 新增 `mo autopilot` / `mo autopilot-worker`，將例行巡檢固定為單一指令。
- Verification: `npm run mo -- autopilot` 與 `npm run mo -- autopilot-worker` 需成功，且輸出應包含各步驟成功紀錄。


## 0.10.4 guardrail consolidation
- Problem: `guard`、`sanity`、`validate-artifacts` 與 `doctor/smoke` 需要人工記住多組順序，`autopilot` 與 release 流程也可能逐漸分叉。
- Mitigation: 新增 `mo validate`、`mo preflight`、`mo preflight-worker`，並讓 `autopilot` 轉呼叫 preflight，收斂單一巡檢定義。
- Verification: `npm run mo -- validate`、`npm run mo -- preflight`、`npm run mo -- preflight-worker`、`npm run mo -- autopilot`、`npm run mo -- release` 均需成功。


## 0.10.6 runtime-invariants parser hotfix
- Problem: `scripts/runtime-invariants.mjs` 直接對 `wrangler.jsonc` 使用 `JSON.parse`，遇到註解 / trailing comma 時會在 `loadDbName()` 崩潰，導致 `runtime-invariants`、`preflight-worker`、`autopilot-worker` 全部失敗。
- Mitigation: 改為使用可容忍 JSONC 的解析流程（去 comment + 去 trailing comma 後再 parse）。
- Verification: `npm run mo -- runtime-invariants`、`npm run mo -- preflight-worker`、`npm run mo -- autopilot-worker` 均需成功，且不得再出現 `Expected double-quoted property name in JSON`。

## 0.10.5 runtime consistency guard
- Problem: preflight 先前只驗 toolchain / artifact，無法在 deploy 前攔下 remote D1 的負現金、NaN/非正持倉、缺 snapshot / stale snapshot、`EXECUTED` 缺 `exec_date`。
- Mitigation: 新增 `scripts/runtime-invariants.mjs` 與 `mo runtime-invariants`，並將其納入 `preflight-worker` / `autopilot-worker`。
- Verification: `npm run mo -- runtime-invariants`、`npm run mo -- preflight-worker`、`npm run mo -- autopilot-worker` 均需成功；若故意製造負現金或缺 snapshot，流程應直接失敗。
