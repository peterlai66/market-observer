## 0.13.2
- Added symbol repair status transitions and repair transition summary/action layers to recommendation-scoreboard.

## 0.13.0
- Add `repair_readiness_summary`, `repair_progress_findings`, and `repair_progress_actions` to recommendation scoreboard.
- Extend symbol-level repair outputs into blocker-clearance / post-repair readiness signals for strategy evaluation.

## 0.12.9
- Add symbol-level `data_coverage_map` and `repair_targets` to recommendation scoreboard.
- Prioritize repair targets by blocker severity, missing-close concentration, and data-related share.

0.12.8

## 0.12.7
- feat(scoreboard): 新增 data quality action layer，於 gate attribution 後輸出 `data_quality_summary`、`data_quality_findings`、`data_quality_actionables`。
- feat(scoreboard): 將 data_gap / data_coverage / data_quality 與 execution_gate 分開判讀，讓 scoreboard 直接指出資料缺口是否為主要阻塞。

## 0.12.6
- feat(scoreboard): recommendation-scoreboard 現在會查詢 `review_note`，修正 0.12.5 skip reason breakdown 因缺欄位導致全部落在 `unknown / other` 的問題。
- feat(scoreboard): 新增 structured skip reason normalization，將 checkpoint-prefixed marks 正規化成 `signal-generated-but-not-filled`、`not-enough-trade-days`、`missing-close` 等穩定 reason，並映射到 `execution_gate`、`data_coverage`、`data_gap` 等 family。

## 0.12.5
- feat(scoreboard): 新增 actionable recommendations layer，於 `top_findings` 後輸出可執行的下一步建議。
- feat(scoreboard): recommendation 會依 gate pressure、executed share、edge state、horizon signal 自動調整。

## 0.12.3
- feat(scoreboard): 新增 batch-level summary 與 top findings，彙總所有 checkpoint 的 dominant status / gate pressure / edge state / horizon signal 共識。
- feat(scoreboard): 新增 strongest horizon、max execution coverage gap、average executed share 等批次層級摘要。

## 0.12.2
- feat(scoreboard): 新增 checkpoint diagnosis layer，於每個 checkpoint 額外輸出 `dominant_status`、`dominant_status_share`、`gate_pressure`、`edge_state`、`horizon_signal_strength`、`execution_coverage_gap`、`interpretation`。
- docs(scoreboard): 同步更新 MO_START / PROJECT / AI_MEMORY / NEXT_TASK / commands / developer guide，將 0.12.2 定位為 diagnosis 版本。

## 0.12.1
- feat(scoreboard): 新增 execution-aware performance summary，於每個 checkpoint 額外輸出 overall / executed / skipped / pending 的 evaluable share、average return、positive / win / loss / flat rate、expectancy、decisive rate。
- docs(baseline): 同步更新 MO_START / PROJECT / NEXT_TASK / commands / developer guide，將 0.12.1 定位為 execution-aware summary 版本。

## 0.12.0 - Recommendation Performance Engine
- `mo recommendation-scoreboard` 新增 checkpoint performance 指標：`expectancy`、`avg_win_return`、`avg_loss_return`、`edge_ratio`、`nonflat_evaluable`、`decisive_rate`。
- `mo recommendation-scoreboard` 新增 `last_1_batch` / `last_3_batch` / `last_5_batch` rolling summary。
- 新增 `BASELINE.json`、`mo baseline`、`scripts/write-baseline.mjs`，release 現在會自動鎖定 baseline manifest。

## 0.11.9 - Recommendation Outcome Classification
- `mo recommendation-scoreboard` 新增各 checkpoint 的 outcome classification。
- 新增 `win / loss / flat` 統計與 `win_rate / loss_rate / flat_rate`。
- 新增 `executed / skipped / pending` 切片的 evaluable 與 average_return，避免全部 `+0.00%` 時誤讀為真實績效無波動。
- 保留既有 summary 與 0.11.8 outcome metrics 欄位不變。

## 0.11.8 recommendation outcome metrics

- Extend `mo recommendation-scoreboard` with checkpoint outcome summary for D0 / D5 / D10 / D20.
- Added per-checkpoint `evaluable`, `coverage`, `positive`, `positive_rate`, and `average_return` metrics.
- Kept the existing total batch / symbol / filled / skipped / pending / latest batch summary unchanged.

## 0.11.7 recommendation scoreboard query normalization

- Fix recommendation-scoreboard on Windows by normalizing SQL before `wrangler d1 execute --command`.
- Guard against empty SQL in recommendation review library.

## 0.11.6 recommendation scoreboard
- 新增 `mo recommendation-scoreboard`，可彙總已落表的 recommendation review batch / item 統計。
- 輸出包含 total_batches、total_symbols、filled/skipped/pending orders、skip_ratio、filled_ratio，以及 latest batch 概況。

## 0.11.5
- 修正 `recommendation-review-save` 在 Windows / cmd 環境下以 `--command` 傳多行 SQL 造成 Wrangler 判定缺少 `--command` 的問題。
- `execSql()` 現在會先將 SQL 正規化為單行再送給 `wrangler d1 execute`。

## 0.11.3
- 新增 `mo recommendation-review-save`，把最新推薦批次 review 結果落表到 D1。
- 自動建立 `mo_recommendation_review_batches`、`mo_recommendation_review_items`。
- 為後續 scoreboard / 命中率統計建立正式 snapshot 基線。

## 0.11.3
- `mo recommendation-review` 輸出強化：新增 `max_review_horizon`、`available_checkpoints`、`pending_checkpoints`，並明確區分 `not-enough-trade-days`、`missing-close`、`signal-generated-but-not-filled`。

# Changelog

## 0.11.1
- feat(review): 新增 `scripts/recommendation-review.mjs` 與 `mo recommendation-review`，回看最新推薦批次在 D0 / D5 / D10 / D20 的模擬表現。
- docs(scope): 明確校正 MO 為推薦驗證系統，不將模擬資料層誤解為實盤交易系統。
- docs(tooling): 同步更新 `MO_START.md`、`docs/PROJECT.md`、`docs/AI_MEMORY.md`、`docs/NEXT_TASK.md`、`docs/BUGS.md`、`docs/FUTURE_SYSTEMS.md`、`docs/commands.md`、`developer/SCRIPTS_GUIDE.md`。
