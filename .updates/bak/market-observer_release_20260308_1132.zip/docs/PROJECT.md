## 0.10.0 update
- MO 已進入成交閉環第一階段：strategy output 不只會產生 `mo_orders`，也會在 recommendation 與 execution 兩端做成本感知過濾。
- 新增交易守門概念：`minQty`、`minNotionalTwd`、`roundTripCost`、`edge_lt_cost`。
- 目前 TW ETF 採保守規則：先過成本與最小量門檻，再進入 PENDING / EXECUTED / SKIPPED 流程。

# PROJECT

## Current state
- CLI / update / smoke / deploy pipeline stable
- ETF universe comes from env -> D1 -> default fallback
- Multi-asset engine now generates candidates from universe snapshots
- 0.9.0 adds conservative starter fallback so the system can move from pure observation to actionable recommendations
- LINE commands for operational verification: 狀態 / 建議 / debug / universe

- 0.9.1: final recommendation close-price mapping now resolves TW ETF prices from raw close, OHLC fallback, and candidate fallback before rejecting for invalid close.

- 0.10.1 已修正同交易日重複建單問題；`mo_orders` 改為 idempotent insert，重跑 `/admin/run` 只會記錄 dedupe，不再污染訂單表。
- `mo_execution_mark` 現在會記錄 `SKIPPED / EXECUTED` 結果，方便驗證 pending 單後續是否真的被處理。


## 0.10.2 toolchain guardrail
- 新增 `mo guard` / `mo sanity`，用來在 release 前先攔下 AI 偏離流程、錯誤檔名、文件未同步、版本不同步等問題。
- `pack:release` 會自動串起 `sync-structure` → `doctor` → `guard` → `sanity` → `validate-artifacts`。
- 正式開發循環固定為：release 驗證 / 討論 → 使用者提供 `market-observer_dev_latest.zip` → AI 開發 → release。
