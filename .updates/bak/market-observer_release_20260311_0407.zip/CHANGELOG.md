## 0.18.4
- tradeDate probe builder corrected to include anchor+1 and shared probe list for legacy/FinMind
- logging now emits anchor, anchor_plus_one, probes

## 0.18.0
- fix(trade-date): legacy MI_INDEX probes now prioritize `anchor+1` and ignore candidates more than one day ahead of the primary anchor.
- fix(finmind): switch backstop dataset from `TaiwanStockPrice` to `TaiwanStockTradingDate`, and treat auth/plan rejection as soft-unavailable instead of poisoning quorum.

## 0.17.9
- tradeDate engine 新增 FinMind backstop，並將 legacy 探測改為包含 today / today-1，避免 3/11 凌晨仍停在 3/9。
- 最新報告改為優先使用最新 cycle / recommendation / summary 日期，不再被舊 review batch 綁回 3/6。

## 0.17.8
- fix(twse): legacy MI_INDEX probe now anchors to the freshest primary trade date and only accepts at-most +1 day backstop results, preventing false jumps to today.
- logs(twse): add legacy probe anchor/probe/delta logging so remote /admin/run can explain why a legacy date was accepted or ignored.

## 0.17.7
- Fix TWSE trade-date resolution: FMTQIK / STOCK_DAY_ALL now take the latest distinct date instead of the first row, and MI_INDEX legacy date probes are used as a freshness backstop.
- Pack scripts now auto-include root repo files, reducing the chance that newly added baseline/docs/config files are omitted from dev/release/patch artifacts.

## 0.17.6
- fix(ai): 預設 OpenAI model 改為 gpt-4o-mini，並由 wrangler vars 明確鎖定 AI_ENABLED=1 / OPENAI_MODEL=gpt-4o-mini。
- fix(ai): `ai 狀態 / ai 報告 / ai 建議` 現在會把最近一次 AI 呼叫結果落表到 `mo_ai_audit`，可追查是否真的呼叫、是否成功、耗時多久、是否拿到回應。
- fix(ai): webhook 內 AI timeout guard 縮短為 1.2 秒，避免 LINE 因等待 GPT 而更容易 cancel。

## 0.17.3

- LINE `report / 最新報告 / 本週報告` 改成 human-readable operator narration，主畫面優先顯示結論、驗證進度、重點標的與下一步，不再先丟工程欄位。
- LINE `AI 報告 / AI 狀態 / AI 建議` webhook timeout guard 從 8.5 秒縮短到 2.5 秒，並對 OpenAI 呼叫加上 2.2 秒 abort，避免 reply 被卡住。
- 新增 `AI報告 / AI狀態 / AI建議` 與 `GPT報告 / GPT狀態 / GPT建議` 無空白別名，降低 LINE 指令輸入失敗率。

## 0.17.2

- 修正 LINE「AI 報告 / AI 狀態 / AI 建議」在 OpenAI 慢回或逾時時無回覆的問題。
- 新增 OpenAI 回應 8 秒 timeout guard。
- AI 逾時或失敗時，自動 fallback 為內建摘要並照常回 LINE。

## 0.17.1
- 修正 LINE `report / 最新報告 / 本週報告` 指向最新 MO operator report，而非僅顯示舊的台股盤後摘要。
- `ai 報告` payload 補入最新 cycle / review / recommendation context，支援 GPT 解釋層讀取最新 batch。

## 0.17.0
- LINE `report / 最新報告 / 本週報告` 現在回傳最新 cycle + review operator report，不再只讀舊的 `twse_daily_summary`。
- `ai 報告` payload 新增 cycle / review batch / review items / recommendation context，讓 GPT narration 能解釋最新狀態而不是停留在上週摘要。

## 0.16.1
- recommendation-review-save now respects review-side fill fallback when SIM_FILL_POLICY=RANGE_OR_CLOSE, promoting eligible D0 range misses into executed review samples for scoreboard accumulation.

## 0.16.0
- 新增 `SIM_FILL_POLICY`，支援 `STRICT_RANGE`、`RANGE_OR_CLOSE`、`NEXT_OPEN`。
- 預設改為 `RANGE_OR_CLOSE`：若買賣區間未觸發，模擬成交可回退到當日 close，開始累積第一批 executed samples。
- `src/index.ts` 的 pending order execution 會在 fallback fill 時把 `fallback=` 模式寫入 `mo_orders.reason`。

## 0.15.1
- 新增 execution gate breakdown，將 signal-generated-but-not-filled 細分為可診斷的 execution:* 原因。
- recommendation-review-save 會把 mo_orders.reason 正規化寫入 review_note，便於 scoreboard 追蹤成交阻塞根因。

## 0.14.9
- `recommendation-scoreboard` now distinguishes natural future-day waiting from broken data pipelines.
- Add `coverage_accumulation_summary` so MO can show the latest unlocked checkpoint, the next checkpoint to unlock, and how many future trade dates are still needed.
- Reclassify pure `not-enough-trade-days` situations away from `DATA_REPAIR`, reducing false alarms once D0 data is already valid.

## 0.14.8
- Hotfix `recommendation-review-save`: restore missing `canonicalTwSymbol` / `bareTwSymbol` / `unique` helpers so the command can execute instead of crashing with `ReferenceError`.
- Unblocks canonical `.TW` review persistence and allows the next successful save run to delete historical bare-symbol rows for the same trade date.

## 0.14.6
- Add TW close snapshot upsert into `prices_daily` during daily processing for active-universe symbols.
- Canonicalize recommendation persistence to `.TW` and delete legacy bare-symbol `mo_orders` / review rows for the same trade date.
- Recommendation review now counts unique future trade dates and falls back to `prices_daily` closes instead of relying only on duplicated `twse_daily_raw` rows.

## 0.14.4
- Add daily cycle state tracking (`mo_cycle_state`) so MO can keep retrying from 14:30 until next-day open instead of stalling at report-not-ready.
- Decouple recommendation/simulation bootstrap from report push; snapshot-ready days can now seed next-day simulated orders even when summary push is still pending.
- Add GPT explanation commands (`ai 狀態`, `ai 報告`, `ai 建議`) and include cycle state in AI payloads.

## 0.14.2
- Added weekly operator message layer for report payload shaping and publish-ready messaging.

## 0.14.0
- Added weekly run gating summary to recommendation-scoreboard.

## 0.13.9 operator final decision summary
- Add final operator decision summary / findings / actions to `mo recommendation-scoreboard`.
- Surface `final_decision`, `operator_priority`, `release_blocker`, `dominant_gate`, and `immediate_next_action`.

## 0.13.8
- Add pipeline advancement criteria output to recommendation-scoreboard.
- Add pipeline advancement summary/actions for stage progression visibility.

## 0.13.7
- add full pipeline readiness summary layer to recommendation-scoreboard

## 0.13.6
- add strategy evaluation unlock layer to recommendation-scoreboard

## 0.13.2
- Added symbol repair status transitions and repair transition summary/action layers to recommendation-scoreboard.

## 0.13.0
- Add `repair_readiness_summary`, `repair_progress_findings`, and `repair_progress_actions` to recommendation scoreboard.
- Extend symbol-level repair outputs into blocker-clearance / post-repair readiness signals for strategy evaluation.

## 0.12.9
- Add symbol-level `data_coverage_map` and `repair_targets` to recommendation scoreboard.
- Prioritize repair targets by blocker severity, missing-close concentration, and data-related share.

0.12.8

## 0.12.7
- feat(scoreboard): 新增 data quality action layer，於 gate attribution 後輸出 `data_quality_summary`、`data_quality_findings`、`data_quality_actionables`。
- feat(scoreboard): 將 data_gap / data_coverage / data_quality 與 execution_gate 分開判讀，讓 scoreboard 直接指出資料缺口是否為主要阻塞。

## 0.12.6
- feat(scoreboard): recommendation-scoreboard 現在會查詢 `review_note`，修正 0.12.5 skip reason breakdown 因缺欄位導致全部落在 `unknown / other` 的問題。
- feat(scoreboard): 新增 structured skip reason normalization，將 checkpoint-prefixed marks 正規化成 `signal-generated-but-not-filled`、`not-enough-trade-days`、`missing-close` 等穩定 reason，並映射到 `execution_gate`、`data_coverage`、`data_gap` 等 family。

## 0.12.5
- feat(scoreboard): 新增 actionable recommendations layer，於 `top_findings` 後輸出可執行的下一步建議。
- feat(scoreboard): recommendation 會依 gate pressure、executed share、edge state、horizon signal 自動調整。

## 0.12.3
- feat(scoreboard): 新增 batch-level summary 與 top findings，彙總所有 checkpoint 的 dominant status / gate pressure / edge state / horizon signal 共識。
- feat(scoreboard): 新增 strongest horizon、max execution coverage gap、average executed share 等批次層級摘要。

## 0.12.2
- feat(scoreboard): 新增 checkpoint diagnosis layer，於每個 checkpoint 額外輸出 `dominant_status`、`dominant_status_share`、`gate_pressure`、`edge_state`、`horizon_signal_strength`、`execution_coverage_gap`、`interpretation`。
- docs(scoreboard): 同步更新 MO_START / PROJECT / AI_MEMORY / NEXT_TASK / commands / developer guide，將 0.12.2 定位為 diagnosis 版本。

## 0.12.1
- feat(scoreboard): 新增 execution-aware performance summary，於每個 checkpoint 額外輸出 overall / executed / skipped / pending 的 evaluable share、average return、positive / win / loss / flat rate、expectancy、decisive rate。
- docs(baseline): 同步更新 MO_START / PROJECT / NEXT_TASK / commands / developer guide，將 0.12.1 定位為 execution-aware summary 版本。

## 0.12.0 - Recommendation Performance Engine
- `mo recommendation-scoreboard` 新增 checkpoint performance 指標：`expectancy`、`avg_win_return`、`avg_loss_return`、`edge_ratio`、`nonflat_evaluable`、`decisive_rate`。
- `mo recommendation-scoreboard` 新增 `last_1_batch` / `last_3_batch` / `last_5_batch` rolling summary。
- 新增 `BASELINE.json`、`mo baseline`、`scripts/write-baseline.mjs`，release 現在會自動鎖定 baseline manifest。

## 0.11.9 - Recommendation Outcome Classification
- `mo recommendation-scoreboard` 新增各 checkpoint 的 outcome classification。
- 新增 `win / loss / flat` 統計與 `win_rate / loss_rate / flat_rate`。
- 新增 `executed / skipped / pending` 切片的 evaluable 與 average_return，避免全部 `+0.00%` 時誤讀為真實績效無波動。
- 保留既有 summary 與 0.11.8 outcome metrics 欄位不變。

## 0.11.8 recommendation outcome metrics

- Extend `mo recommendation-scoreboard` with checkpoint outcome summary for D0 / D5 / D10 / D20.
- Added per-checkpoint `evaluable`, `coverage`, `positive`, `positive_rate`, and `average_return` metrics.
- Kept the existing total batch / symbol / filled / skipped / pending / latest batch summary unchanged.

## 0.11.7 recommendation scoreboard query normalization

- Fix recommendation-scoreboard on Windows by normalizing SQL before `wrangler d1 execute --command`.
- Guard against empty SQL in recommendation review library.

## 0.11.6 recommendation scoreboard
- 新增 `mo recommendation-scoreboard`，可彙總已落表的 recommendation review batch / item 統計。
- 輸出包含 total_batches、total_symbols、filled/skipped/pending orders、skip_ratio、filled_ratio，以及 latest batch 概況。

## 0.11.5
- 修正 `recommendation-review-save` 在 Windows / cmd 環境下以 `--command` 傳多行 SQL 造成 Wrangler 判定缺少 `--command` 的問題。
- `execSql()` 現在會先將 SQL 正規化為單行再送給 `wrangler d1 execute`。

## 0.11.3
- 新增 `mo recommendation-review-save`，把最新推薦批次 review 結果落表到 D1。
- 自動建立 `mo_recommendation_review_batches`、`mo_recommendation_review_items`。
- 為後續 scoreboard / 命中率統計建立正式 snapshot 基線。

## 0.11.3
- `mo recommendation-review` 輸出強化：新增 `max_review_horizon`、`available_checkpoints`、`pending_checkpoints`，並明確區分 `not-enough-trade-days`、`missing-close`、`signal-generated-but-not-filled`。

# Changelog

## 0.11.1
- feat(review): 新增 `scripts/recommendation-review.mjs` 與 `mo recommendation-review`，回看最新推薦批次在 D0 / D5 / D10 / D20 的模擬表現。
- docs(scope): 明確校正 MO 為推薦驗證系統，不將模擬資料層誤解為實盤交易系統。
- docs(tooling): 同步更新 `MO_START.md`、`docs/PROJECT.md`、`docs/AI_MEMORY.md`、`docs/NEXT_TASK.md`、`docs/BUGS.md`、`docs/FUTURE_SYSTEMS.md`、`docs/commands.md`、`developer/SCRIPTS_GUIDE.md`。


0.13.5: blocked repair completion criteria added.


- 0.14.2: added weekly_delivery_formatting_summary / weekly_delivery_formatting_blocks / weekly_delivery_formatting_actions for LINE/email/log payload shaping.


## 0.14.8
- add TW monthly close backfill inside recommendation review flow using official TWSE monthly close endpoint candidates
- auto upsert fetched .TW close rows into prices_daily before computing review horizons
- keep recommendation review/save async so remote repair can run before scoreboard evaluation
