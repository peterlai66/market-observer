Recommendation Outcome Classification

## 0.11.9

本版擴充 `mo recommendation-scoreboard`，在既有 D0 / D5 / D10 / D20 outcome metrics 之外，新增 outcome classification 區塊：
- `win / loss / flat`
- `win_rate / loss_rate / flat_rate`
- `executed / skipped / pending` 的 `evaluable` 與 `average_return`

用途：讓 scoreboard 在目前樣本多為 skipped 或回報為 `+0.00%` 時，能更清楚區分是「真的 flat」還是「不同 execution status 的混合結果」。

建議驗證：
1. `npm run mo -- doctor`
2. `npm run mo -- recommendation-scoreboard`

預期：
- 舊的 summary 欄位與 D0 / D5 / D10 / D20 outcome metrics 仍存在
- 每個 checkpoint 下面新增 classification 區塊
- 會顯示 `win / loss / flat` 與 `executed / skipped / pending` 切片

## 0.11.8
- Extend `mo recommendation-scoreboard` with checkpoint outcome summary for D0 / D5 / D10 / D20.
- New outcome metrics: `evaluable`, `coverage`, `positive`, `positive_rate`, `average_return`.
- Existing scoreboard summary fields remain unchanged for backward compatibility.

# 0.11.7

- Fix `mo recommendation-scoreboard` so remote D1 queries normalize SQL before passing to Wrangler on Windows.
- Add empty-SQL guard in recommendation review query helper.

# 0.11.6
- Added `mo recommendation-scoreboard` to summarize saved recommendation review snapshots.
- Updated CLI/help/doctor/docs for the new verification command.

## 0.11.5
- 修正 `recommendation-review-save` 在 Windows / cmd 環境下以 `--command` 傳多行 SQL 造成 Wrangler 判定缺少 `--command` 的問題。
- `execSql()` 現在會先將 SQL 正規化為單行再送給 `wrangler d1 execute`。

## 0.11.3
- 新增 `mo recommendation-review-save`，把最新推薦批次 review 結果落表到 D1。
- 自動建立 `mo_recommendation_review_batches`、`mo_recommendation_review_items`。
- 為後續 scoreboard / 命中率統計建立正式 snapshot 基線。

## 0.11.3
- `mo recommendation-review` 輸出強化：新增 `max_review_horizon`、`available_checkpoints`、`pending_checkpoints`，並明確區分 `not-enough-trade-days`、`missing-close`、`signal-generated-but-not-filled`。

# Release Notes

## 0.11.1
- 新增 `mo recommendation-review`，用最新推薦批次回看 D0 / D5 / D10 / D20 的模擬表現。
- 明確校正 MO 定位：MO 是推薦驗證系統，不是實盤交易系統；portfolio / orders / execution marks 屬於推薦驗證用模擬資料層。
- 同步更新 `MO_START.md`、`docs/PROJECT.md`、`docs/AI_MEMORY.md`、`docs/NEXT_TASK.md`、`docs/BUGS.md`、`docs/FUTURE_SYSTEMS.md`、`docs/commands.md`、`developer/SCRIPTS_GUIDE.md`。

## 驗證重點
1. `npm run mo -- doctor` 後，版本應顯示為 `market-observer@0.11.1`。
2. `npm run mo -- recommendation-review` 應成功，輸出最新推薦批次的 D0 / D5 / D10 / D20 表現。
3. 若目前尚不足 20 個交易日資料，腳本應顯示 partial review / D20 summary skip，而不是失敗。

