#!/usr/bin/env node
import { run } from './_util.mjs';

const mode = (process.argv[2] || 'toolchain').trim().toLowerCase();
const includeWorker = mode === 'worker' || mode === 'full';

const steps = [
  ['doctor', ['node', ['scripts/doctor.mjs']]],
  ['smoke', ['node', ['scripts/smoke-tools.mjs']]],
];
if (includeWorker) {
  steps.push(['smoke-worker', ['node', ['scripts/smoke-worker.mjs']]]);
}
steps.push(
  ['guard', ['node', ['scripts/guard.mjs']]],
  ['sanity', ['node', ['scripts/sanity.mjs']]],
);

console.log(`MO Autopilot (${includeWorker ? 'worker' : 'toolchain'})`);
for (const [label, [cmd, args]] of steps) {
  console.log(`→ ${label}`);
  run(cmd, args);
}
console.log('Autopilot OK');
