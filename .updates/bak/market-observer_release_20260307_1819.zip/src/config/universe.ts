export type UniverseItem = {
	code: string;
	name: string;
};

// 目前 Worker 資料源是 TWSE，因此預設 universe 先收斂在台股 ETF。
// 若之後接上美股 / 全球 ETF 價料，再擴充即可。
export const DEFAULT_TW_ETF_UNIVERSE: UniverseItem[] = [
	{ code: '0050', name: '元大台灣50' },
	{ code: '006208', name: '富邦台50' },
	{ code: '0056', name: '元大高股息' },
	{ code: '00878', name: '國泰永續高股息' },
	{ code: '00919', name: '群益台灣精選高息' },
];

export function parseUniverseCodes(raw: string | null | undefined): string[] {
	const txt = String(raw || '').trim();
	if (!txt) return [];
	return txt
		.split(/[\s,;|]+/)
		.map((x) => x.trim())
		.filter(Boolean)
		.map((x) => x.toUpperCase());
}

export function getUniverseCodes(raw: string | null | undefined): string[] {
	const parsed = parseUniverseCodes(raw);
	if (parsed.length) return parsed;
	return DEFAULT_TW_ETF_UNIVERSE.map((x) => x.code);
}
