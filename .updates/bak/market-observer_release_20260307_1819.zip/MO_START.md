# MO_START

這是 Market Observer (MO) 專案的唯一入口文件。任何 AI 接手本專案時，必須先讀本文件，再讀 `docs/PROJECT.md`、`docs/AI_MEMORY.md`、`docs/NEXT_TASK.md`、`developer/SCRIPTS_GUIDE.md`。

## 1. 核心原則
- 使用者只負責提需求、定框架、做線上驗收；不手動改程式。
- AI 負責實作、同步文件、產出 release / patch / handoff。
- 一般交付一律提供可透過 `mo update` 套用的 release zip。
- 只有使用者明確輸入 `handoff` 時，才進入交接流程並產出 handoff 包。
- 所有已定案流程與規格都要同步寫入文件，不可只留在聊天室。

## 2. update / deploy 分流
- `update`：把 release / patch 套用到 local repo。
- `deploy`：把 Worker 發佈到 Cloudflare。
- 若 release 包含 `src/`、`wrangler.jsonc`、`migrations/`、`worker-configuration.d.ts`，update 後必須 deploy。

## 3. 測試流程
### 工具鏈 / 文件修改
- `npm run smoke:tools`
- `npm run mo -- update`

### Worker 程式修改
- `npm run smoke:tools`
- `npm run smoke:worker`
- `npm run mo -- update`
- `npm run mo -- deploy`

## 4. D0~D19 的正式定義
- D0~D19 代表 20 個交易日的模擬週期。
- D0 = 模擬第 1 個交易日，D1 = 模擬第 2 個交易日，依此類推。
- 不要把 D0 / D1 理解成市場慣例的當日 / 次日術語。

## 5. 主循環
1. 取得最新可用交易日市場資料。
2. 生成該交易日盤後報告。
3. 根據盤後報告產生買進 / 賣出建議。
4. 下一個交易日用最高 / 最低價模擬是否成交。
5. 更新模擬持倉與績效，持續滾動。

## 6. 非交易日規則
- 週末 / 國定假日不生成新的盤後報告。
- 查詢盤後報告時，顯示最近交易日的報告。
- 若最近交易日摘要尚未生成，系統應補寫該交易日摘要，而不是直接回空。

## 7. handoff 流程
1. 使用者 local 執行 `npm run mo -- pack`。
2. 使用者上傳 `mo_local_latest.zip`。
3. 使用者輸入 `handoff`。
4. AI 必須先比對 repo、文件、規則、已知 bug、未完成功能。
5. AI 補齊可補項，並列出未完成事項。
6. AI 產出新的 handoff 包：`mo_handoff_YYYYMMDD_HHMM.zip`。
7. 新視窗輸入：`讀取檔案中的 MO_START.md 並繼續開發專案`。
