import { spawnSync } from "node:child_process";
import { resolve } from "node:path";
import process from "node:process";

function quoteCmdArg(value) {
  const s = String(value ?? "");
  if (s.length === 0) return '""';
  const needsQuotes = /[\s\t"^&|<>]/.test(s);
  let out = "";
  let backslashes = 0;
  for (const ch of s) {
    if (ch === "\\") {
      backslashes += 1;
      continue;
    }
    if (ch === '"') {
      out += "\\".repeat(backslashes * 2 + 1);
      out += '"';
      backslashes = 0;
      continue;
    }
    out += "\\".repeat(backslashes);
    backslashes = 0;
    out += ch;
  }
  out += "\\".repeat(backslashes * 2);
  if (!needsQuotes) return out;
  return `"${out}"`;
}

function normalizeWindowsCommand(cmd) {
  const raw = String(cmd || "").trim();
  if (!raw) return raw;
  if (/[\\/]/.test(raw) || /\.(cmd|bat|exe)$/i.test(raw)) return raw;
  if (raw === "npm" || raw === "npx") return `${raw}.cmd`;
  return raw;
}

function runWindowsCommand(cmd, args, opts = {}) {
  const comspec = process.env.ComSpec || "cmd.exe";
  const commandLine = [normalizeWindowsCommand(cmd), ...args.map(quoteCmdArg)].join(" ");
  return spawnSync(comspec, ["/d", "/s", "/c", commandLine], {
    stdio: "inherit",
    ...opts,
  });
}

export function runSoft(cmd, args = [], opts = {}) {
  const command = String(cmd || "");
  const argv = Array.isArray(args) ? args.map((v) => String(v)) : [];
  const res = process.platform === "win32"
    ? runWindowsCommand(command, argv, opts)
    : spawnSync(command, argv, { stdio: "inherit", ...opts });
  return {
    status: res.status ?? (res.error ? 1 : 0),
    error: res.error,
  };
}

export function run(cmd, args = [], opts = {}) {
  const r = runSoft(cmd, args, opts);
  if (r.error) throw r.error;
  if (r.status !== 0) throw new Error(`${cmd} failed with exit code ${r.status}`);
}

export function runShell(commandLine, opts = {}) {
  const line = String(commandLine || "");
  if (process.platform === "win32") {
    const comspec = process.env.ComSpec || "cmd.exe";
    return runSoft(comspec, ["/d", "/s", "/c", line], opts);
  }
  const shell = process.env.SHELL || "/bin/sh";
  return runSoft(shell, ["-lc", line], opts);
}

export function nowTag() {
  const d = new Date();
  const pad = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}_${pad(d.getHours())}${pad(d.getMinutes())}`;
}

export function safeGitSha() {
  try {
    const r = spawnSync("git", ["rev-parse", "--short", "HEAD"], { encoding: "utf8" });
    if (r.status === 0) return String(r.stdout).trim() || "nogit";
  } catch {}
  return "nogit";
}

export function openExplorer(targetPath) {
  const p = resolve(String(targetPath));
  if (process.platform !== "win32") return;
  const isZip = /\.zip$/i.test(p);
  const args = isZip ? ["/select,", p] : [p];
  const r = runSoft("explorer.exe", args, { shell: false });
  if (r.status !== 0) console.log(`Explorer opened (exit=${r.status} ignored)`);
}
