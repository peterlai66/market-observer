# Update Process

## 產生本地快照
1. 執行 `npm run mo -- pack`
2. 產生 `.updates/outbox/market-observer_dev_latest.zip`
3. 提供給 AI 做比對或 handoff 前補檔

## 套用 patch
1. 把 `market-observer_patch_latest.zip` 放到 `.updates/inbox/`
2. 執行 `npm run mo -- patch`
3. 套用後封存到 `.updates/bak/`

## 套用 release
1. 把 `market-observer_release_latest.zip` 放到 `.updates/inbox/`
2. 執行 `npm run mo -- update`
3. 套用後封存到 `.updates/bak/`
4. 若有 `src/`、`wrangler.jsonc`、`migrations/` 異動，再執行 `npm run mo -- deploy`

## 目錄契約
- `outbox/`：local pack / patch / release 輸出，僅用檔名區分
- `inbox/`：待套用 zip
- `bak/`：已套用 zip 歸檔
- `repo-backup/`：update / patch 前的 repo 快照
- `work/`：解壓 staging 區
- `history/`：執行紀錄

## smoke validation
- 可執行 `npm run mo -- smoke` 在暫存 repo 驗證 pack / patch / release / update 與 deprecated cleanup。
- 若有 Worker 程式變更，再執行 `npm run mo -- smoke-worker`。
- 正式交付前，若工具鏈有改動，應至少跑一次 smoke 驗證。
