## 2026-03-07
- CLI / scripts toolchain：補回 `mo smoke`、新增 `mo smoke-worker` 入口。
- `mo deploy` / `mo logs` 改為直接走 `npx wrangler ...`，修正 Windows `spawnSync npm.cmd EINVAL`。
- `pack / patch / release` 統一輸出到 `.updates/outbox/`，只靠檔名區分。
- 同步修正文檔，避免 CLI / scripts / 文件不同步。

# HANDOFF NOTES

## 本次 handoff 已補齊
- 修正 `scripts/_util.mjs`：spawn 失敗時不再被誤判成成功。
- `mo deploy` 仍維持走 `npm run deploy`，但因 `_util.run()` 已正確拋錯，Windows 下不再假成功。
- 新增 `scripts/smoke-worker.mjs` 與 `npm run smoke:worker`。
- 同步文件：`MO_START.md`、`docs/PROJECT.md`、`docs/AI_MEMORY.md`、`docs/NEXT_TASK.md`、`developer/SCRIPTS_GUIDE.md`。
- 把 `update / deploy` 分流、D0~D19 定義、非交易日規則寫入文件。

## 目前已知狀態
- local toolchain：`update` / `smoke:tools` 已可用。
- Worker：可 deploy、cron 有跑、watchlist 與 latest_trade_date 可查。
- 線上功能缺口：daily summary、strategy、orders、simulator 尚未完成。

## 仍未完成 / 待下一個 AI 接續
1. `twse_daily_summary` 自動生成：需要對齊 `latest_trade_date`，而不是直接以今天是否開盤判斷。
2. 預設 ETF universe 真正進入策略引擎，解決 `done 0/0`。
3. `mo_orders (PENDING)` 生成與 D0~D19 模擬成交。
4. 若要再修 `mo deploy` UX，可再補上「update 完若需 deploy 的明確提示」。

## 新視窗接續指令
請上傳本 handoff 包，並輸入：

`讀取檔案中的 MO_START.md 並繼續開發專案`
