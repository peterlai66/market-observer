# .updates directory contract

Do not delete folders unless documentation explicitly says it is safe.

## folders
- `inbox/`：等待套用的 patch / release 包
- `work/`：patch / update 解壓工作區
- `bak/`：已套用的 patch / release 歷史
- `repo-backup/`：patch / update 前的備份快照
- `outbox/`：本地 dev / patch / release 輸出，僅用檔名區分用途
- `outbox/bak/`：上一版 latest zip 的歸檔區
- `history/`：patch / update / handoff 執行紀錄

## note
- `backup/` 已 deprecated，不可再新增回來
- 修工具鏈時應優先走 `patch`
- `mo pack` 的預期輸出位置是 `.updates/outbox/market-observer_dev_latest.zip`
- `mo release` 的預期輸出位置是 `.updates/outbox/market-observer_release_latest.zip`
- `mo pack-patch` 的預期輸出位置是 `.updates/outbox/market-observer_patch_latest.zip`
