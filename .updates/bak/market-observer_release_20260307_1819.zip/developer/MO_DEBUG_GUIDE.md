# MO DEBUG GUIDE

## update / patch 自檢
成功時至少要檢查：
- `.updates/repo-backup/` 有新增非空 zip
- `.updates/bak/` 有新增已吃掉的 package
- `.updates/history/` 有新增 json 記錄
- 終端機有成功摘要

若 `VERSION` 改了但上述三者沒有新增，不能視為 update 成功。
