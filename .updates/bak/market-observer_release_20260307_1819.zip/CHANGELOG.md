# Release 0.7.9

本版修正 0.7.8 工具鏈回退問題：
- 補回 `mo smoke` 與 `mo smoke-worker` CLI 入口。
- `mo deploy` / `mo logs` 改回直接走 `npx wrangler ...`，不再經過 `npm run deploy`。
- 保留 Phase 4 第一段的 ETF universe 整合與 recommendation log 功能。
- `scripts/`、`developer/SCRIPTS_GUIDE.md`、`docs/commands.md`、`docs/update_process.md`、`.updates/README.md` 已重新對齊，避免文件顯示有功能但 CLI 實際消失。

驗證：
- `npm run smoke:tools`
- `npm run typecheck`

套用後建議：
1. `npm run mo -- update`
2. `npm run mo -- smoke`
3. `npm run mo -- deploy`

## 0.7.8
- Phase 4：把預設台股 ETF universe 接進多標的策略引擎，推薦邏輯優先在 universe 內挑選，不再只看全市場成交值前幾名。
- 新增 `src/config/universe.ts`，支援內建 universe 與 `MO_UNIVERSE` 環境變數覆寫。
- 新增 `mo_recommendation_log` 自動建表與寫入，保留每批 recommendation 歷史與 latest 標記。
- `daily_mark.note` 會寫入 recommendation 數量，方便線上驗證是否真的有產生建議。

## 0.7.5-handoff
- fix(toolchain): `_util.run()` now throws on process spawn errors.
- feat(toolchain): add `smoke:worker` and document when to run it.
- docs(handoff): sync deploy flow, D0~D19 semantics, current runtime status, unresolved items.

# 0.6.9

- Fix: `smoke:tools` now reuses source `node_modules` instead of running nested `npm install` in the sandbox, avoiding Windows npm CLI failures.

# 0.6.8

- Add toolchain smoke test script for pack / patch / release / update workflow.
- Fix doctor success output and patch cleanup import.
- Normalize generated zip entry paths for cross-platform compatibility.

# 0.5.4

- Fix: TWSE not-ready no longer blocks order generation; avoid clearing seeded PENDING orders when snapshot missing.
- Fix: Correct index direction using TWSE sign.

# Changelog

## v0.4.2-hotfix.1 — TWSE trade date fallback

- Fixed: When TWSE FMTQIK has no trade date (or API returns empty/changed schema), treat as NOT READY instead of throwing hard error. Writes status into mo_daily_mark.
## v0.4.2 (2026-03-05)

### Added
- D1 runtime audit tables (via migration `0005_add_runtime_audit_tables.sql`)
  - `mo_tick_audit` (tick dispatcher audit + de-dupe lock)
  - `mo_daily_mark` (daily market-data readiness + push markers)
  - `mo_execution_mark` (simulation / execution audit)

### Improved
- Tick dispatcher writes audit rows to `mo_tick_audit` and skips duplicates safely.
- `mo status` shows **health** by reading the latest audit rows from remote D1.

### Changed
- Cron trigger switched to a **global 15-minute heartbeat**: `*/15 * * * *` (market logic stays in code).

## 0.6.1
- 修正 mo pack / mo update 的命名與流程語意
- `mo pack` 改為輸出 `.updates/outbox/mo_local_latest.zip`
- `mo update` 對齊 `.updates/inbox/market-observer_release_latest.zip` → `.updates/bak/` → `.updates/work/` 流程
- 新增 `manifest.json`、`VERSION`、`docs/update_process.md`、`docs/setup.md`
- handoff 規則明確化：AI 需比對聊天室規則與 repo 差異後再產出 `mo_handoff*.zip`
