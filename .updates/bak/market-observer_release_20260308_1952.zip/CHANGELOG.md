## 0.11.6 recommendation scoreboard
- 新增 `mo recommendation-scoreboard`，可彙總已落表的 recommendation review batch / item 統計。
- 輸出包含 total_batches、total_symbols、filled/skipped/pending orders、skip_ratio、filled_ratio，以及 latest batch 概況。

## 0.11.5
- 修正 `recommendation-review-save` 在 Windows / cmd 環境下以 `--command` 傳多行 SQL 造成 Wrangler 判定缺少 `--command` 的問題。
- `execSql()` 現在會先將 SQL 正規化為單行再送給 `wrangler d1 execute`。

## 0.11.3
- 新增 `mo recommendation-review-save`，把最新推薦批次 review 結果落表到 D1。
- 自動建立 `mo_recommendation_review_batches`、`mo_recommendation_review_items`。
- 為後續 scoreboard / 命中率統計建立正式 snapshot 基線。

## 0.11.3
- `mo recommendation-review` 輸出強化：新增 `max_review_horizon`、`available_checkpoints`、`pending_checkpoints`，並明確區分 `not-enough-trade-days`、`missing-close`、`signal-generated-but-not-filled`。

# Changelog

## 0.11.1
- feat(review): 新增 `scripts/recommendation-review.mjs` 與 `mo recommendation-review`，回看最新推薦批次在 D0 / D5 / D10 / D20 的模擬表現。
- docs(scope): 明確校正 MO 為推薦驗證系統，不將模擬資料層誤解為實盤交易系統。
- docs(tooling): 同步更新 `MO_START.md`、`docs/PROJECT.md`、`docs/AI_MEMORY.md`、`docs/NEXT_TASK.md`、`docs/BUGS.md`、`docs/FUTURE_SYSTEMS.md`、`docs/commands.md`、`developer/SCRIPTS_GUIDE.md`。
