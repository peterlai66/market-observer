#!/usr/bin/env node
import { readFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';

const __dirname = dirname(fileURLToPath(import.meta.url));
const root = resolve(__dirname, '..');
const mode = (process.argv[2] || 'remote').trim().toLowerCase();
const remote = mode !== 'local';
const explicitDate = (process.argv[3] || '').trim();

function stripJsonComments(input) {
  return input
    .replace(/\/\*[\s\S]*?\*\//g, '')
    .replace(/(^|[^:\\])\/\/.*$/gm, '$1');
}

function stripTrailingCommas(input) {
  return input.replace(/,(\s*[}\]])/g, '$1');
}

function parseJsonc(input) {
  return JSON.parse(stripTrailingCommas(stripJsonComments(input)));
}

function loadDbName() {
  const raw = readFileSync(resolve(root, 'wrangler.jsonc'), 'utf-8');
  const cfg = parseJsonc(raw);
  const db = cfg?.d1_databases?.[0]?.database_name;
  if (!db) throw new Error('Cannot resolve D1 database_name from wrangler.jsonc');
  return String(db);
}

function spawnCapture(cmd, args = []) {
  const isWin = process.platform === 'win32' && (cmd === 'npx' || cmd === 'npm' || /\.(cmd|bat)$/i.test(cmd));
  const finalCmd = isWin ? 'cmd.exe' : cmd;
  const finalArgs = isWin ? ['/d', '/s', '/c', cmd, ...args] : args;
  return spawnSync(finalCmd, finalArgs, {
    cwd: root,
    encoding: 'utf8',
    stdio: ['ignore', 'pipe', 'pipe'],
    shell: false,
  });
}

function runQuery(sql) {
  const database = loadDbName();
  const args = ['wrangler', 'd1', 'execute', database, remote ? '--remote' : '--local', '--json', '--command', sql];
  const res = spawnCapture('npx', args);
  if ((res.status ?? 1) !== 0) {
    process.stdout.write(res.stdout || '');
    process.stderr.write(res.stderr || '');
    throw new Error(`wrangler d1 execute failed (${remote ? 'remote' : 'local'})`);
  }
  const txt = String(res.stdout || '').trim();
  if (!txt) return [];
  const parsed = JSON.parse(txt);
  if (Array.isArray(parsed)) return Array.isArray(parsed[0]?.results) ? parsed[0].results : parsed;
  return Array.isArray(parsed?.results) ? parsed.results : [];
}


function tableColumns(table) {
  const rows = runQuery(`PRAGMA table_info(${table});`);
  return new Set(rows.map((r) => String(r.name || '').trim()).filter(Boolean));
}
function getStr(obj, keys) {
  for (const k of keys) {
    const v = obj?.[k];
    if (v == null) continue;
    const s = String(v).trim();
    if (s) return s;
  }
  return '';
}

function getNum(obj, keys) {
  for (const k of keys) {
    const v = obj?.[k];
    if (v == null) continue;
    const n = Number(String(v).replace(/,/g, '').trim());
    if (Number.isFinite(n)) return n;
  }
  return NaN;
}

function parseTwsePayload(raw) {
  try {
    const payload = JSON.parse(String(raw || 'null'));
    if (Array.isArray(payload)) return payload;
    if (Array.isArray(payload?.data)) return payload.data;
    for (const value of Object.values(payload || {})) {
      if (Array.isArray(value)) return value;
    }
    return [];
  } catch {
    return [];
  }
}

function buildCloseMap(rows) {
  const m = new Map();
  for (const r of rows) {
    const code = getStr(r, ['證券代號', 'Code', 'code', 'StockCode']);
    const close = getNum(r, ['收盤價', 'Close', 'close', '收盤', 'ClosingPrice', 'lastPrice', 'LastPrice']);
    if (code && Number.isFinite(close) && close > 0) m.set(code, close);
  }
  return m;
}

function pct(base, px) {
  if (!Number.isFinite(base) || base <= 0 || !Number.isFinite(px) || px <= 0) return NaN;
  return ((px / base) - 1) * 100;
}

function fmtPct(v) {
  return Number.isFinite(v) ? `${v >= 0 ? '+' : ''}${v.toFixed(2)}%` : '—';
}

function fmtPrice(v) {
  return Number.isFinite(v) ? v.toFixed(2) : '—';
}

function fail(msg) {
  console.error(`❌ ${msg}`);
  process.exit(1);
}

console.log(`MO Recommendation Review (${remote ? 'remote' : 'local'})`);

const latestRows = explicitDate
  ? [{ trade_date: explicitDate }]
  : runQuery("SELECT trade_date FROM mo_recommendation_log WHERE rec_count > 0 ORDER BY trade_date DESC, id DESC LIMIT 1;");
if (!latestRows.length) fail('no recommendation batch found');
const tradeDate = String(latestRows[0].trade_date || explicitDate || '').trim();
if (!tradeDate) fail('cannot resolve review trade_date');

const moOrderCols = tableColumns('mo_orders');
for (const required of ['signal_date','symbol','side','entry_low','entry_high','qty','status']) {
  if (!moOrderCols.has(required)) fail(`mo_orders missing required column: ${required}`);
}
const optionalName = moOrderCols.has('name') ? 'name,' : "'' AS name,";
const optionalReason = moOrderCols.has('reason') ? 'reason,' : "'' AS reason,";
const recRows = runQuery(`SELECT signal_date, symbol, ${optionalName} side, entry_low, entry_high, qty, ${optionalReason} status FROM mo_orders WHERE signal_date='${tradeDate}' AND side='BUY' ORDER BY symbol;`);
if (!recRows.length) fail(`no BUY recommendations found for ${tradeDate}`);

const rawRows = runQuery(`SELECT date, payload_json FROM twse_daily_raw WHERE date>='${tradeDate}' ORDER BY date ASC LIMIT 30;`);
if (!rawRows.length) fail(`no twse_daily_raw snapshots found on/after ${tradeDate}`);

const tradingDates = rawRows.map((r) => String(r.date || '').trim()).filter(Boolean);
const closeByDate = new Map();
for (const row of rawRows) {
  const d = String(row.date || '').trim();
  closeByDate.set(d, buildCloseMap(parseTwsePayload(row.payload_json)));
}

const checkpoints = [0, 5, 10, 20];
const lines = [];
lines.push(`trade_date=${tradeDate}`);
lines.push(`review_universe=${recRows.length} symbols`);
lines.push(`available_trade_dates=${tradingDates.length} (${tradingDates[0]} -> ${tradingDates[tradingDates.length - 1]})`);
lines.push('');
lines.push('symbol | base | D0 | D5 | D10 | D20 | status');

const d20Returns = [];
for (const row of recRows) {
  const symbol = String(row.symbol || '').trim();
  const name = String(row.name || '').trim();
  const entryLow = Number(row.entry_low);
  const entryHigh = Number(row.entry_high);
  const base = Number.isFinite(entryLow) && Number.isFinite(entryHigh) && entryLow > 0 && entryHigh > 0
    ? (entryLow + entryHigh) / 2
    : NaN;

  const review = [];
  for (const cp of checkpoints) {
    const d = tradingDates[cp];
    const close = d ? closeByDate.get(d)?.get(symbol) : NaN;
    review.push(`${cp === 0 ? 'D0' : `D${cp}`} ${fmtPct(pct(base, close))}`);
    if (cp === 20) {
      const r = pct(base, close);
      if (Number.isFinite(r)) d20Returns.push(r);
    }
  }

  lines.push(`${symbol}${name ? ` ${name}` : ''} | base=${fmtPrice(base)} | ${review.join(' | ')} | ${String(row.status || '').trim() || '—'}`);
}

lines.push('');
if (d20Returns.length) {
  const avg = d20Returns.reduce((a, b) => a + b, 0) / d20Returns.length;
  const winRate = (d20Returns.filter((x) => x > 0).length / d20Returns.length) * 100;
  lines.push(`D20 summary avg=${fmtPct(avg)} win_rate=${winRate.toFixed(1)}% samples=${d20Returns.length}`);
} else {
  lines.push('D20 summary skipped (insufficient future trade dates or missing closes)');
}

console.log(lines.join('\n'));
console.log('Recommendation review OK');
