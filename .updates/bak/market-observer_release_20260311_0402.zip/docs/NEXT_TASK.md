> Current packaged baseline: 0.18.3

## 0.18.1 next
- 驗證 `/admin/run?force=1` 的 legacy / FinMind log 是否同時輸出 `anchor`、`anchor_plus_one`、`probes`。
- 驗證 legacy 與 FinMind 的 probe list 是否完全一致，且順序為 `anchor+1, anchor, anchor-1, anchor-2`。
- 驗證 3/11 凌晨情境下 tradeDate 是否能前進到 3/10；若 primary sources 仍晚於 backstop，再評估是否加入交易日曆判定。

## 0.18.0 next
- 驗證 `/admin/run?force=1` 的 legacy probe 是否變成 `anchor+1, anchor, anchor-1, anchor-2`，例如 2026-03-10, 2026-03-09, ...
- 驗證 FinMind log 是否改為 `TaiwanStockTradingDate`，且免費/權限不足時只標示 unavailable，不再導致 mismatch spread。
- 驗證 3/11 凌晨情境下 tradeDate 是否能前進到 3/10；若 TWSE 與 backstop 仍不同步，再評估加入交易日曆判定。

## 0.17.8 next
- Verify remote `/admin/run?force=1` now keeps legacy MI_INDEX probes anchored around the primary consensus date instead of probing the current day first.
- Confirm legacy backstop only advances tradeDate by one day when `MI_INDEX_LEGACY` returns a date exactly one day newer than the freshest primary source.

## 0.17.7 next
- Verify remote `/admin/run?force=1` now resolves FMTQIK to the latest date (not the first row) and uses legacy MI_INDEX probes only when they are fresher than OpenAPI.
- Confirm `mo pack` / `mo release` include newly added root files without having to manually update per-script file lists.

# NEXT TASK

- 驗證 Cloudflare logs 中 AI 呼叫是否固定顯示 `model=gpt-4o-mini`。
- 驗證 `mo_ai_audit` 是否正確記錄成功 / timeout / disabled 三種狀態。
- 下一輪聚焦：將 FMTQIK tradeDate 解析改為取最新日期而非首筆日期。

# NEXT TASK

- 驗證 LINE `report / 最新報告 / 本週報告` 是否已回傳最新 cycle/review 狀態，而非只顯示舊的 `twse_daily_summary`。
- 開始設計 0.17.x 的 operator narration / GPT explain layer，讓最新 operator report 能轉成 LINE 友善說明。
- 下一輪聚焦：把最新 operator report 主動投遞到 LINE，而不只提供查詢。

## 0.16.1
- recommendation-review-save now respects review-side fill fallback when SIM_FILL_POLICY=RANGE_OR_CLOSE, promoting eligible D0 range misses into executed review samples for scoreboard accumulation.

# NEXT TASK

- 驗證 `SIM_FILL_POLICY=RANGE_OR_CLOSE` 是否開始產生第一批 `EXECUTED` 樣本。
- 若第一批 executed sample 仍不足，再評估是否切到 `NEXT_OPEN` 或放寬 entry range。
- 在 scoreboard 補一層 executed sample accumulation / first-fill milestone。

- 追蹤 execution gate breakdown，確認主要阻塞是否為價格區間未觸發、資金不足或交易門檻。
- 依 execution:* 結果決定是否調整 simulated fill policy 或 entry range。

## 0.14.9 next target
- Continue extending TW future trade-date coverage so D5 / D10 / D20 unlock naturally after D0.
- Add execution-gate diagnostics for `signal-generated-but-not-filled` once coverage is no longer the primary blocker.
- Keep using the locked release baseline workflow for every new AI development round.

## 0.14.8 next target
- P1 TW price backfill repair: backfill missing `00757.TW` / `00919.TW` history into `prices_daily` and extend `00878.TW` beyond 2026-03-02.
- Add a dedicated CLI diagnostic to print `prices_daily` coverage gaps by symbol/date before weekly simulation runs.
- Keep review items canonical-only (`.TW`) and add one-shot cleanup for historical bare-symbol duplicates still remaining in remote D1.


## 0.14.4
- Daily cycle engine foundation is in place.
- `src/index.ts` now tracks `mo_cycle_state`, extends retry window to next-day open, and allows recommendation/simulation bootstrap before report push finishes.
- LINE now supports `ai 狀態` / `ai 報告` / `ai 建議` for GPT explanation.
- Verify with `npm run mo -- doctor`, `npm run typecheck`, deploy, then LINE `狀態`, `建議`, `ai 狀態`.

Next target: 0.14.5 cycle scoreboard + actionable / report_only tracking in CLI status and review outputs.

## 0.14.2
- Added weekly operator message layer for report payload shaping and publish-ready messaging.

## 0.13.9
- Operator final decision summary
- `mo recommendation-scoreboard` now prints `operator_final_decision_summary`, `operator_final_decision_findings`, and `operator_final_decision_actions`.
- Verify with `npm run mo -- doctor` then `npm run mo -- recommendation-scoreboard`.

Next target: 0.14.0 operator execution checklist
## 0.13.7
- Full Pipeline Readiness Summary
- `mo recommendation-scoreboard` now prints `pipeline_readiness_summary`, `pipeline_readiness_findings`, and `pipeline_readiness_actions`.
- Verify with `npm run mo -- doctor` then `npm run mo -- recommendation-scoreboard`.

Next target: 0.13.7 execution validation unlock checks


- 0.14.2: added weekly_delivery_formatting_summary / weekly_delivery_formatting_blocks / weekly_delivery_formatting_actions for LINE/email/log payload shaping.

## after 0.14.8
1. 驗證 `recommendation-review-save` 是否成功回填 00757.TW / 00919.TW / 00878.TW 的 2026-03 月 close rows。
2. 若 D0 已解鎖，持續累積未來交易日，觀察 D5 / D10 何時解鎖。
3. 若 TWSE monthly endpoint 對部分 ETF 無資料，補第二來源 backfill。

- [done] tradeDate engine 已加入 FinMind backstop 與 legacy forward probe；下一步觀察 3/10/3/11 凌晨是否能自動前推。
- [done] 最新報告日期選擇已改為優先看最新 cycle / recommendation / summary，避免被舊 review batch 壓回舊日期。
