This directory stores MO update, release, patch, backup, and handoff artifacts.
