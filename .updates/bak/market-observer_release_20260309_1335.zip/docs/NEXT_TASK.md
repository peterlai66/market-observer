Next target: 0.13.7 execution validation unlock checks
