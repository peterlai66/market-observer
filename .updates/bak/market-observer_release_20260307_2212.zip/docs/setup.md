## AI explain layer
- 在 `wrangler.jsonc` 或 Cloudflare vars 設 `AI_ENABLED=1`
- 建議 model：`gpt-5-mini`
- 用 Wrangler secret 設定 `OPENAI_API_KEY`
- 啟用後可在 LINE 輸入：`解釋狀態`、`解釋報告`、`解釋建議`

# Setup

## 初始化
1. `npm install`
2. 建議使用 `npm run mo -- doctor`

## 常用操作
- `npm run mo -- pack`
- `npm run mo -- patch`
- `npm run mo -- release`
- `npm run mo -- update`

## 說明
- 若是修工具鏈，優先使用 `patch`
- 若是完整進版，使用 `update`
