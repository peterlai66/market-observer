## 0.11.0 update
- MO 新增 GPT 解釋層第一階段：AI 只做說明，不做交易決策。
- LINE 現可查詢 `解釋狀態 / 解釋報告 / 解釋建議`，用自然語言說明系統是否正常運作、為何沒有交易、目前候選單在等什麼。
- AI 解釋層吃的是 D1 內既有結構資料，不碰 web，不自行補新聞，避免幻覺影響判斷。

## 0.10.0 update
- MO 已進入成交閉環第一階段：strategy output 不只會產生 `mo_orders`，也會在 recommendation 與 execution 兩端做成本感知過濾。
- 新增交易守門概念：`minQty`、`minNotionalTwd`、`roundTripCost`、`edge_lt_cost`。
- 目前 TW ETF 採保守規則：先過成本與最小量門檻，再進入 PENDING / EXECUTED / SKIPPED 流程。

# PROJECT

## Current state
- CLI / update / smoke / deploy pipeline stable
- ETF universe comes from env -> D1 -> default fallback
- Multi-asset engine now generates candidates from universe snapshots
- 0.9.0 adds conservative starter fallback so the system can move from pure observation to actionable recommendations
- LINE commands for operational verification: 狀態 / 建議 / debug / universe

- 0.9.1: final recommendation close-price mapping now resolves TW ETF prices from raw close, OHLC fallback, and candidate fallback before rejecting for invalid close.
