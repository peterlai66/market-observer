# Market Observer v0.7.0

- `mo update` auto-detects the newest `market-observer_release*.zip` in `.updates/inbox`; no manual rename is required.
- `mo patch` auto-detects the newest `market-observer_patch*.zip` in `.updates/inbox`.
- Keep typed outbox structure (`outbox/dev`, `outbox/patch`, `outbox/release`) and document the matching inbox contract for consistent package handling.
- Ignore `mo_handoff*.zip` and `mo_local*.zip` during local patch / update flows.

# Market Observer v0.6.9

- Make `smoke:tools` Windows-safe by reusing the source repo `node_modules` instead of calling nested `npm install` in the temp sandbox.
- Use `node` from the current runtime for smoke steps, create `.updates/inbox` during sandbox setup, and fail fast with a clear message when local dependencies are missing.

# Market Observer v0.6.8

- Add `scripts/smoke-tools.mjs` and `npm run smoke:tools` to verify `mo pack` / `mo patch` / `mo update` end-to-end in a temp repo.
- Fix `scripts/doctor.mjs` success output so the script exits cleanly.
- Fix `scripts/apply-patch.mjs` missing `rmSync` import during deprecated cleanup.
- Replace ZIP creation with `archiver` to normalize entry paths and avoid Windows-created packages storing backslashes in zip entries.
- Keep deprecated `.updates/backup` cleanup covered by smoke verification for both patch and update flows.

# Market Observer v0.6.7-handoff

- Align `mo pack` output path to `.updates/outbox/dev/mo_local_latest.zip`.
- Extend `.updates` contract to include `outbox/dev` and `outbox/handoff`.
- Add deprecated cleanup for `.updates/backup` after successful patch / update.
- Strengthen handoff rule: compare, fill gaps, record unfinished items, then generate a new handoff package.
- Synchronize `MO_START.md`, `docs/PROJECT.md`, `docs/AI_MEMORY.md`, `docs/NEXT_TASK.md`, `docs/update_process.md`, `developer/SCRIPTS_GUIDE.md`, and `.updates/README.md`.

# Market Observer v0.5.5 (hotfix)

- Fixes premature post_close_done marking: post-close is marked done only after today's summary exists and is non-empty.
- Allows push-only placeholder at 16:00 even when summary is not ready, while keeping post-close retry active every 15 minutes.

# Market Observer v0.5.4 (stable)

- Orders generation no longer aborts when TWSE "not ready"; summary may skip but strategy/simulation can continue.
- Prevents wiping existing PENDING orders when no TWSE stock snapshot is available.
- Fixes index up/down direction by applying TWSE sign to change points.

# Market Observer v0.4.2-hotfix.1

- TWSE FMTQIK trade date missing no longer crashes daily process.
- Mark daily readiness into mo_daily_mark and skip until ready.

# Market Observer Release Notes

## 0.0.0 (2026-03-04 19:44)  [1e0b808]

### Other
- auto 20260304_1709
- Initial commit (by create-cloudflare CLI)

## 2026-03-04  Dev Tools Baseline

### Add
- `scripts/` dev tools
- `npm run pack:dev` / `npm run pack:release`
- `npm run send` (typecheck → commit → pack:dev → open artifacts)
- `npm run quick` (typecheck → deploy → tail)
- `npm run doctor` (check node/npm/wrangler/git + wrangler bindings)

### Notes
- Packaging includes: `src/`, `scripts/`, `migrations/`, `wrangler.jsonc`, `package.json`, `tsconfig.json`, `README.md`, `RELEASE_NOTES.md`

---

## 0.4.2 (2026-03-05)

### Added
- D1 runtime audit tables (migration `0005_add_runtime_audit_tables.sql`)
  - `mo_tick_audit`: tick dispatcher audit + de-dupe lock
  - `mo_daily_mark`: daily market-data readiness + push markers
  - `mo_execution_mark`: simulation / execution audit

### Improved
- Tick dispatcher writes audit rows and safely skips duplicate ticks.
- `mo status` includes health summary pulled from remote D1.

### Changed
- Cron trigger switched to global heartbeat: `*/15 * * * *`
