# MO_START

這是 **Market Observer (MO)** 專案的唯一入口文件。

本文件不是一般說明，而是 **AI Runtime Spec / 專案執行規格**。  
任何 AI 接手本專案時，**必須先完整閱讀本文件，再開始任何修改**。

如果 AI 沒有先讀完本文件就開始修改程式，視為違反專案規則。

---

## 0. 核心原則（先讀）

### AI 必須遵守
- **先讀文件，再改程式**
- **先理解既有架構，再接續開發**
- **所有架構 / 功能 / 流程 / 目錄 / 檔案變更，都必須同步更新文件**
- **一般交付一律提供可透過 `mo update` 套用的 release zip**
- **修工具鏈時優先走 `mo patch`**
- **只有使用者明確輸入 `handoff` 時，才進入交接流程並產出 handoff 包**
- **`mo pack` 是 local 最新快照，不是 handoff 包**

### AI 不可做的事
- 未讀完文件就開始修改程式
- 未更新文件就修改流程、目錄、檔案、指令
- 把 `mo pack` 誤認為 handoff 完成品
- 把使用者上傳的 local pack 直接改名後交回，當成 handoff 包
- 用 `update` 去修 `update` 本身
- 在不記錄原因的情況下刪除系統目錄或重要檔案

### 若 AI 不確定
- **停止修改**
- 明確說明不確定點
- 等待使用者確認

---

## 1. AI 接手時的強制閱讀順序（不可跳）

當使用者說：

> 請依照 `MO_START.md` 接續開發專案

AI 必須先依序閱讀：

1. `MO_START.md`
2. `docs/PROJECT.md`
3. `docs/AI_MEMORY.md`
4. `docs/NEXT_TASK.md`
5. `developer/SCRIPTS_GUIDE.md`

必要時再閱讀：

6. `docs/AI_CONTEXT.md`
7. `developer/MO_DEBUG_GUIDE.md`
8. `docs/update_process.md`
9. `docs/setup.md`

**在完全理解上述文件前，不得修改任何程式碼。**

---

## 2. 唯一入口與唯一操作規則

### 唯一入口文件
- `MO_START.md`

### 唯一人工操作入口
- `mo` CLI

目前建議使用：

```bash
npm run mo -- <command>
```

未來若工具鏈收斂，可改為：

```bash
npx mo <command>
```

### 唯一流程原則
- **patch**：修工具鏈與文件
- **update**：完整專案更新
- **release**：正式交付 update 包
- **handoff**：聊天中的交接指令，不是本地 CLI 指令

---

## 3. 開發流程（固定，不可重發明）

### 一般開發
1. 使用者上傳 local 打包檔或指定目前 repo 狀態
2. AI 先讀 `MO_START.md`
3. AI 再讀其他規定文件
4. AI 依既有架構接續開發
5. 一般交付提供 **release zip**
6. 使用者在 local 執行 `mo update`

### 修工具鏈
1. AI 修改 `scripts / docs / developer / MO_START`
2. AI 提供 **patch zip**
3. 使用者在 local 執行 `mo patch`
4. 工具鏈更新完成後，再進行 `update / release`

### 交接（handoff）
1. 使用者先在 local 執行 `mo pack`
2. 使用者上傳 local pack
3. 使用者在聊天中輸入 `handoff`
4. AI 必須依 handoff 規則處理（見第 8 節）
5. AI 產出新的 handoff 包
6. 新視窗輸入：`請依照 MO_START.md 接續開發專案`

---

## 4. Package / 命名規則（固定）

### `mo pack`
- 用途：把 **local 最新狀態** 交給 AI 分析 / 接手
- 不是 handoff 包
- 預期輸出：

```text
.updates/outbox/dev/mo_local_latest.zip
```

### `mo patch`
- 入口：

```text
.updates/inbox/market-observer_patch_latest.zip
```

- 用途：只更新工具鏈與文件

### `mo update`
- 入口：

```text
.updates/inbox/market-observer_release_latest.zip
```

- 用途：完整專案更新

### handoff 包
- 只有 AI 在聊天 `handoff` 流程中產出
- 檔名：

```text
mo_handoff_latest.zip
```

### 版本來源
- `_latest.zip` 只是入口 alias
- 實際版本以：
  - `VERSION`
  - `manifest.json`
  - `RELEASE_NOTES.md`
  為準

---

## 5. `.updates/` 目錄 contract（強制）

```text
.updates/
  README.md
  inbox/
  outbox/
    bak/              ← legacy root artifact archive
    dev/
      bak/
    patch/
      bak/
    release/
      bak/
    handoff/
      bak/
  bak/
  work/
  history/
  repo-backup/
```

### 用途定義
- `inbox/`：等待套用的 patch / release 入口包
- `outbox/dev/`：`mo pack` 的 local 開發快照輸出
- `outbox/patch/`：本地 patch 包輸出
- `outbox/release/`：本地 release 包輸出
- `outbox/handoff/`：handoff 包輸出
- `outbox/bak/`：legacy root archive；保留但不應新增新的 dev pack 到此處
- `bak/`：`mo patch / mo update` 已吃掉的封存包
- `work/`：`mo patch / mo update` 解壓工作區
- `history/`：`mo patch / mo update / handoff` 的歷程紀錄
- `repo-backup/`：`mo patch / mo update` 前的備份快照

### deprecated
以下目錄為 deprecated，應在適當版本清理：

```text
.updates/backup
```

### 重要規則
AI 不可任意修改 `.updates/` 結構。  
若有新增 / 刪除 / 改名，必須同步更新：

- `MO_START.md`
- `docs/PROJECT.md`
- `docs/update_process.md`
- `developer/SCRIPTS_GUIDE.md`
- `RELEASE_NOTES.md`
- `.updates/README.md`

---

## 6. `mo patch` / `mo update` 規則（固定）

### `mo patch`
只更新工具鏈與文件，範圍限於：

- `scripts/`
- `docs/`
- `developer/`
- `MO_START.md`
- `VERSION`
- `RELEASE_NOTES.md`
- `.updates/README.md`
- 必要時 `package.json`（若 CLI / scripts 有異動）

**patch 不應動到：**
- `src/`
- `migrations/`

### `mo update`
用於完整專案更新。

### `patch / update` 共同流程
兩者都必須：

1. 檢查 `inbox` 入口 zip 是否存在
2. 建立 `repo-backup`
3. 驗證 backup 存在且非空
4. 先清空 `.updates/work/`
5. 解壓到 `.updates/work/`
6. 驗證 work 非空
7. 套用檔案到 repo root
8. 成功後才把 zip 移到 `.updates/bak/`
9. 寫入 `.updates/history/` 紀錄
10. 若有 deprecated 目錄清理規則，於成功後執行 cleanup

### 失敗規則
若失敗：
- `inbox` 內原始 zip 必須保留供重試
- 不可出現「表面成功、實際 backup 為空」的假成功

---

## 7. `mo pack` 規則（明確）

`mo pack` 的責任只有一件事：

> 把目前 local 最新狀態打包給 AI 使用

### `mo pack` 不是：
- handoff 包
- release 包
- patch 包

### `mo pack` 的預期輸出：
```text
.updates/outbox/dev/mo_local_latest.zip
```

若腳本輸出位置與本文件不一致，視為 **工具鏈與規格不一致**，必須修正並記錄。

---

## 8. handoff 正式流程（最重要）

當使用者在聊天中輸入：

```text
handoff
```

且附上 local 打包檔時，AI **必須**：

### Step 1：檢查附件
- 檢查是否有附 local 打包檔
- 若沒有，必須明確要求使用者補上
- 不可跳過這一步

### Step 2：讀取並比對
AI 必須讀取附件內容，並比對：

- `MO_START.md`
- `docs/PROJECT.md`
- `docs/AI_MEMORY.md`
- `docs/NEXT_TASK.md`
- `developer/SCRIPTS_GUIDE.md`
- 本聊天室中已定義的規則、架構、功能、流程、bug 修正點

### Step 3：補齊缺失
AI 必須把以下缺失補齊後，才能交付 handoff：

- 缺少但應存在的文件
- 已討論但未落地的規則
- 已確定但未同步的腳本修正
- 目錄 contract 不一致
- 文件與實作不一致
- release / patch / update / handoff 流程缺漏

### Step 4：記錄未完成項
若有本次來不及完成的內容，AI 必須明確記錄到 handoff 文件，包含：

- 未完成功能
- 未修 bug
- 已知風險
- 下個 AI 的優先處理順序

### Step 5：產生新的 handoff 包
AI 必須產出：

```text
mo_handoff_latest.zip
```

這個 handoff 包 **不是使用者上傳的 local pack 改名**，而必須是：

- 經過比對後的 repo
- 已補齊缺失
- 已加入 handoff 記錄
- 可供下一個 AI 直接接手的交接包

### Step 6：提醒下一個 AI 的啟動語句
AI 必須明確提醒：

```text
請在新視窗輸入：請依照 MO_START.md 接續開發專案
```

---

## 9. 文件維護規則（強制，不可省略）

只要有修改，就必須同步更新相關文件。  
**沒有更新文件的程式變更，視為未完成。**

### 修改類型 → 必須更新文件

- 架構／流程改動 → `docs/PROJECT.md`
- 重要決策／里程碑 → `docs/AI_MEMORY.md`
- 下一步開發方向 → `docs/NEXT_TASK.md`
- 指令／腳本變動 → `developer/SCRIPTS_GUIDE.md`
- 更新流程改動 → `docs/update_process.md`
- 安裝或初始化改動 → `docs/setup.md`
- 除錯流程改動 → `developer/MO_DEBUG_GUIDE.md`
- 版本變更 → `RELEASE_NOTES.md`
- 目錄結構、重要檔案新增刪除 → `MO_START.md` + `docs/PROJECT.md` + `RELEASE_NOTES.md`

### 補充規則
若修改的是：
- `scripts/`
- `package.json`
- `.updates/`
- `mo` CLI 行為

則至少必須同步更新：
- `developer/SCRIPTS_GUIDE.md`
- `docs/update_process.md`
- `RELEASE_NOTES.md`

---

## 10. AI 自檢清單（交付前必查）

AI 在任何交付前，必須自行檢查：

1. 是否已讀完必要文件
2. 是否遵守 `.updates/` contract
3. 是否把已討論的規則落地
4. 是否同步更新文件
5. 是否記錄版本或變更
6. 若是 handoff，是否有：
   - 比對
   - 補齊
   - 未完成項記錄
   - 重新打包

若任一項未完成，視為 **不可交付**。

---

## 11. 最終責任

任何 AI 修改本專案，必須確保：

- 專案架構清楚
- 流程權責分明
- 文件與程式一致
- `.updates` 結構可持續運作
- handoff 後下一個 AI 可以直接接續，而不是重新開始

若沒有做到，視為本次交付未完成。


## AI Code Delivery Rules
- AI 不得要求使用者手動建立或修改多檔程式碼。
- 程式碼修改一律以 release / patch / handoff 包交付。
- `.updates/inbox` 接受 `market-observer_release*.zip` 與 `market-observer_patch*.zip`，使用者不需 rename。
- 本地 `mo update` / `mo patch` 會忽略 `mo_handoff*.zip` 與 `mo_local*.zip`。
