# NEXT TASK

1. 在使用者 local（Windows 11）實測 `market-observer_release*.zip` / `market-observer_patch*.zip` 直接放入 `.updates/inbox/` 後，可不 rename 完成 `mo update` / `mo patch`。
2. 視需要補 `smoke:worker` 與 `pre-release` gate，讓 Worker 與工具鏈一起驗證。
3. 評估 handoff 包是否也要建立對應的本地驗證腳本或 manifest 規則。
4. 若後續有多個 inbox 套件共存的需求，再決定是否加入明確優先序或互斥檢查。
