# PROJECT

## 專案定位
Market Observer (MO) 是以 **Cloudflare Workers + D1 + TWSE OpenAPI + LINE** 為核心的盤後市場觀察與建議系統。

## AI 協作原則
- `MO_START.md` 是唯一入口文件
- 新 AI 接手必須先讀文件，不可從零猜測專案結構
- 架構、流程、目錄 contract 一旦修改，必須同步更新文件並留痕
- 任何程式修改若未同步更新文件，視為未完成
- handoff 必須先比對、補齊、記錄未完成項，再產生新的 handoff 包

## Runtime 架構
1. **MO CLI / Update System**
2. **Data Layer**：TWSE（MI_INDEX / FMTQIK / STOCK_DAY_ALL）
3. **Reliability Layer (D0)**：tradeDate quorum、schema guard、mismatch guard
4. **Feature / Recommendation Layer**
5. **Personal Portfolio Layer**
6. **Personal Risk Control Layer**
7. **Opportunity Analyzer**
8. **Notification Layer**

## `.updates` 正式結構
```text
.updates
├ README.md
├ inbox
├ work
├ bak
├ repo-backup
├ outbox
│  ├ bak
│  ├ dev
│  │  └ bak
│  ├ patch
│  │  └ bak
│  ├ release
│  │  └ bak
│  └ handoff
│     └ bak
└ history
```

### 說明
- `backup/` 已 deprecated，應由 patch / update cleanup 移除
- `outbox/` 與 `history/` 都是正式結構的一部分，不可當成無用資料夾刪除
- `patch` 與 `update` 共用 `.updates/work`、`.updates/bak`、`.updates/history`、`.updates/repo-backup`
- `mo pack` 的標準輸出位置為 `.updates/outbox/dev/mo_local_latest.zip`

## CLI 原則
所有人工操作都優先透過 `mo`：
- `npm run mo -- doctor`
- `npm run mo -- logs`
- `npm run mo -- deploy`
- `npm run mo -- pack`
- `npm run mo -- patch`
- `npm run mo -- release`
- `npm run mo -- update`

## Toolchain 分工
- `patch`：修工具鏈與文件，不動 `src/`、`migrations/`
- `update`：完整專案更新
- `handoff`：AI 聊天交接包；不是 local pack 改名

## Toolchain 驗證
- `npm run smoke:tools`：在暫存 repo 驗證 `mo pack` / `mo patch` / `mo release` / `mo update` 流程是否可完整跑通
- ZIP 產包改用 `archiver`，確保跨平台解壓時 entry path 維持正確的 `/` 結構


## LINE 入口
- 主指令使用「盤後報告」。
- 保留「昨日報告 / report」相容。
- 有設定 OPENAI_API_KEY 時，未知輸入交由 GPT 辨識為 status/report/advice/watchlist/help。


## Daily Loop（正式）
1. 先確認最新交易日與市場資料是否可用。
2. 生成最新交易日的盤後報告（非交易日不生成新報告，但允許補寫最近交易日報告）。
3. 只有在盤後報告可用後，才進入建議與模擬交易。
4. D1 需根據前一交易日建議與隔日高低價判定是否成交。

## Non-Trading Day 行為
- 非交易日不生成新的盤後報告。
- 非交易日可查詢最近交易日的盤後報告。
- 若最近交易日報告尚未落地，系統應自動補寫，不應只顯示舊日期。
