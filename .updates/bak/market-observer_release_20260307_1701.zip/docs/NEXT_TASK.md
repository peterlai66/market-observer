1. 讓 universe 真正進入 strategy engine，避免 Tick 仍為 done 0/0
2. 生成 mo_orders（PENDING）並讓 LINE `建議` 可看到內容
3. 接上 D1 模擬交易：以前一交易日建議 + 隔日高低價判定成交
4. 補個人持股監控與賣出建議（價格區間 + 數量）
5. 將報告/建議/模擬交易的 push 節點做成完整每日輪迴
