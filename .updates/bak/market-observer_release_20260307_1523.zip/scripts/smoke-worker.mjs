#!/usr/bin/env node
import { execFileSync } from 'node:child_process';

const isWin = process.platform === 'win32';
const npxCmd = isWin ? 'npx.cmd' : 'npx';

function run(step, cmd, args) {
  console.log(`[${step}] ${cmd} ${args.join(' ')}`);
  execFileSync(cmd, args, { stdio: 'inherit', env: { ...process.env, CI: '1' } });
}

try {
  run('0', npxCmd, ['wrangler', '--version']);
  run('1', npxCmd, ['wrangler', 'deploy', '--dry-run']);
  run('2', npxCmd, ['wrangler', 'd1', 'migrations', 'list']);
  console.log('[OK] Worker smoke passed');
} catch (error) {
  console.error(error instanceof Error ? error.message : error);
  process.exit(1);
}
